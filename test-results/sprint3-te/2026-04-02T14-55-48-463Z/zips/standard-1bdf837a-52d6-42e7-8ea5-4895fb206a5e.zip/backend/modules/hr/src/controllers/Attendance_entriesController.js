// brick-library/backend-bricks/core/BaseController.js.hbs
const RepositoryProvider = require('../repository/PostgresProvider');
const Attendance_entriesService = require('../services/Attendance_entriesService');

class Attendance_entriesController {
  constructor() {
    this.repository = new RepositoryProvider();
    this.service = new Attendance_entriesService(this.repository, {"HRAttendanceTimesheetMixin":{"attendance_entity":"attendance_entries","shift_entity":"shift_assignments","timesheet_entity":"timesheet_entries","attendance_employee_field":"employee_id","attendance_date_field":"work_date","check_in_field":"check_in_at","check_out_field":"check_out_at","worked_hours_field":"worked_hours","attendance_status_field":"status","shift_employee_field":"employee_id","shift_start_field":"start_time","shift_end_field":"end_time","shift_days_field":"work_days","shift_status_field":"status","timesheet_employee_field":"employee_id","timesheet_date_field":"work_date","timesheet_hours_field":"regular_hours","timesheet_overtime_field":"overtime_hours","timesheet_status_field":"status","timesheet_attendance_field":"attendance_id","enabled":true,"work_days":["Mon"],"daily_hours":6,"employee_entity":"employees"},"hrattendance_timesheet":{"attendance_entity":"attendance_entries","shift_entity":"shift_assignments","timesheet_entity":"timesheet_entries","attendance_employee_field":"employee_id","attendance_date_field":"work_date","check_in_field":"check_in_at","check_out_field":"check_out_at","worked_hours_field":"worked_hours","attendance_status_field":"status","shift_employee_field":"employee_id","shift_start_field":"start_time","shift_end_field":"end_time","shift_days_field":"work_days","shift_status_field":"status","timesheet_employee_field":"employee_id","timesheet_date_field":"work_date","timesheet_hours_field":"regular_hours","timesheet_overtime_field":"overtime_hours","timesheet_status_field":"status","timesheet_attendance_field":"attendance_id","enabled":true,"work_days":["Mon"],"daily_hours":6,"employee_entity":"employees"},"hrattendanceTimesheet":{"attendance_entity":"attendance_entries","shift_entity":"shift_assignments","timesheet_entity":"timesheet_entries","attendance_employee_field":"employee_id","attendance_date_field":"work_date","check_in_field":"check_in_at","check_out_field":"check_out_at","worked_hours_field":"worked_hours","attendance_status_field":"status","shift_employee_field":"employee_id","shift_start_field":"start_time","shift_end_field":"end_time","shift_days_field":"work_days","shift_status_field":"status","timesheet_employee_field":"employee_id","timesheet_date_field":"work_date","timesheet_hours_field":"regular_hours","timesheet_overtime_field":"overtime_hours","timesheet_status_field":"status","timesheet_attendance_field":"attendance_id","enabled":true,"work_days":["Mon"],"daily_hours":6,"employee_entity":"employees"}});
  }

  _errorPayload(error) {
    return {
      error: error.message,
      field_errors: error.fieldErrors || undefined,
      dependents: error.dependents || undefined,
      details: error.details || undefined,
    };
  }

  _resolveStatus(error, fallback = 500) {
    return error.statusCode || error.status || fallback;
  }

  async runAction(req, res, methodName, ...args) {
    try {
      const method = this.service && this.service[methodName];
      if (typeof method !== 'function') {
        return res.status(404).json({ error: `Action '${methodName}' is not available` });
      }
      const result = await method.apply(this.service, args);
      if (result === undefined) {
        return res.status(204).send();
      }
      return res.json(result);
    } catch (error) {
      const status = this._resolveStatus(error, 400);
      return res.status(status).json(this._errorPayload(error));
    }
  }

  async getAll(req, res) {
    try {
      const items = await this.service.findAll(req.query);
      res.json(items);
    } catch (error) {
      res.status(500).json(this._errorPayload(error));
    }
  }

  async getById(req, res) {
    try {
      const item = await this.service.findById(req.params.id);
      if (!item) return res.status(404).json({ error: 'Not found' });
      res.json(item);
    } catch (error) {
      res.status(500).json(this._errorPayload(error));
    }
  }

  async create(req, res) {
    try {
      const item = await this.service.create(req.body);
      res.status(201).json(item);
    } catch (error) {
      const status = this._resolveStatus(error, 400);
      res.status(status).json(this._errorPayload(error));
    }
  }

  async update(req, res) {
    try {
      const item = await this.service.update(req.params.id, req.body);
      if (!item) return res.status(404).json({ error: 'Not found' });
      res.json(item);
    } catch (error) {
      const status = this._resolveStatus(error, 400);
      res.status(status).json(this._errorPayload(error));
    }
  }

  async delete(req, res) {
    try {
      const result = await this.service.delete(req.params.id);
      if (!result) return res.status(404).json({ error: 'Not found' });
      res.status(204).send();
    } catch (error) {
      const status = this._resolveStatus(error, 500);
      res.status(status).json(this._errorPayload(error));
    }
  }
}

module.exports = Attendance_entriesController;

