// brick-library/backend-bricks/core/BaseController.js.hbs
const RepositoryProvider = require('../repository/PostgresProvider');
const LeavesService = require('../services/LeavesService');

class LeavesController {
  constructor() {
    this.repository = new RepositoryProvider();
    this.service = new LeavesService(this.repository, {"HRLeaveMixin":{"leave_entity":"leaves","balance_entity":"leave_balances","employee_field":"employee_id","leave_type_field":"leave_type","start_date_field":"start_date","end_date_field":"end_date","days_field":"leave_days","status_field":"status","entitlement_field":"annual_entitlement","accrued_field":"accrued_days","consumed_field":"consumed_days","carry_forward_field":"carry_forward_days","available_field":"available_days","fiscal_year_field":"year","last_accrual_at_field":"last_accrual_at","default_entitlement":18,"auto_create_balance":true,"enabled":true,"work_days":["Mon"],"daily_hours":6,"consume_on_approval":true,"employee_entity":"employees"},"hrleave":{"leave_entity":"leaves","balance_entity":"leave_balances","employee_field":"employee_id","leave_type_field":"leave_type","start_date_field":"start_date","end_date_field":"end_date","days_field":"leave_days","status_field":"status","entitlement_field":"annual_entitlement","accrued_field":"accrued_days","consumed_field":"consumed_days","carry_forward_field":"carry_forward_days","available_field":"available_days","fiscal_year_field":"year","last_accrual_at_field":"last_accrual_at","default_entitlement":18,"auto_create_balance":true,"enabled":true,"work_days":["Mon"],"daily_hours":6,"consume_on_approval":true,"employee_entity":"employees"},"HRLeaveBalanceMixin":{"leave_entity":"leaves","balance_entity":"leave_balances","employee_field":"employee_id","leave_type_field":"leave_type","start_date_field":"start_date","end_date_field":"end_date","days_field":"leave_days","status_field":"status","entitlement_field":"annual_entitlement","accrued_field":"accrued_days","consumed_field":"consumed_days","carry_forward_field":"carry_forward_days","available_field":"available_days","fiscal_year_field":"year","last_accrual_at_field":"last_accrual_at","default_entitlement":18,"auto_create_balance":true,"enabled":true,"work_days":["Mon"],"daily_hours":6,"consume_on_approval":true,"employee_entity":"employees"},"hrleave_balance":{"leave_entity":"leaves","balance_entity":"leave_balances","employee_field":"employee_id","leave_type_field":"leave_type","start_date_field":"start_date","end_date_field":"end_date","days_field":"leave_days","status_field":"status","entitlement_field":"annual_entitlement","accrued_field":"accrued_days","consumed_field":"consumed_days","carry_forward_field":"carry_forward_days","available_field":"available_days","fiscal_year_field":"year","last_accrual_at_field":"last_accrual_at","default_entitlement":18,"auto_create_balance":true,"enabled":true,"work_days":["Mon"],"daily_hours":6,"consume_on_approval":true,"employee_entity":"employees"},"hrleaveBalance":{"leave_entity":"leaves","balance_entity":"leave_balances","employee_field":"employee_id","leave_type_field":"leave_type","start_date_field":"start_date","end_date_field":"end_date","days_field":"leave_days","status_field":"status","entitlement_field":"annual_entitlement","accrued_field":"accrued_days","consumed_field":"consumed_days","carry_forward_field":"carry_forward_days","available_field":"available_days","fiscal_year_field":"year","last_accrual_at_field":"last_accrual_at","default_entitlement":18,"auto_create_balance":true,"enabled":true,"work_days":["Mon"],"daily_hours":6,"consume_on_approval":true,"employee_entity":"employees"},"HRLeaveApprovalMixin":{"leave_entity":"leaves","status_field":"status","approver_field":"approver_id","approved_at_field":"approved_at","rejected_at_field":"rejected_at","cancelled_at_field":"cancelled_at","rejection_reason_field":"rejection_reason","decision_key_field":"decision_key","statuses":["Pending","Approved","Rejected","Cancelled"],"enforce_transitions":true,"consume_on_approval":true,"enabled":true,"work_days":["Mon"],"daily_hours":6,"balance_entity":"leave_balances","transitions":{"Pending":["Approved","Rejected","Cancelled"],"Approved":["Cancelled"],"Rejected":[],"Cancelled":[]},"employee_field":"employee_id","leave_type_field":"leave_type","start_date_field":"start_date","end_date_field":"end_date","days_field":"leave_days","entitlement_field":"annual_entitlement","accrued_field":"accrued_days","consumed_field":"consumed_days","carry_forward_field":"carry_forward_days","available_field":"available_days","fiscal_year_field":"year","last_accrual_at_field":"last_accrual_at","default_entitlement":18,"auto_create_balance":true,"employee_entity":"employees"},"hrleave_approval":{"leave_entity":"leaves","status_field":"status","approver_field":"approver_id","approved_at_field":"approved_at","rejected_at_field":"rejected_at","cancelled_at_field":"cancelled_at","rejection_reason_field":"rejection_reason","decision_key_field":"decision_key","statuses":["Pending","Approved","Rejected","Cancelled"],"enforce_transitions":true,"consume_on_approval":true,"enabled":true,"work_days":["Mon"],"daily_hours":6,"balance_entity":"leave_balances","transitions":{"Pending":["Approved","Rejected","Cancelled"],"Approved":["Cancelled"],"Rejected":[],"Cancelled":[]},"employee_field":"employee_id","leave_type_field":"leave_type","start_date_field":"start_date","end_date_field":"end_date","days_field":"leave_days","entitlement_field":"annual_entitlement","accrued_field":"accrued_days","consumed_field":"consumed_days","carry_forward_field":"carry_forward_days","available_field":"available_days","fiscal_year_field":"year","last_accrual_at_field":"last_accrual_at","default_entitlement":18,"auto_create_balance":true,"employee_entity":"employees"},"hrleaveApproval":{"leave_entity":"leaves","status_field":"status","approver_field":"approver_id","approved_at_field":"approved_at","rejected_at_field":"rejected_at","cancelled_at_field":"cancelled_at","rejection_reason_field":"rejection_reason","decision_key_field":"decision_key","statuses":["Pending","Approved","Rejected","Cancelled"],"enforce_transitions":true,"consume_on_approval":true,"enabled":true,"work_days":["Mon"],"daily_hours":6,"balance_entity":"leave_balances","transitions":{"Pending":["Approved","Rejected","Cancelled"],"Approved":["Cancelled"],"Rejected":[],"Cancelled":[]},"employee_field":"employee_id","leave_type_field":"leave_type","start_date_field":"start_date","end_date_field":"end_date","days_field":"leave_days","entitlement_field":"annual_entitlement","accrued_field":"accrued_days","consumed_field":"consumed_days","carry_forward_field":"carry_forward_days","available_field":"available_days","fiscal_year_field":"year","last_accrual_at_field":"last_accrual_at","default_entitlement":18,"auto_create_balance":true,"employee_entity":"employees"}});
  }

  _errorPayload(error) {
    return {
      error: error.message,
      field_errors: error.fieldErrors || undefined,
      dependents: error.dependents || undefined,
      details: error.details || undefined,
    };
  }

  _resolveStatus(error, fallback = 500) {
    return error.statusCode || error.status || fallback;
  }

  async runAction(req, res, methodName, ...args) {
    try {
      const method = this.service && this.service[methodName];
      if (typeof method !== 'function') {
        return res.status(404).json({ error: `Action '${methodName}' is not available` });
      }
      const result = await method.apply(this.service, args);
      if (result === undefined) {
        return res.status(204).send();
      }
      return res.json(result);
    } catch (error) {
      const status = this._resolveStatus(error, 400);
      return res.status(status).json(this._errorPayload(error));
    }
  }

  async getAll(req, res) {
    try {
      const items = await this.service.findAll(req.query);
      res.json(items);
    } catch (error) {
      res.status(500).json(this._errorPayload(error));
    }
  }

  async getById(req, res) {
    try {
      const item = await this.service.findById(req.params.id);
      if (!item) return res.status(404).json({ error: 'Not found' });
      res.json(item);
    } catch (error) {
      res.status(500).json(this._errorPayload(error));
    }
  }

  async create(req, res) {
    try {
      const item = await this.service.create(req.body);
      res.status(201).json(item);
    } catch (error) {
      const status = this._resolveStatus(error, 400);
      res.status(status).json(this._errorPayload(error));
    }
  }

  async update(req, res) {
    try {
      const item = await this.service.update(req.params.id, req.body);
      if (!item) return res.status(404).json({ error: 'Not found' });
      res.json(item);
    } catch (error) {
      const status = this._resolveStatus(error, 400);
      res.status(status).json(this._errorPayload(error));
    }
  }

  async delete(req, res) {
    try {
      const result = await this.service.delete(req.params.id);
      if (!result) return res.status(404).json({ error: 'Not found' });
      res.status(204).send();
    } catch (error) {
      const status = this._resolveStatus(error, 500);
      res.status(status).json(this._errorPayload(error));
    }
  }
}

module.exports = LeavesController;

