
const express = require('express');
const router = express.Router();
const Attendance_entriesController = require('../controllers/Attendance_entriesController');

const controller = new Attendance_entriesController();

router.get('/', (req, res) => controller.getAll(req, res));
router.get('/:id', (req, res) => controller.getById(req, res));
router.post('/', (req, res) => controller.create(req, res));
router.put('/:id', (req, res) => controller.update(req, res));
router.delete('/:id', (req, res) => controller.delete(req, res));

router.post('/record', (req, res) => controller.runAction(req, res, 'recordAttendance', req.body || {}));
router.post('/:id/recalculate', (req, res) => controller.runAction(req, res, 'recalculateAttendance', req.params.id, req.body || {}));


module.exports = router;
