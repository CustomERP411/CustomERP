
const express = require('express');
const router = express.Router();
const Compensation_ledgerController = require('../controllers/Compensation_ledgerController');

const controller = new Compensation_ledgerController();

router.get('/', (req, res) => controller.getAll(req, res));
router.get('/:id', (req, res) => controller.getById(req, res));
router.post('/', (req, res) => controller.create(req, res));
router.put('/:id', (req, res) => controller.update(req, res));
router.delete('/:id', (req, res) => controller.delete(req, res));

router.post('/snapshot', (req, res) => controller.runAction(req, res, 'createCompensationSnapshot', req.body || {}));
router.post('/:id/post', (req, res) => controller.runAction(req, res, 'postCompensationLedger', req.params.id, req.body || {}));


module.exports = router;
