
const express = require('express');
const router = express.Router();
const Compensation_snapshotsController = require('../controllers/Compensation_snapshotsController');

const controller = new Compensation_snapshotsController();

router.get('/', (req, res) => controller.getAll(req, res));
router.get('/:id', (req, res) => controller.getById(req, res));
router.post('/', (req, res) => controller.create(req, res));
router.put('/:id', (req, res) => controller.update(req, res));
router.delete('/:id', (req, res) => controller.delete(req, res));

router.post('/:id/post', (req, res) => controller.runAction(req, res, 'postCompensationSnapshot', req.params.id, req.body || {}));


module.exports = router;
