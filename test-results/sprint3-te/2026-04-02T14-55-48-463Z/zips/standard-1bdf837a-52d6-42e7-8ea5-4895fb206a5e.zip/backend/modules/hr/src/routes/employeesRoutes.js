
const express = require('express');
const router = express.Router();
const EmployeesController = require('../controllers/EmployeesController');

const controller = new EmployeesController();

router.get('/', (req, res) => controller.getAll(req, res));
router.get('/:id', (req, res) => controller.getById(req, res));
router.post('/', (req, res) => controller.create(req, res));
router.put('/:id', (req, res) => controller.update(req, res));
router.delete('/:id', (req, res) => controller.delete(req, res));

router.get('/:id/leave-balance', (req, res) => controller.runAction(req, res, 'getEmployeeLeaveBalance', req.params.id, req.query || {}));
router.post('/:id/leave-balance/accrue', (req, res) => controller.runAction(req, res, 'accrueLeaveBalance', req.params.id, req.body || {}));
router.post('/:id/leave-balance/adjust', (req, res) => controller.runAction(req, res, 'adjustLeaveBalance', req.params.id, req.body || {}));


module.exports = router;
