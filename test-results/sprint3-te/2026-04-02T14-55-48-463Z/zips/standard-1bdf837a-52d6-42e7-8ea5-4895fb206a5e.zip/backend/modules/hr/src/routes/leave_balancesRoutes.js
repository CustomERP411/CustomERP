
const express = require('express');
const router = express.Router();
const Leave_balancesController = require('../controllers/Leave_balancesController');

const controller = new Leave_balancesController();

router.get('/', (req, res) => controller.getAll(req, res));
router.get('/:id', (req, res) => controller.getById(req, res));
router.post('/', (req, res) => controller.create(req, res));
router.put('/:id', (req, res) => controller.update(req, res));
router.delete('/:id', (req, res) => controller.delete(req, res));


module.exports = router;
