
const express = require('express');
const router = express.Router();
const LeavesController = require('../controllers/LeavesController');

const controller = new LeavesController();

router.get('/', (req, res) => controller.getAll(req, res));
router.get('/:id', (req, res) => controller.getById(req, res));
router.post('/', (req, res) => controller.create(req, res));
router.put('/:id', (req, res) => controller.update(req, res));
router.delete('/:id', (req, res) => controller.delete(req, res));

router.get('/approvals/pending', (req, res) => controller.runAction(req, res, 'listPendingLeaveApprovals', req.query || {}));
router.post('/:id/approve', (req, res) => controller.runAction(req, res, 'approveLeaveRequest', req.params.id, req.body || {}));
router.post('/:id/reject', (req, res) => controller.runAction(req, res, 'rejectLeaveRequest', req.params.id, req.body || {}));
router.post('/:id/cancel', (req, res) => controller.runAction(req, res, 'cancelLeaveRequest', req.params.id, req.body || {}));
router.post('/:id/recalculate-days', (req, res) => controller.runAction(req, res, 'recalculateLeaveDays', req.params.id, req.body || {}));


module.exports = router;
