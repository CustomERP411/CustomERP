
const express = require('express');
const router = express.Router();
const Timesheet_entriesController = require('../controllers/Timesheet_entriesController');

const controller = new Timesheet_entriesController();

router.get('/', (req, res) => controller.getAll(req, res));
router.get('/:id', (req, res) => controller.getById(req, res));
router.post('/', (req, res) => controller.create(req, res));
router.put('/:id', (req, res) => controller.update(req, res));
router.delete('/:id', (req, res) => controller.delete(req, res));

router.post('/sync', (req, res) => controller.runAction(req, res, 'syncTimesheetWindow', req.body || {}));
router.post('/:id/approve', (req, res) => controller.runAction(req, res, 'approveTimesheetEntry', req.params.id, req.body || {}));


module.exports = router;
