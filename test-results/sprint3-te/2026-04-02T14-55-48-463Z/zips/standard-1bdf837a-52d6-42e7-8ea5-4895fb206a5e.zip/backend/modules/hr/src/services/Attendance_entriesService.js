// brick-library/backend-bricks/core/BaseService.js.hbs
class Attendance_entriesService {
  constructor(repository, mixinConfig = {}) {
    this.repository = repository;
    this.slug = 'attendance_entries';
    this.mixinConfig = mixinConfig && typeof mixinConfig === 'object' ? mixinConfig : {};
  }

  async create(data) {
    // @HOOK: BEFORE_CREATE_VALIDATION
    
      // Schema-driven validation (generated)
      const fieldErrors = {};
      const isMissing = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
      const isMissingNonString = (v) => v === undefined || v === null;

      const existingItems = await this.repository.findAll(this.slug);

      const __refIdSets = {};
      const getRefIdSet = async (slug) => {
        if (__refIdSets[slug]) return __refIdSets[slug];
        const all = await this.repository.findAll(slug);
        __refIdSets[slug] = new Set(all.map((x) => x.id));
        return __refIdSets[slug];
      };

      if (isMissing(data['employee_id'])) fieldErrors['employee_id'] = 'Employee Id is required';

      if (!isMissing(data['employee_id'])) {
        const ids = await getRefIdSet('employees');
        if (!ids.has(String(data['employee_id']))) fieldErrors['employee_id'] = 'Employee Id has an invalid reference';
      }

      if (isMissing(data['work_date'])) fieldErrors['work_date'] = 'Work Date is required';

      if (!isMissing(data['worked_hours'])) {
        const num = typeof data['worked_hours'] === 'number' ? data['worked_hours'] : Number(data['worked_hours']);
        if (Number.isNaN(num)) {
          fieldErrors['worked_hours'] = 'Worked Hours must be a number';
        } else {

        }
      }

      const __allowed_status = ['Present', 'Absent', 'Half Day', 'On Leave'];
      if (!isMissing(data['status']) && !__allowed_status.includes(String(data['status']))) fieldErrors['status'] = 'Status must be one of: Present, Absent, Half Day, On Leave';

      if (!isMissing(data['idempotency_key']) && existingItems.some((it) => String(it['idempotency_key']) === String(data['idempotency_key']))) {
        fieldErrors['idempotency_key'] = 'Idempotency Key must be unique';
      }

      if (Object.keys(fieldErrors).length) {
        const err = new Error('Validation failed');
        err.statusCode = 400;
        err.fieldErrors = fieldErrors;
        throw err;
      }

    
    // @HOOK: BEFORE_CREATE_TRANSFORMATION
    
      {
      const __cfg = this._hrAttCfg();
            if (this.slug === __cfg.attendance_entity && data) {
              const __worked = this._hrAttCalcHours(data[__cfg.check_in_field], data[__cfg.check_out_field]);
              if (__worked !== null && data[__cfg.worked_hours_field] === undefined) {
                data[__cfg.worked_hours_field] = __worked;
              }
              if (data[__cfg.attendance_status_field] === undefined || data[__cfg.attendance_status_field] === null || data[__cfg.attendance_status_field] === '') {
                data[__cfg.attendance_status_field] = 'Present';
              }
            }
            if (this.slug === __cfg.timesheet_entity && data) {
              if (data[__cfg.timesheet_status_field] === undefined || data[__cfg.timesheet_status_field] === null || data[__cfg.timesheet_status_field] === '') {
                data[__cfg.timesheet_status_field] = 'Draft';
              }
            }
      }

    
    const result = await this.repository.create(this.slug, data);
    
    // @HOOK: AFTER_CREATE_LOGGING
    
    return result;
  }

  async update(id, data) {
    // @HOOK: BEFORE_UPDATE_VALIDATION
    
      // Schema-driven validation (generated)
      const existing = await this.repository.findById(this.slug, id);
      if (!existing) return null;
      const merged = { ...existing, ...data };

      const fieldErrors = {};
      const isMissing = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
      const isMissingNonString = (v) => v === undefined || v === null;

      const existingItems = await this.repository.findAll(this.slug);

      const __refIdSets = {};
      const getRefIdSet = async (slug) => {
        if (__refIdSets[slug]) return __refIdSets[slug];
        const all = await this.repository.findAll(slug);
        __refIdSets[slug] = new Set(all.map((x) => x.id));
        return __refIdSets[slug];
      };

      if (isMissing(merged['employee_id'])) fieldErrors['employee_id'] = 'Employee Id is required';

      if (!isMissing(merged['employee_id'])) {
        const ids = await getRefIdSet('employees');
        if (!ids.has(String(merged['employee_id']))) fieldErrors['employee_id'] = 'Employee Id has an invalid reference';
      }

      if (isMissing(merged['work_date'])) fieldErrors['work_date'] = 'Work Date is required';

      if (!isMissing(merged['worked_hours'])) {
        const num = typeof merged['worked_hours'] === 'number' ? merged['worked_hours'] : Number(merged['worked_hours']);
        if (Number.isNaN(num)) {
          fieldErrors['worked_hours'] = 'Worked Hours must be a number';
        } else {

        }
      }

      const __allowed_status = ['Present', 'Absent', 'Half Day', 'On Leave'];
      if (!isMissing(merged['status']) && !__allowed_status.includes(String(merged['status']))) fieldErrors['status'] = 'Status must be one of: Present, Absent, Half Day, On Leave';

      if (!isMissing(merged['idempotency_key']) && existingItems.some((it) => it.id !== id && String(it['idempotency_key']) === String(merged['idempotency_key']))) {
        fieldErrors['idempotency_key'] = 'Idempotency Key must be unique';
      }

      if (Object.keys(fieldErrors).length) {
        const err = new Error('Validation failed');
        err.statusCode = 400;
        err.fieldErrors = fieldErrors;
        throw err;
      }

    
    const result = await this.repository.update(this.slug, id, data);
    
    // @HOOK: AFTER_UPDATE_LOGGING

    return result;
  }

  async delete(id) {
    // @HOOK: BEFORE_DELETE_VALIDATION
    
      // Delete protection (generated): prevent deleting a record that is referenced by others
      const dependents = [];

      {
        const rows = await this.repository.findAll('timesheet_entries');
        const matches = rows.filter((row) => String(row['attendance_id'] ?? '') === String(id));
        if (matches.length) {
          dependents.push({
            entity: 'timesheet_entries',
            via: ['attendance_id'],
            count: matches.length,
            preview: matches.slice(0, 10).map((r) => ({ id: r.id, display: r['employee_id'] || r.id })),
          });
        }
      }

      if (dependents.length) {
        const err = new Error('Cannot delete: this record is referenced by other records');
        err.statusCode = 409;
        err.dependents = dependents;
        throw err;
      }


    const result = await this.repository.delete(this.slug, id);
    
    // @HOOK: AFTER_DELETE_LOGGING

    return result;
  }

  async findById(id) {
    return this.repository.findById(this.slug, id);
  }

  async findAll(filter = {}) {
    return this.repository.findAll(this.slug, filter);
  }

  // @HOOK: ADDITIONAL_METHODS
    
  _hrAttCfg() {
    const cfg =
      this.mixinConfig?.hr_attendance_timesheet ||
      this.mixinConfig?.hrAttendanceTimesheet ||
      this.mixinConfig?.hr_attendance_time ||
      this.mixinConfig?.hrAttendanceTime ||
      {};
    return {
      employee_entity: cfg.employee_entity || cfg.employeeEntity || 'employees',
      attendance_entity: cfg.attendance_entity || cfg.attendanceEntity || 'attendance_entries',
      shift_entity: cfg.shift_entity || cfg.shiftEntity || 'shift_assignments',
      timesheet_entity: cfg.timesheet_entity || cfg.timesheetEntity || 'timesheet_entries',
      attendance_employee_field: cfg.attendance_employee_field || cfg.attendanceEmployeeField || 'employee_id',
      attendance_date_field: cfg.attendance_date_field || cfg.attendanceDateField || 'work_date',
      check_in_field: cfg.check_in_field || cfg.checkInField || 'check_in_at',
      check_out_field: cfg.check_out_field || cfg.checkOutField || 'check_out_at',
      worked_hours_field: cfg.worked_hours_field || cfg.workedHoursField || 'worked_hours',
      attendance_status_field: cfg.attendance_status_field || cfg.attendanceStatusField || 'status',
      timesheet_employee_field: cfg.timesheet_employee_field || cfg.timesheetEmployeeField || 'employee_id',
      timesheet_date_field: cfg.timesheet_date_field || cfg.timesheetDateField || 'work_date',
      timesheet_hours_field: cfg.timesheet_hours_field || cfg.timesheetHoursField || 'regular_hours',
      timesheet_overtime_field: cfg.timesheet_overtime_field || cfg.timesheetOvertimeField || 'overtime_hours',
      timesheet_status_field: cfg.timesheet_status_field || cfg.timesheetStatusField || 'status',
      timesheet_attendance_field: cfg.timesheet_attendance_field || cfg.timesheetAttendanceField || 'attendance_id',
      timesheet_approved_at_field: cfg.timesheet_approved_at_field || cfg.timesheetApprovedAtField || 'approved_at',
      timesheet_approved_by_field: cfg.timesheet_approved_by_field || cfg.timesheetApprovedByField || 'approved_by',
      daily_hours: Number(cfg.daily_hours || cfg.dailyHours || 6) || 6,
    };
  }

  _hrAttErr(message, statusCode = 400, details = null) {
    const err = new Error(message);
    err.statusCode = statusCode;
    if (details) err.details = details;
    return err;
  }

  _hrAttRound(rawValue) {
    const num = Number(rawValue);
    if (!Number.isFinite(num)) return 0;
    return Number(num.toFixed(2));
  }

  _hrAttCalcHours(checkInRaw, checkOutRaw) {
    if (!checkInRaw || !checkOutRaw) return null;
    const inDate = new Date(checkInRaw);
    const outDate = new Date(checkOutRaw);
    if (!Number.isFinite(inDate.getTime()) || !Number.isFinite(outDate.getTime())) {
      throw this._hrAttErr('Invalid check-in/check-out datetime values', 400);
    }
    if (outDate.getTime() < inDate.getTime()) {
      throw this._hrAttErr('check_out_at must be on or after check_in_at', 400);
    }
    const hours = (outDate.getTime() - inDate.getTime()) / (1000 * 60 * 60);
    return this._hrAttRound(hours);
  }

  async recordAttendance(payload = {}) {
    const cfg = this._hrAttCfg();
    if (this.slug !== cfg.attendance_entity) {
      throw this._hrAttErr(
        `Attendance record can only run on '${cfg.attendance_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    const employeeId = payload[cfg.attendance_employee_field] || payload.employee_id || payload.employeeId;
    const workDate = payload[cfg.attendance_date_field] || payload.work_date || payload.workDate;
    if (!employeeId) throw this._hrAttErr('employee_id is required', 400);
    if (!workDate) throw this._hrAttErr('work_date is required', 400);

    return this.repository.withTransaction(async (client) => {
      if (this.repository && typeof this.repository.atomicUpsertAttendanceTimesheet === 'function') {
        return this.repository.atomicUpsertAttendanceTimesheet(
          cfg.attendance_entity,
          cfg.timesheet_entity,
          {
            employee_id: employeeId,
            work_date: workDate,
            attendance_employee_field: cfg.attendance_employee_field,
            attendance_date_field: cfg.attendance_date_field,
            check_in_field: cfg.check_in_field,
            check_out_field: cfg.check_out_field,
            worked_hours_field: cfg.worked_hours_field,
            attendance_status_field: cfg.attendance_status_field,
            timesheet_employee_field: cfg.timesheet_employee_field,
            timesheet_date_field: cfg.timesheet_date_field,
            timesheet_hours_field: cfg.timesheet_hours_field,
            timesheet_overtime_field: cfg.timesheet_overtime_field,
            timesheet_status_field: cfg.timesheet_status_field,
            timesheet_attendance_field: cfg.timesheet_attendance_field,
            daily_hours: cfg.daily_hours,
            attendance_patch: payload,
          },
          client
        );
      }

      const existing = await this.repository.findAllWithClient(cfg.attendance_entity, {
        [cfg.attendance_employee_field]: employeeId,
        [cfg.attendance_date_field]: workDate,
      }, client);
      const current = Array.isArray(existing) && existing.length ? existing[0] : null;

      const checkIn = payload[cfg.check_in_field] ?? payload.check_in_at ?? payload.checkInAt ?? (current ? current[cfg.check_in_field] : null);
      const checkOut = payload[cfg.check_out_field] ?? payload.check_out_at ?? payload.checkOutAt ?? (current ? current[cfg.check_out_field] : null);
      const workedHoursRaw = payload[cfg.worked_hours_field] ?? payload.worked_hours;
      const workedHours = workedHoursRaw !== undefined ? this._hrAttRound(workedHoursRaw) : this._hrAttCalcHours(checkIn, checkOut);
      const attendancePayload = {
        [cfg.attendance_employee_field]: employeeId,
        [cfg.attendance_date_field]: workDate,
        [cfg.check_in_field]: checkIn || null,
        [cfg.check_out_field]: checkOut || null,
        [cfg.worked_hours_field]: workedHours !== null ? workedHours : 0,
        [cfg.attendance_status_field]:
          payload[cfg.attendance_status_field] ||
          payload.status ||
          (current ? current[cfg.attendance_status_field] : null) ||
          'Present',
      };
      if (payload.note !== undefined) attendancePayload.note = payload.note;

      const attendance = current
        ? await this.repository.updateWithClient(cfg.attendance_entity, current.id, attendancePayload, client)
        : await this.repository.createWithClient(cfg.attendance_entity, attendancePayload, client);

      const worked = this._hrAttRound(attendance[cfg.worked_hours_field] || 0);
      const regular = this._hrAttRound(Math.min(worked, cfg.daily_hours));
      const overtime = this._hrAttRound(Math.max(worked - cfg.daily_hours, 0));
      const existingTimesheets = await this.repository.findAllWithClient(cfg.timesheet_entity, {
        [cfg.timesheet_employee_field]: employeeId,
        [cfg.timesheet_date_field]: workDate,
      }, client);
      const currentTimesheet = Array.isArray(existingTimesheets) && existingTimesheets.length ? existingTimesheets[0] : null;
      const timesheetPayload = {
        [cfg.timesheet_employee_field]: employeeId,
        [cfg.timesheet_date_field]: workDate,
        [cfg.timesheet_hours_field]: regular,
        [cfg.timesheet_overtime_field]: overtime,
        [cfg.timesheet_status_field]: currentTimesheet ? currentTimesheet[cfg.timesheet_status_field] || 'Draft' : 'Draft',
        [cfg.timesheet_attendance_field]: attendance.id,
      };
      const timesheet = currentTimesheet
        ? await this.repository.updateWithClient(cfg.timesheet_entity, currentTimesheet.id, timesheetPayload, client)
        : await this.repository.createWithClient(cfg.timesheet_entity, timesheetPayload, client);

      return {
        attendance,
        timesheet,
      };
    });
  }

  async recalculateAttendance(attendanceId, payload = {}) {
    const cfg = this._hrAttCfg();
    if (this.slug !== cfg.attendance_entity) {
      throw this._hrAttErr(
        `Attendance recalculation can only run on '${cfg.attendance_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    return this.repository.withTransaction(async (client) => {
      const attendance = await this.repository.findByIdForUpdate(cfg.attendance_entity, attendanceId, client);
      if (!attendance) throw this._hrAttErr('Attendance entry not found', 404);

      const checkIn = payload[cfg.check_in_field] ?? attendance[cfg.check_in_field];
      const checkOut = payload[cfg.check_out_field] ?? attendance[cfg.check_out_field];
      const workedHours = this._hrAttCalcHours(checkIn, checkOut);

      const updatedAttendance = await this.repository.updateWithClient(cfg.attendance_entity, attendanceId, {
        [cfg.check_in_field]: checkIn || null,
        [cfg.check_out_field]: checkOut || null,
        [cfg.worked_hours_field]: workedHours !== null ? workedHours : attendance[cfg.worked_hours_field] || 0,
      }, client);

      const employeeId = updatedAttendance[cfg.attendance_employee_field];
      const workDate = updatedAttendance[cfg.attendance_date_field];
      const regular = this._hrAttRound(Math.min(updatedAttendance[cfg.worked_hours_field] || 0, cfg.daily_hours));
      const overtime = this._hrAttRound(Math.max((updatedAttendance[cfg.worked_hours_field] || 0) - cfg.daily_hours, 0));
      const existingTimesheets = await this.repository.findAllWithClient(cfg.timesheet_entity, {
        [cfg.timesheet_employee_field]: employeeId,
        [cfg.timesheet_date_field]: workDate,
      }, client);
      const currentTimesheet = Array.isArray(existingTimesheets) && existingTimesheets.length ? existingTimesheets[0] : null;
      const timesheetPayload = {
        [cfg.timesheet_employee_field]: employeeId,
        [cfg.timesheet_date_field]: workDate,
        [cfg.timesheet_hours_field]: regular,
        [cfg.timesheet_overtime_field]: overtime,
        [cfg.timesheet_attendance_field]: updatedAttendance.id,
      };
      const timesheet = currentTimesheet
        ? await this.repository.updateWithClient(cfg.timesheet_entity, currentTimesheet.id, timesheetPayload, client)
        : await this.repository.createWithClient(cfg.timesheet_entity, {
            ...timesheetPayload,
            [cfg.timesheet_status_field]: 'Draft',
          }, client);

      return {
        attendance: updatedAttendance,
        timesheet,
      };
    });
  }

  async syncTimesheetWindow(payload = {}) {
    const cfg = this._hrAttCfg();
    if (this.slug !== cfg.timesheet_entity) {
      throw this._hrAttErr(
        `Timesheet sync can only run on '${cfg.timesheet_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }
    const employeeId = payload[cfg.attendance_employee_field] || payload.employee_id || payload.employeeId;
    if (!employeeId) throw this._hrAttErr('employee_id is required for timesheet sync', 400);

    const fromDate = payload.from_date || payload.fromDate || null;
    const toDate = payload.to_date || payload.toDate || null;

    return this.repository.withTransaction(async (client) => {
      const attendanceRows = await this.repository.findAllWithClient(cfg.attendance_entity, {
        [cfg.attendance_employee_field]: employeeId,
      }, client);
      const filtered = (Array.isArray(attendanceRows) ? attendanceRows : []).filter((row) => {
        const day = String(row[cfg.attendance_date_field] || '');
        if (!day) return false;
        if (fromDate && day < String(fromDate)) return false;
        if (toDate && day > String(toDate)) return false;
        return true;
      });

      let synced = 0;
      for (const row of filtered) {
        const workDate = row[cfg.attendance_date_field];
        const regular = this._hrAttRound(Math.min(row[cfg.worked_hours_field] || 0, cfg.daily_hours));
        const overtime = this._hrAttRound(Math.max((row[cfg.worked_hours_field] || 0) - cfg.daily_hours, 0));
        const existingTimesheets = await this.repository.findAllWithClient(cfg.timesheet_entity, {
          [cfg.timesheet_employee_field]: employeeId,
          [cfg.timesheet_date_field]: workDate,
        }, client);
        const current = Array.isArray(existingTimesheets) && existingTimesheets.length ? existingTimesheets[0] : null;
        const patch = {
          [cfg.timesheet_employee_field]: employeeId,
          [cfg.timesheet_date_field]: workDate,
          [cfg.timesheet_hours_field]: regular,
          [cfg.timesheet_overtime_field]: overtime,
          [cfg.timesheet_attendance_field]: row.id,
        };
        if (current) {
          await this.repository.updateWithClient(cfg.timesheet_entity, current.id, patch, client);
        } else {
          await this.repository.createWithClient(cfg.timesheet_entity, {
            ...patch,
            [cfg.timesheet_status_field]: 'Draft',
          }, client);
        }
        synced += 1;
      }

      return {
        employee_id: employeeId,
        synced_entries: synced,
      };
    });
  }

  async approveTimesheetEntry(timesheetId, payload = {}) {
    const cfg = this._hrAttCfg();
    if (this.slug !== cfg.timesheet_entity) {
      throw this._hrAttErr(
        `Timesheet approval can only run on '${cfg.timesheet_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    return this.repository.withTransaction(async (client) => {
      const row = await this.repository.findByIdForUpdate(cfg.timesheet_entity, timesheetId, client);
      if (!row) throw this._hrAttErr('Timesheet entry not found', 404);
      const updated = await this.repository.updateWithClient(cfg.timesheet_entity, timesheetId, {
        [cfg.timesheet_status_field]: 'Approved',
        [cfg.timesheet_approved_at_field]: new Date().toISOString(),
        [cfg.timesheet_approved_by_field]: payload.approved_by || payload.approvedBy || payload[cfg.timesheet_approved_by_field] || null,
      }, client);
      return {
        timesheet: updated,
      };
    });
  }
    
}

module.exports = Attendance_entriesService;
