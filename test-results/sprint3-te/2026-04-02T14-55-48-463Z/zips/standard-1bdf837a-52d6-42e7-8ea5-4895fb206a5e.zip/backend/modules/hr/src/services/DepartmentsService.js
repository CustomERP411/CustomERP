// brick-library/backend-bricks/core/BaseService.js.hbs
class DepartmentsService {
  constructor(repository, mixinConfig = {}) {
    this.repository = repository;
    this.slug = 'departments';
    this.mixinConfig = mixinConfig && typeof mixinConfig === 'object' ? mixinConfig : {};
  }

  async create(data) {
    // @HOOK: BEFORE_CREATE_VALIDATION
    
      // Schema-driven validation (generated)
      const fieldErrors = {};
      const isMissing = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
      const isMissingNonString = (v) => v === undefined || v === null;

      const existingItems = await this.repository.findAll(this.slug);

      const __refIdSets = {};
      const getRefIdSet = async (slug) => {
        if (__refIdSets[slug]) return __refIdSets[slug];
        const all = await this.repository.findAll(slug);
        __refIdSets[slug] = new Set(all.map((x) => x.id));
        return __refIdSets[slug];
      };

      if (isMissing(data['name'])) fieldErrors['name'] = 'Name is required';

      if (!isMissing(data['name']) && existingItems.some((it) => String(it['name']) === String(data['name']))) {
        fieldErrors['name'] = 'Name must be unique';
      }

      if (!isMissing(data['manager_id'])) {
        const ids = await getRefIdSet('employees');
        if (!ids.has(String(data['manager_id']))) fieldErrors['manager_id'] = 'Manager has an invalid reference';
      }

      if (Object.keys(fieldErrors).length) {
        const err = new Error('Validation failed');
        err.statusCode = 400;
        err.fieldErrors = fieldErrors;
        throw err;
      }

    
    // @HOOK: BEFORE_CREATE_TRANSFORMATION
    
      {
      // HRDepartmentMixin: Normalize core fields
            if (data.name !== undefined && data.name !== null) {
              data.name = String(data.name).trim();
            }
            if (data.location !== undefined && data.location !== null) {
              data.location = String(data.location).trim();
            }
      }

    
    const result = await this.repository.create(this.slug, data);
    
    // @HOOK: AFTER_CREATE_LOGGING
    
    return result;
  }

  async update(id, data) {
    // @HOOK: BEFORE_UPDATE_VALIDATION
    
      // Schema-driven validation (generated)
      const existing = await this.repository.findById(this.slug, id);
      if (!existing) return null;
      const merged = { ...existing, ...data };

      const fieldErrors = {};
      const isMissing = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
      const isMissingNonString = (v) => v === undefined || v === null;

      const existingItems = await this.repository.findAll(this.slug);

      const __refIdSets = {};
      const getRefIdSet = async (slug) => {
        if (__refIdSets[slug]) return __refIdSets[slug];
        const all = await this.repository.findAll(slug);
        __refIdSets[slug] = new Set(all.map((x) => x.id));
        return __refIdSets[slug];
      };

      if (isMissing(merged['name'])) fieldErrors['name'] = 'Name is required';

      if (!isMissing(merged['name']) && existingItems.some((it) => it.id !== id && String(it['name']) === String(merged['name']))) {
        fieldErrors['name'] = 'Name must be unique';
      }

      if (!isMissing(merged['manager_id'])) {
        const ids = await getRefIdSet('employees');
        if (!ids.has(String(merged['manager_id']))) fieldErrors['manager_id'] = 'Manager has an invalid reference';
      }

      if (Object.keys(fieldErrors).length) {
        const err = new Error('Validation failed');
        err.statusCode = 400;
        err.fieldErrors = fieldErrors;
        throw err;
      }

    
      {
      // HRDepartmentMixin: Basic validation guardrails
            if (data.name !== undefined && data.name !== null) {
              data.name = String(data.name).trim();
            }
            if (data.location !== undefined && data.location !== null) {
              data.location = String(data.location).trim();
            }
      }

    
    const result = await this.repository.update(this.slug, id, data);
    
    // @HOOK: AFTER_UPDATE_LOGGING

    return result;
  }

  async delete(id) {
    // @HOOK: BEFORE_DELETE_VALIDATION
    
      // Delete protection (generated): prevent deleting a record that is referenced by others
      const dependents = [];

      {
        const rows = await this.repository.findAll('employees');
        const matches = rows.filter((row) => String(row['department_id'] ?? '') === String(id));
        if (matches.length) {
          dependents.push({
            entity: 'employees',
            via: ['department_id'],
            count: matches.length,
            preview: matches.slice(0, 10).map((r) => ({ id: r.id, display: r['first_name'] || r.id })),
          });
        }
      }

      if (dependents.length) {
        const err = new Error('Cannot delete: this record is referenced by other records');
        err.statusCode = 409;
        err.dependents = dependents;
        throw err;
      }


    const result = await this.repository.delete(this.slug, id);
    
    // @HOOK: AFTER_DELETE_LOGGING

    return result;
  }

  async findById(id) {
    return this.repository.findById(this.slug, id);
  }

  async findAll(filter = {}) {
    return this.repository.findAll(this.slug, filter);
  }

  // @HOOK: ADDITIONAL_METHODS
}

module.exports = DepartmentsService;
