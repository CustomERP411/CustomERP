// brick-library/backend-bricks/core/BaseService.js.hbs
class LeavesService {
  constructor(repository, mixinConfig = {}) {
    this.repository = repository;
    this.slug = 'leaves';
    this.mixinConfig = mixinConfig && typeof mixinConfig === 'object' ? mixinConfig : {};
  }

  async create(data) {
    // @HOOK: BEFORE_CREATE_VALIDATION
    
      // Schema-driven validation (generated)
      const fieldErrors = {};
      const isMissing = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
      const isMissingNonString = (v) => v === undefined || v === null;

      const __refIdSets = {};
      const getRefIdSet = async (slug) => {
        if (__refIdSets[slug]) return __refIdSets[slug];
        const all = await this.repository.findAll(slug);
        __refIdSets[slug] = new Set(all.map((x) => x.id));
        return __refIdSets[slug];
      };

      if (isMissing(data['employee_id'])) fieldErrors['employee_id'] = 'Employee Id is required';

      if (!isMissing(data['employee_id'])) {
        const ids = await getRefIdSet('employees');
        if (!ids.has(String(data['employee_id']))) fieldErrors['employee_id'] = 'Employee Id has an invalid reference';
      }

      if (isMissing(data['leave_type'])) fieldErrors['leave_type'] = 'Leave Type is required';

      const __allowed_leave_type = ['Sick'];
      if (!isMissing(data['leave_type']) && !__allowed_leave_type.includes(String(data['leave_type']))) fieldErrors['leave_type'] = 'Leave Type must be one of: Sick';

      if (isMissing(data['start_date'])) fieldErrors['start_date'] = 'Start Date is required';

      if (isMissing(data['end_date'])) fieldErrors['end_date'] = 'End Date is required';

      if (!isMissing(data['leave_days'])) {
        const num = typeof data['leave_days'] === 'number' ? data['leave_days'] : Number(data['leave_days']);
        if (Number.isNaN(num)) {
          fieldErrors['leave_days'] = 'Leave Days must be a number';
        } else {

          if (!Number.isInteger(num)) fieldErrors['leave_days'] = 'Leave Days must be an integer';

        }
      }

      if (isMissing(data['status'])) fieldErrors['status'] = 'Status is required';

      const __allowed_status = ['Pending', 'Approved', 'Rejected', 'Cancelled'];
      if (!isMissing(data['status']) && !__allowed_status.includes(String(data['status']))) fieldErrors['status'] = 'Status must be one of: Pending, Approved, Rejected, Cancelled';

      if (Object.keys(fieldErrors).length) {
        const err = new Error('Validation failed');
        err.statusCode = 400;
        err.fieldErrors = fieldErrors;
        throw err;
      }

    
      {
      // HRLeaveMixin: Basic date range validation
            if (data.start_date && data.end_date) {
              const start = new Date(data.start_date);
              const end = new Date(data.end_date);
              if (isNaN(start.getTime()) || isNaN(end.getTime())) {
                throw new Error('Invalid leave date range');
              }
              if (end.getTime() < start.getTime()) {
                throw new Error('Leave end_date must be on or after start_date');
              }
            }
      }

    
    // @HOOK: BEFORE_CREATE_TRANSFORMATION
    
      {
      const __cfg = this._hrLeaveApprovalCfg();
            if (this.slug === __cfg.leave_entity && data) {
              if (data[__cfg.status_field] === undefined || data[__cfg.status_field] === null || data[__cfg.status_field] === '') {
                data[__cfg.status_field] = 'Pending';
              }
            }
      }

    
      {
      const __cfg = this._hrLeaveCfg();
            if (this.slug === __cfg.leave_entity && data) {
              const __start = data[__cfg.start_date_field];
              const __end = data[__cfg.end_date_field];
              if ((__start || __end) && data[__cfg.days_field] === undefined) {
                const __days = this._hrLeaveCalcDays(__start, __end, __cfg);
                if (__days !== null) data[__cfg.days_field] = __days;
              }
              if (data[__cfg.status_field] === undefined || data[__cfg.status_field] === null || data[__cfg.status_field] === '') {
                data[__cfg.status_field] = 'Pending';
              }
            }
            if (this.slug === __cfg.balance_entity && data) {
              const __entitlement = this._hrLeaveRound(data[__cfg.entitlement_field] ?? __cfg.default_entitlement);
              const __accrued = this._hrLeaveRound(data[__cfg.accrued_field] ?? __entitlement);
              const __consumed = this._hrLeaveRound(data[__cfg.consumed_field] ?? 0);
              const __carry = this._hrLeaveRound(data[__cfg.carry_forward_field] ?? 0);
              const __available = this._hrLeaveRound(
                data[__cfg.available_field] !== undefined
                  ? data[__cfg.available_field]
                  : (__entitlement + __accrued + __carry - __consumed)
              );
              data[__cfg.entitlement_field] = __entitlement;
              data[__cfg.accrued_field] = __accrued;
              data[__cfg.consumed_field] = __consumed;
              data[__cfg.carry_forward_field] = __carry;
              data[__cfg.available_field] = __available;
              if (!data[__cfg.fiscal_year_field]) data[__cfg.fiscal_year_field] = String(new Date().getFullYear());
            }
      }

    
      {
      // HRLeaveMixin: Normalize dates
            if (data.start_date) {
              const start = new Date(data.start_date);
              if (!isNaN(start.getTime())) {
                data.start_date = start.toISOString();
              }
            }
            if (data.end_date) {
              const end = new Date(data.end_date);
              if (!isNaN(end.getTime())) {
                data.end_date = end.toISOString();
              }
            }
      }

    
    const result = await this.repository.create(this.slug, data);
    
    // @HOOK: AFTER_CREATE_LOGGING
    
    return result;
  }

  async update(id, data) {
    // @HOOK: BEFORE_UPDATE_VALIDATION
    
      // Schema-driven validation (generated)
      const existing = await this.repository.findById(this.slug, id);
      if (!existing) return null;
      const merged = { ...existing, ...data };

      const fieldErrors = {};
      const isMissing = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
      const isMissingNonString = (v) => v === undefined || v === null;

      const __refIdSets = {};
      const getRefIdSet = async (slug) => {
        if (__refIdSets[slug]) return __refIdSets[slug];
        const all = await this.repository.findAll(slug);
        __refIdSets[slug] = new Set(all.map((x) => x.id));
        return __refIdSets[slug];
      };

      if (isMissing(merged['employee_id'])) fieldErrors['employee_id'] = 'Employee Id is required';

      if (!isMissing(merged['employee_id'])) {
        const ids = await getRefIdSet('employees');
        if (!ids.has(String(merged['employee_id']))) fieldErrors['employee_id'] = 'Employee Id has an invalid reference';
      }

      if (isMissing(merged['leave_type'])) fieldErrors['leave_type'] = 'Leave Type is required';

      const __allowed_leave_type = ['Sick'];
      if (!isMissing(merged['leave_type']) && !__allowed_leave_type.includes(String(merged['leave_type']))) fieldErrors['leave_type'] = 'Leave Type must be one of: Sick';

      if (isMissing(merged['start_date'])) fieldErrors['start_date'] = 'Start Date is required';

      if (isMissing(merged['end_date'])) fieldErrors['end_date'] = 'End Date is required';

      if (!isMissing(merged['leave_days'])) {
        const num = typeof merged['leave_days'] === 'number' ? merged['leave_days'] : Number(merged['leave_days']);
        if (Number.isNaN(num)) {
          fieldErrors['leave_days'] = 'Leave Days must be a number';
        } else {

          if (!Number.isInteger(num)) fieldErrors['leave_days'] = 'Leave Days must be an integer';

        }
      }

      if (isMissing(merged['status'])) fieldErrors['status'] = 'Status is required';

      const __allowed_status = ['Pending', 'Approved', 'Rejected', 'Cancelled'];
      if (!isMissing(merged['status']) && !__allowed_status.includes(String(merged['status']))) fieldErrors['status'] = 'Status must be one of: Pending, Approved, Rejected, Cancelled';

      if (Object.keys(fieldErrors).length) {
        const err = new Error('Validation failed');
        err.statusCode = 400;
        err.fieldErrors = fieldErrors;
        throw err;
      }

    
      {
      const __cfg = this._hrLeaveApprovalCfg();
            if (this.slug === __cfg.leave_entity && data && Object.prototype.hasOwnProperty.call(data, __cfg.status_field)) {
              const __nextStatus = String(data[__cfg.status_field] || '');
              if (!__cfg.statuses.includes(__nextStatus)) {
                throw this._hrLeaveApprovalErr(`${__cfg.status_field} must be one of: ${__cfg.statuses.join(', ')}`, 400);
              }
            }
      }

    
      {
      const __cfg = this._hrLeaveCfg();
            if (this.slug === __cfg.leave_entity && data) {
              const __hasStart = Object.prototype.hasOwnProperty.call(data, __cfg.start_date_field);
              const __hasEnd = Object.prototype.hasOwnProperty.call(data, __cfg.end_date_field);
              if (__hasStart || __hasEnd) {
                const __existing = await this.repository.findById(this.slug, id);
                const __start = __hasStart ? data[__cfg.start_date_field] : (__existing ? __existing[__cfg.start_date_field] : null);
                const __end = __hasEnd ? data[__cfg.end_date_field] : (__existing ? __existing[__cfg.end_date_field] : null);
                const __days = this._hrLeaveCalcDays(__start, __end, __cfg);
                if (__days !== null) data[__cfg.days_field] = __days;
              }
            }
      }

    
      {
      // HRLeaveMixin: Validate and normalize updates
            const hasStart = data.start_date !== undefined && data.start_date !== null;
            const hasEnd = data.end_date !== undefined && data.end_date !== null;
            let rangeStart = null;
            let rangeEnd = null;
            if (hasStart) {
              const start = new Date(data.start_date);
              if (isNaN(start.getTime())) {
                throw new Error('Invalid start_date');
              }
              data.start_date = start.toISOString();
              rangeStart = data.start_date;
            }
            if (hasEnd) {
              const end = new Date(data.end_date);
              if (isNaN(end.getTime())) {
                throw new Error('Invalid end_date');
              }
              data.end_date = end.toISOString();
              rangeEnd = data.end_date;
            }
            if (hasStart || hasEnd) {
              if (!rangeStart || !rangeEnd) {
                const existing = await this.repository.findById(this.slug, id);
                if (existing) {
                  if (!rangeStart && existing.start_date) {
                    rangeStart = existing.start_date;
                  }
                  if (!rangeEnd && existing.end_date) {
                    rangeEnd = existing.end_date;
                  }
                }
              }
              if (rangeStart && rangeEnd) {
                const start = new Date(rangeStart);
                const end = new Date(rangeEnd);
                if (isNaN(start.getTime()) || isNaN(end.getTime())) {
                  throw new Error('Invalid leave date range');
                }
                if (end.getTime() < start.getTime()) {
                  throw new Error('Leave end_date must be on or after start_date');
                }
              }
            }
      }

    
    const result = await this.repository.update(this.slug, id, data);
    
    // @HOOK: AFTER_UPDATE_LOGGING

    return result;
  }

  async delete(id) {
    // @HOOK: BEFORE_DELETE_VALIDATION

    const result = await this.repository.delete(this.slug, id);
    
    // @HOOK: AFTER_DELETE_LOGGING

    return result;
  }

  async findById(id) {
    return this.repository.findById(this.slug, id);
  }

  async findAll(filter = {}) {
    return this.repository.findAll(this.slug, filter);
  }

  // @HOOK: ADDITIONAL_METHODS
    
  _hrLeaveApprovalCfg() {
    const cfg =
      this.mixinConfig?.hr_leave_approval ||
      this.mixinConfig?.hrLeaveApproval ||
      {};
    return {
      leave_entity: cfg.leave_entity || cfg.leaveEntity || 'leaves',
      status_field: cfg.status_field || cfg.statusField || 'status',
      approver_field: cfg.approver_field || cfg.approverField || 'approver_id',
      approved_at_field: cfg.approved_at_field || cfg.approvedAtField || 'approved_at',
      rejected_at_field: cfg.rejected_at_field || cfg.rejectedAtField || 'rejected_at',
      cancelled_at_field: cfg.cancelled_at_field || cfg.cancelledAtField || 'cancelled_at',
      rejection_reason_field: cfg.rejection_reason_field || cfg.rejectionReasonField || 'rejection_reason',
      decision_key_field: cfg.decision_key_field || cfg.decisionKeyField || 'decision_key',
      statuses:
        (Array.isArray(cfg.statuses) && cfg.statuses.length
          ? cfg.statuses
          : ["Pending","Approved","Rejected","Cancelled"]),
      enforce_transitions:
        cfg.enforce_transitions !== false &&
        cfg.enforceTransitions !== false,
      consume_on_approval:
        cfg.consume_on_approval !== false &&
        cfg.consumeOnApproval !== false,
      transitions:
        (cfg.transitions && typeof cfg.transitions === 'object')
          ? cfg.transitions
          : {"Pending":["Approved","Rejected","Cancelled"],"Approved":["Cancelled"],"Rejected":[],"Cancelled":[]},
      employee_field: cfg.employee_field || cfg.employeeField || 'employee_id',
      leave_type_field: cfg.leave_type_field || cfg.leaveTypeField || 'leave_type',
      days_field: cfg.days_field || cfg.daysField || 'leave_days',
      start_date_field: cfg.start_date_field || cfg.startDateField || 'start_date',
      end_date_field: cfg.end_date_field || cfg.endDateField || 'end_date',
      balance_entity: cfg.balance_entity || cfg.balanceEntity || 'leave_balances',
      fiscal_year_field: cfg.fiscal_year_field || cfg.fiscalYearField || 'year',
      entitlement_field: cfg.entitlement_field || cfg.entitlementField || 'annual_entitlement',
      accrued_field: cfg.accrued_field || cfg.accruedField || 'accrued_days',
      consumed_field: cfg.consumed_field || cfg.consumedField || 'consumed_days',
      carry_forward_field: cfg.carry_forward_field || cfg.carryForwardField || 'carry_forward_days',
      available_field: cfg.available_field || cfg.availableField || 'available_days',
      default_entitlement: Number(cfg.default_entitlement || cfg.defaultEntitlement || 18) || 18,
    };
  }

  _hrLeaveApprovalErr(message, statusCode = 400, details = null) {
    const err = new Error(message);
    err.statusCode = statusCode;
    if (details) err.details = details;
    return err;
  }

  _hrLeaveApprovalAssertTransition(currentStatus, nextStatus, cfg) {
    if (!cfg.enforce_transitions) return;
    if (!currentStatus || !nextStatus || String(currentStatus) === String(nextStatus)) return;
    const transitions = cfg.transitions && typeof cfg.transitions === 'object' ? cfg.transitions : {};
    const allowed = Array.isArray(transitions[currentStatus]) ? transitions[currentStatus] : [];
    if (!allowed.includes(nextStatus)) {
      throw this._hrLeaveApprovalErr(`Invalid leave status transition: ${currentStatus} -> ${nextStatus}`, 409);
    }
  }

  async listPendingLeaveApprovals(filter = {}) {
    const cfg = this._hrLeaveApprovalCfg();
    if (this.slug !== cfg.leave_entity) {
      throw this._hrLeaveApprovalErr(
        `Leave approval listing can only run on '${cfg.leave_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }
    const where = {
      [cfg.status_field]: 'Pending',
    };
    if (filter && Object.prototype.hasOwnProperty.call(filter, cfg.approver_field)) {
      where[cfg.approver_field] = filter[cfg.approver_field];
    } else if (filter && Object.prototype.hasOwnProperty.call(filter, 'approver_id')) {
      where[cfg.approver_field] = filter.approver_id;
    } else if (filter && Object.prototype.hasOwnProperty.call(filter, 'approverId')) {
      where[cfg.approver_field] = filter.approverId;
    }
    return this.repository.findAll(cfg.leave_entity, where);
  }

  async _hrApplyLeaveDecision(leaveId, targetStatus, payload = {}) {
    const cfg = this._hrLeaveApprovalCfg();
    if (this.slug !== cfg.leave_entity) {
      throw this._hrLeaveApprovalErr(
        `Leave decision can only run on '${cfg.leave_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }
    if (!cfg.statuses.includes(targetStatus)) {
      throw this._hrLeaveApprovalErr(`Unsupported target status '${targetStatus}'`, 400);
    }

    return this.repository.withTransaction(async (client) => {
      if (this.repository && typeof this.repository.applyLeaveDecisionIdempotent === 'function') {
        return this.repository.applyLeaveDecisionIdempotent(
          cfg.leave_entity,
          leaveId,
          {
            target_status: targetStatus,
            status_field: cfg.status_field,
            approver_field: cfg.approver_field,
            approved_at_field: cfg.approved_at_field,
            rejected_at_field: cfg.rejected_at_field,
            cancelled_at_field: cfg.cancelled_at_field,
            rejection_reason_field: cfg.rejection_reason_field,
            decision_key_field: cfg.decision_key_field,
            transitions: cfg.transitions,
            enforce_transitions: cfg.enforce_transitions,
            decision_key: payload.decision_key || payload.decisionKey || null,
            approver_id: payload[cfg.approver_field] || payload.approver_id || payload.approverId || null,
            reason: payload.reason || payload[cfg.rejection_reason_field] || null,
            consume_on_approval: cfg.consume_on_approval,
            employee_field: cfg.employee_field,
            leave_type_field: cfg.leave_type_field,
            days_field: cfg.days_field,
            start_date_field: cfg.start_date_field,
            end_date_field: cfg.end_date_field,
            balance_entity: cfg.balance_entity,
            fiscal_year_field: cfg.fiscal_year_field,
            entitlement_field: cfg.entitlement_field,
            accrued_field: cfg.accrued_field,
            consumed_field: cfg.consumed_field,
            carry_forward_field: cfg.carry_forward_field,
            available_field: cfg.available_field,
            default_entitlement: cfg.default_entitlement,
          },
          client
        );
      }

      const leave = await this.repository.findByIdForUpdate(cfg.leave_entity, leaveId, client);
      if (!leave) throw this._hrLeaveApprovalErr('Leave request not found', 404);

      const currentStatus = String(leave[cfg.status_field] || 'Pending');
      this._hrLeaveApprovalAssertTransition(currentStatus, targetStatus, cfg);
      const nowIso = new Date().toISOString();
      const patch = {
        [cfg.status_field]: targetStatus,
      };
      if (payload.decision_key || payload.decisionKey) {
        patch[cfg.decision_key_field] = payload.decision_key || payload.decisionKey;
      }
      if (payload[cfg.approver_field] || payload.approver_id || payload.approverId) {
        patch[cfg.approver_field] = payload[cfg.approver_field] || payload.approver_id || payload.approverId;
      }
      if (targetStatus === 'Approved') patch[cfg.approved_at_field] = nowIso;
      if (targetStatus === 'Rejected') {
        patch[cfg.rejected_at_field] = nowIso;
        patch[cfg.rejection_reason_field] = payload.reason || null;
      }
      if (targetStatus === 'Cancelled') patch[cfg.cancelled_at_field] = nowIso;

      const updatedLeave = await this.repository.updateWithClient(cfg.leave_entity, leaveId, patch, client);

      let balanceResult = null;
      if (targetStatus === 'Approved' && cfg.consume_on_approval) {
        const leaveCfg = this._hrLeaveCfg();
        const empId = leave[cfg.employee_field];
        const leaveType = String(leave[cfg.leave_type_field] || '').trim();
        const startDate = leave[cfg.start_date_field];
        const endDate = leave[cfg.end_date_field];
        const leaveDays = this._hrLeaveRound(
          leave[cfg.days_field] ?? this._hrLeaveCalcDays(startDate, endDate, leaveCfg)
        );
        if (empId && leaveType && Number.isFinite(leaveDays) && leaveDays > 0) {
          const fiscalYear = this._hrLeaveYearFromDates(startDate, endDate);
          await this._hrLeaveFindOrCreateBalance(client, leaveCfg, empId, leaveType, fiscalYear, {});
          const balanceMatches = await this.repository.findAllWithClient(leaveCfg.balance_entity, {
            [leaveCfg.employee_field]: empId,
            [leaveCfg.leave_type_field]: leaveType,
            [leaveCfg.fiscal_year_field]: fiscalYear,
          }, client);
          const bal = Array.isArray(balanceMatches) && balanceMatches.length ? balanceMatches[0] : null;
          if (bal) {
            const consumed = this._hrLeaveRound((bal[leaveCfg.consumed_field] || 0) + leaveDays);
            const available = this._hrLeaveRound((bal[leaveCfg.available_field] || 0) - leaveDays);
            balanceResult = await this.repository.updateWithClient(leaveCfg.balance_entity, bal.id, {
              [leaveCfg.consumed_field]: consumed,
              [leaveCfg.available_field]: available,
            }, client);
          }
        }
      }

      return {
        leave: updatedLeave,
        idempotent: false,
        balance: balanceResult,
      };
    });
  }

  async approveLeaveRequest(leaveId, payload = {}) {
    return this._hrApplyLeaveDecision(leaveId, 'Approved', payload);
  }

  async rejectLeaveRequest(leaveId, payload = {}) {
    return this._hrApplyLeaveDecision(leaveId, 'Rejected', payload);
  }

  async cancelLeaveRequest(leaveId, payload = {}) {
    return this._hrApplyLeaveDecision(leaveId, 'Cancelled', payload);
  }
    
    
  _hrLeaveCfg() {
    const cfg =
      this.mixinConfig?.hr_leave_balance ||
      this.mixinConfig?.hrLeaveBalance ||
      this.mixinConfig?.hr_leave_engine ||
      this.mixinConfig?.hrLeaveEngine ||
      {};
    return {
      employee_entity: cfg.employee_entity || cfg.employeeEntity || 'employees',
      leave_entity: cfg.leave_entity || cfg.leaveEntity || 'leaves',
      balance_entity: cfg.balance_entity || cfg.balanceEntity || 'leave_balances',
      employee_field: cfg.employee_field || cfg.employeeField || 'employee_id',
      leave_type_field: cfg.leave_type_field || cfg.leaveTypeField || 'leave_type',
      start_date_field: cfg.start_date_field || cfg.startDateField || 'start_date',
      end_date_field: cfg.end_date_field || cfg.endDateField || 'end_date',
      days_field: cfg.days_field || cfg.daysField || 'leave_days',
      status_field: cfg.status_field || cfg.statusField || 'status',
      entitlement_field: cfg.entitlement_field || cfg.entitlementField || 'annual_entitlement',
      accrued_field: cfg.accrued_field || cfg.accruedField || 'accrued_days',
      consumed_field: cfg.consumed_field || cfg.consumedField || 'consumed_days',
      carry_forward_field: cfg.carry_forward_field || cfg.carryForwardField || 'carry_forward_days',
      available_field: cfg.available_field || cfg.availableField || 'available_days',
      fiscal_year_field: cfg.fiscal_year_field || cfg.fiscalYearField || 'year',
      last_accrual_at_field: cfg.last_accrual_at_field || cfg.lastAccrualAtField || 'last_accrual_at',
      default_entitlement: Number(cfg.default_entitlement || cfg.defaultEntitlement || 18) || 18,
      auto_create_balance:
        cfg.auto_create_balance !== false &&
        cfg.autoCreateBalance !== false,
      work_days:
        (Array.isArray(cfg.work_days) && cfg.work_days.length ? cfg.work_days : null) ||
        (Array.isArray(cfg.workDays) && cfg.workDays.length ? cfg.workDays : null) ||
        ["Mon"],
    };
  }

  _hrLeaveErr(message, statusCode = 400, details = null) {
    const err = new Error(message);
    err.statusCode = statusCode;
    if (details) err.details = details;
    return err;
  }

  _hrLeaveRound(rawValue) {
    const num = Number(rawValue);
    if (!Number.isFinite(num)) return 0;
    return Number(num.toFixed(2));
  }

  _hrLeaveWeekdayToken(dateObj) {
    const idx = dateObj.getUTCDay();
    const map = ['Sun', 'Mon', 'Tue', 'Wed', 'Thu', 'Fri', 'Sat'];
    return map[idx] || 'Mon';
  }

  _hrLeaveCalcDays(startRaw, endRaw, cfg) {
    if (!startRaw || !endRaw) return null;
    const start = new Date(startRaw);
    const end = new Date(endRaw);
    if (!Number.isFinite(start.getTime()) || !Number.isFinite(end.getTime())) {
      throw this._hrLeaveErr('Invalid leave date range', 400);
    }
    if (end.getTime() < start.getTime()) {
      throw this._hrLeaveErr('Leave end date must be on or after start date', 400);
    }
    const allowed = new Set((Array.isArray(cfg.work_days) ? cfg.work_days : []).map((x) => String(x)));
    const cursor = new Date(Date.UTC(start.getUTCFullYear(), start.getUTCMonth(), start.getUTCDate()));
    const stop = new Date(Date.UTC(end.getUTCFullYear(), end.getUTCMonth(), end.getUTCDate()));
    let total = 0;
    while (cursor.getTime() <= stop.getTime()) {
      const token = this._hrLeaveWeekdayToken(cursor);
      if (!allowed.size || allowed.has(token)) total += 1;
      cursor.setUTCDate(cursor.getUTCDate() + 1);
    }
    return total;
  }

  _hrLeaveYearFromDates(startRaw, endRaw) {
    const start = startRaw ? new Date(startRaw) : null;
    const end = endRaw ? new Date(endRaw) : null;
    if (start && Number.isFinite(start.getTime())) return String(start.getUTCFullYear());
    if (end && Number.isFinite(end.getTime())) return String(end.getUTCFullYear());
    return String(new Date().getUTCFullYear());
  }

  async recalculateLeaveDays(leaveId, payload = {}) {
    const cfg = this._hrLeaveCfg();
    if (this.slug !== cfg.leave_entity) {
      throw this._hrLeaveErr(
        `Leave day recalculation can only run on '${cfg.leave_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    return this.repository.withTransaction(async (client) => {
      const row = await this.repository.findByIdForUpdate(cfg.leave_entity, leaveId, client);
      if (!row) throw this._hrLeaveErr('Leave request not found', 404);

      const start = payload[cfg.start_date_field] ?? row[cfg.start_date_field];
      const end = payload[cfg.end_date_field] ?? row[cfg.end_date_field];
      const days = this._hrLeaveCalcDays(start, end, cfg);
      const updated = await this.repository.updateWithClient(cfg.leave_entity, leaveId, {
        [cfg.days_field]: days,
      }, client);
      return {
        leave: updated,
        operation: 'recalculate_days',
      };
    });
  }

  async _hrLeaveFindOrCreateBalance(client, cfg, employeeId, leaveType, fiscalYear, seed = {}) {
    const existing = await this.repository.findAllWithClient(cfg.balance_entity, {
      [cfg.employee_field]: employeeId,
      [cfg.leave_type_field]: leaveType,
      [cfg.fiscal_year_field]: fiscalYear,
    }, client);
    if (Array.isArray(existing) && existing.length > 0) {
      return existing[0];
    }

    if (!cfg.auto_create_balance) {
      throw this._hrLeaveErr('Leave balance record is missing and auto-create is disabled', 404);
    }

    const entitlement = this._hrLeaveRound(seed[cfg.entitlement_field] ?? cfg.default_entitlement);
    const accrued = this._hrLeaveRound(seed[cfg.accrued_field] ?? entitlement);
    const consumed = this._hrLeaveRound(seed[cfg.consumed_field] ?? 0);
    const carryForward = this._hrLeaveRound(seed[cfg.carry_forward_field] ?? 0);
    const available = this._hrLeaveRound(
      seed[cfg.available_field] !== undefined
        ? seed[cfg.available_field]
        : (entitlement + accrued + carryForward - consumed)
    );

    return this.repository.createWithClient(cfg.balance_entity, {
      [cfg.employee_field]: employeeId,
      [cfg.leave_type_field]: leaveType,
      [cfg.fiscal_year_field]: fiscalYear,
      [cfg.entitlement_field]: entitlement,
      [cfg.accrued_field]: accrued,
      [cfg.consumed_field]: consumed,
      [cfg.carry_forward_field]: carryForward,
      [cfg.available_field]: available,
      [cfg.last_accrual_at_field]: new Date().toISOString(),
      note: seed.note || null,
    }, client);
  }

  async getEmployeeLeaveBalance(employeeId, filter = {}) {
    const cfg = this._hrLeaveCfg();
    if (this.slug !== cfg.employee_entity && this.slug !== cfg.leave_entity) {
      throw this._hrLeaveErr(
        `Leave balance query can run on '${cfg.employee_entity}' or '${cfg.leave_entity}'. Current entity: '${this.slug}'.`,
        400
      );
    }
    const where = {
      [cfg.employee_field]: employeeId,
    };
    if (filter && filter.leave_type) where[cfg.leave_type_field] = filter.leave_type;
    if (filter && filter[cfg.leave_type_field]) where[cfg.leave_type_field] = filter[cfg.leave_type_field];
    if (filter && filter.year) where[cfg.fiscal_year_field] = String(filter.year);
    if (filter && filter[cfg.fiscal_year_field]) where[cfg.fiscal_year_field] = String(filter[cfg.fiscal_year_field]);
    return this.repository.findAll(cfg.balance_entity, where);
  }

  async _hrLeaveApplyBalanceChange(employeeId, payload = {}, mode = 'accrue') {
    const cfg = this._hrLeaveCfg();
    const leaveType = String(
      payload.leave_type ||
      payload.leaveType ||
      payload[cfg.leave_type_field] ||
      'Annual'
    ).trim();
    if (!leaveType) throw this._hrLeaveErr('leave_type is required', 400);
    const fiscalYear = String(
      payload.year ||
      payload.fiscal_year ||
      payload.fiscalYear ||
      payload[cfg.fiscal_year_field] ||
      new Date().getUTCFullYear()
    );
    const amount = Number(
      payload.amount ??
      payload.delta ??
      payload.accrued_delta ??
      payload.available_delta
    );
    if (!Number.isFinite(amount) || amount === 0) {
      throw this._hrLeaveErr('amount must be non-zero', 400);
    }

    return this.repository.withTransaction(async (client) => {
      await this._hrLeaveFindOrCreateBalance(client, cfg, employeeId, leaveType, fiscalYear, payload);

      if (this.repository && typeof this.repository.atomicAdjustLeaveBalance === 'function') {
        const adjusted = await this.repository.atomicAdjustLeaveBalance(
          cfg.balance_entity,
          {
            [cfg.employee_field]: employeeId,
            [cfg.leave_type_field]: leaveType,
            [cfg.fiscal_year_field]: fiscalYear,
          },
          {
            employee_field: cfg.employee_field,
            leave_type_field: cfg.leave_type_field,
            fiscal_year_field: cfg.fiscal_year_field,
            entitlement_field: cfg.entitlement_field,
            accrued_field: cfg.accrued_field,
            consumed_field: cfg.consumed_field,
            carry_forward_field: cfg.carry_forward_field,
            available_field: cfg.available_field,
            entitlement_delta: mode === 'accrue' ? 0 : 0,
            accrued_delta: mode === 'accrue' ? amount : 0,
            available_delta: mode === 'adjust' ? amount : 0,
            last_accrual_at_field: cfg.last_accrual_at_field,
            create_if_missing: true,
            default_entitlement: cfg.default_entitlement,
            note: payload.note || null,
          },
          client
        );
        return {
          balance: adjusted,
          operation: mode,
        };
      }

      const matches = await this.repository.findAllWithClient(cfg.balance_entity, {
        [cfg.employee_field]: employeeId,
        [cfg.leave_type_field]: leaveType,
        [cfg.fiscal_year_field]: fiscalYear,
      }, client);
      const balance = Array.isArray(matches) && matches.length ? matches[0] : null;
      if (!balance) throw this._hrLeaveErr('Leave balance not found', 404);

      const accrued = this._hrLeaveRound(balance[cfg.accrued_field] || 0);
      const available = this._hrLeaveRound(balance[cfg.available_field] || 0);
      const patch = {
        [cfg.last_accrual_at_field]: new Date().toISOString(),
      };
      if (mode === 'accrue') {
        patch[cfg.accrued_field] = this._hrLeaveRound(accrued + amount);
      }
      if (mode === 'adjust') {
        patch[cfg.available_field] = this._hrLeaveRound(available + amount);
      }
      const updated = await this.repository.updateWithClient(cfg.balance_entity, balance.id, patch, client);
      return {
        balance: updated,
        operation: mode,
      };
    });
  }

  async accrueLeaveBalance(employeeId, payload = {}) {
    const cfg = this._hrLeaveCfg();
    if (this.slug !== cfg.employee_entity) {
      throw this._hrLeaveErr(
        `Leave accrual can only run on '${cfg.employee_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }
    return this._hrLeaveApplyBalanceChange(employeeId, payload, 'accrue');
  }

  async adjustLeaveBalance(employeeId, payload = {}) {
    const cfg = this._hrLeaveCfg();
    if (this.slug !== cfg.employee_entity) {
      throw this._hrLeaveErr(
        `Leave adjustment can only run on '${cfg.employee_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }
    return this._hrLeaveApplyBalanceChange(employeeId, payload, 'adjust');
  }

  async applyLeaveConsumption(leaveId, payload = {}) {
    const cfg = this._hrLeaveCfg();
    if (this.slug !== cfg.leave_entity) {
      throw this._hrLeaveErr(
        `Leave consumption can only run on '${cfg.leave_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    return this.repository.withTransaction(async (client) => {
      const leave = await this.repository.findByIdForUpdate(cfg.leave_entity, leaveId, client);
      if (!leave) throw this._hrLeaveErr('Leave request not found', 404);

      const employeeId = leave[cfg.employee_field];
      if (!employeeId) throw this._hrLeaveErr('Leave request is missing employee reference', 400);

      const leaveType = String(leave[cfg.leave_type_field] || '').trim();
      if (!leaveType) throw this._hrLeaveErr('Leave request is missing leave type', 400);

      const start = payload[cfg.start_date_field] ?? leave[cfg.start_date_field];
      const end = payload[cfg.end_date_field] ?? leave[cfg.end_date_field];
      const leaveDays = this._hrLeaveRound(
        payload[cfg.days_field] ??
        leave[cfg.days_field] ??
        this._hrLeaveCalcDays(start, end, cfg)
      );
      if (!Number.isFinite(leaveDays) || leaveDays <= 0) {
        throw this._hrLeaveErr('Leave days must be greater than zero', 400);
      }

      const fiscalYear = String(
        payload[cfg.fiscal_year_field] ||
        this._hrLeaveYearFromDates(start, end)
      );

      await this._hrLeaveFindOrCreateBalance(client, cfg, employeeId, leaveType, fiscalYear, payload);
      let balance;
      if (this.repository && typeof this.repository.atomicAdjustLeaveBalance === 'function') {
        balance = await this.repository.atomicAdjustLeaveBalance(
          cfg.balance_entity,
          {
            [cfg.employee_field]: employeeId,
            [cfg.leave_type_field]: leaveType,
            [cfg.fiscal_year_field]: fiscalYear,
          },
          {
            employee_field: cfg.employee_field,
            leave_type_field: cfg.leave_type_field,
            fiscal_year_field: cfg.fiscal_year_field,
            entitlement_field: cfg.entitlement_field,
            accrued_field: cfg.accrued_field,
            consumed_field: cfg.consumed_field,
            carry_forward_field: cfg.carry_forward_field,
            available_field: cfg.available_field,
            consumed_delta: leaveDays,
            available_delta: -leaveDays,
            create_if_missing: true,
            default_entitlement: cfg.default_entitlement,
          },
          client
        );
      }

      const updatedLeave = await this.repository.updateWithClient(cfg.leave_entity, leaveId, {
        [cfg.days_field]: leaveDays,
      }, client);

      return {
        leave: updatedLeave,
        balance: balance || null,
      };
    });
  }
    
}

module.exports = LeavesService;
