// brick-library/backend-bricks/core/BaseController.js.hbs
const RepositoryProvider = require('../repository/PostgresProvider');
const ProductsService = require('../services/ProductsService');

class ProductsController {
  constructor() {
    this.repository = new RepositoryProvider();
    this.service = new ProductsService(this.repository, {"InventoryMixin":{},"inventory":{},"InventoryLifecycleMixin":{},"inventory_lifecycle":{},"inventoryLifecycle":{},"InventoryReservationMixin":{"reservation_entity":"stock_reservations","item_field":"item_id","quantity_field":"quantity","status_field":"status","reserved_field":"reserved_quantity","committed_field":"committed_quantity","available_field":"available_quantity","enabled":true,"stock_entity":"products","stock_quantity_field":"quantity"},"inventory_reservation":{"reservation_entity":"stock_reservations","item_field":"item_id","quantity_field":"quantity","status_field":"status","reserved_field":"reserved_quantity","committed_field":"committed_quantity","available_field":"available_quantity","enabled":true,"stock_entity":"products","stock_quantity_field":"quantity"},"inventoryReservation":{"reservation_entity":"stock_reservations","item_field":"item_id","quantity_field":"quantity","status_field":"status","reserved_field":"reserved_quantity","committed_field":"committed_quantity","available_field":"available_quantity","enabled":true,"stock_entity":"products","stock_quantity_field":"quantity"},"InventoryTransactionSafetyMixin":{"quantity_field":"quantity","enabled":true,"stock_entity":"products","movement_entity":"stock_movements","allow_negative_stock":true,"fields":{"item_ref":"item_id","qty":"quantity","type":"movement_type","location":"location_id","reason":"reason","reference_number":"reference_number","date":"movement_date","from_location":"from_location_id","to_location":"to_location_id"},"movement_types":{"receive":"IN","issue":"OUT","adjust":"ADJUSTMENT","transfer_out":"TRANSFER_OUT","transfer_in":"TRANSFER_IN"}},"inventory_transaction_safety":{"quantity_field":"quantity","enabled":true,"stock_entity":"products","movement_entity":"stock_movements","allow_negative_stock":true,"fields":{"item_ref":"item_id","qty":"quantity","type":"movement_type","location":"location_id","reason":"reason","reference_number":"reference_number","date":"movement_date","from_location":"from_location_id","to_location":"to_location_id"},"movement_types":{"receive":"IN","issue":"OUT","adjust":"ADJUSTMENT","transfer_out":"TRANSFER_OUT","transfer_in":"TRANSFER_IN"}},"inventoryTransactionSafety":{"quantity_field":"quantity","enabled":true,"stock_entity":"products","movement_entity":"stock_movements","allow_negative_stock":true,"fields":{"item_ref":"item_id","qty":"quantity","type":"movement_type","location":"location_id","reason":"reason","reference_number":"reference_number","date":"movement_date","from_location":"from_location_id","to_location":"to_location_id"},"movement_types":{"receive":"IN","issue":"OUT","adjust":"ADJUSTMENT","transfer_out":"TRANSFER_OUT","transfer_in":"TRANSFER_IN"}},"InventoryReservationWorkflowMixin":{"reservation_entity":"stock_reservations","item_field":"item_id","quantity_field":"quantity","status_field":"status","reserved_field":"reserved_quantity","committed_field":"committed_quantity","available_field":"available_quantity","enabled":true,"stock_entity":"products","stock_quantity_field":"quantity"},"inventory_reservation_workflow":{"reservation_entity":"stock_reservations","item_field":"item_id","quantity_field":"quantity","status_field":"status","reserved_field":"reserved_quantity","committed_field":"committed_quantity","available_field":"available_quantity","enabled":true,"stock_entity":"products","stock_quantity_field":"quantity"},"inventoryReservationWorkflow":{"reservation_entity":"stock_reservations","item_field":"item_id","quantity_field":"quantity","status_field":"status","reserved_field":"reserved_quantity","committed_field":"committed_quantity","available_field":"available_quantity","enabled":true,"stock_entity":"products","stock_quantity_field":"quantity"},"BatchTrackingMixin":{},"batch_tracking":{},"batchTracking":{},"SerialTrackingMixin":{},"serial_tracking":{},"serialTracking":{},"LocationMixin":{},"location":{}});
  }

  _errorPayload(error) {
    return {
      error: error.message,
      field_errors: error.fieldErrors || undefined,
      dependents: error.dependents || undefined,
      details: error.details || undefined,
    };
  }

  _resolveStatus(error, fallback = 500) {
    return error.statusCode || error.status || fallback;
  }

  async runAction(req, res, methodName, ...args) {
    try {
      const method = this.service && this.service[methodName];
      if (typeof method !== 'function') {
        return res.status(404).json({ error: `Action '${methodName}' is not available` });
      }
      const result = await method.apply(this.service, args);
      if (result === undefined) {
        return res.status(204).send();
      }
      return res.json(result);
    } catch (error) {
      const status = this._resolveStatus(error, 400);
      return res.status(status).json(this._errorPayload(error));
    }
  }

  async getAll(req, res) {
    try {
      const items = await this.service.findAll(req.query);
      res.json(items);
    } catch (error) {
      res.status(500).json(this._errorPayload(error));
    }
  }

  async getById(req, res) {
    try {
      const item = await this.service.findById(req.params.id);
      if (!item) return res.status(404).json({ error: 'Not found' });
      res.json(item);
    } catch (error) {
      res.status(500).json(this._errorPayload(error));
    }
  }

  async create(req, res) {
    try {
      const item = await this.service.create(req.body);
      res.status(201).json(item);
    } catch (error) {
      const status = this._resolveStatus(error, 400);
      res.status(status).json(this._errorPayload(error));
    }
  }

  async update(req, res) {
    try {
      const item = await this.service.update(req.params.id, req.body);
      if (!item) return res.status(404).json({ error: 'Not found' });
      res.json(item);
    } catch (error) {
      const status = this._resolveStatus(error, 400);
      res.status(status).json(this._errorPayload(error));
    }
  }

  async delete(req, res) {
    try {
      const result = await this.service.delete(req.params.id);
      if (!result) return res.status(404).json({ error: 'Not found' });
      res.status(204).send();
    } catch (error) {
      const status = this._resolveStatus(error, 500);
      res.status(status).json(this._errorPayload(error));
    }
  }
}

module.exports = ProductsController;

