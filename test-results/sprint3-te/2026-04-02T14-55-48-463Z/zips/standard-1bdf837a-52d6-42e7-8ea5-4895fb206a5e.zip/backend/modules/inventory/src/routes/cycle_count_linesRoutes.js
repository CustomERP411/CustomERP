
const express = require('express');
const router = express.Router();
const Cycle_count_linesController = require('../controllers/Cycle_count_linesController');

const controller = new Cycle_count_linesController();

router.get('/', (req, res) => controller.getAll(req, res));
router.get('/:id', (req, res) => controller.getById(req, res));
router.post('/', (req, res) => controller.create(req, res));
router.put('/:id', (req, res) => controller.update(req, res));
router.delete('/:id', (req, res) => controller.delete(req, res));


module.exports = router;
