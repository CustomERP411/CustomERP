
const express = require('express');
const router = express.Router();
const Purchase_order_itemsController = require('../controllers/Purchase_order_itemsController');

const controller = new Purchase_order_itemsController();

router.get('/', (req, res) => controller.getAll(req, res));
router.get('/:id', (req, res) => controller.getById(req, res));
router.post('/', (req, res) => controller.create(req, res));
router.put('/:id', (req, res) => controller.update(req, res));
router.delete('/:id', (req, res) => controller.delete(req, res));


module.exports = router;
