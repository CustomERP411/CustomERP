
const express = require('express');
const router = express.Router();
const Stock_reservationsController = require('../controllers/Stock_reservationsController');

const controller = new Stock_reservationsController();

router.get('/', (req, res) => controller.getAll(req, res));
router.get('/:id', (req, res) => controller.getById(req, res));
router.post('/', (req, res) => controller.create(req, res));
router.put('/:id', (req, res) => controller.update(req, res));
router.delete('/:id', (req, res) => controller.delete(req, res));


module.exports = router;
