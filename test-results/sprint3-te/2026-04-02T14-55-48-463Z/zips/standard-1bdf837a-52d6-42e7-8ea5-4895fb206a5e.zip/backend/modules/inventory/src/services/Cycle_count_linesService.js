// brick-library/backend-bricks/core/BaseService.js.hbs
class Cycle_count_linesService {
  constructor(repository, mixinConfig = {}) {
    this.repository = repository;
    this.slug = 'cycle_count_lines';
    this.mixinConfig = mixinConfig && typeof mixinConfig === 'object' ? mixinConfig : {};
  }

  async create(data) {
    // @HOOK: BEFORE_CREATE_VALIDATION
    
      // Schema-driven validation (generated)
      const fieldErrors = {};
      const isMissing = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
      const isMissingNonString = (v) => v === undefined || v === null;

      const __refIdSets = {};
      const getRefIdSet = async (slug) => {
        if (__refIdSets[slug]) return __refIdSets[slug];
        const all = await this.repository.findAll(slug);
        __refIdSets[slug] = new Set(all.map((x) => x.id));
        return __refIdSets[slug];
      };

      if (isMissing(data['cycle_count_session_id'])) fieldErrors['cycle_count_session_id'] = 'Cycle Count Session Id is required';

      if (!isMissing(data['cycle_count_session_id'])) {
        const ids = await getRefIdSet('cycle_count_sessions');
        if (!ids.has(String(data['cycle_count_session_id']))) fieldErrors['cycle_count_session_id'] = 'Cycle Count Session Id has an invalid reference';
      }

      if (isMissing(data['item_id'])) fieldErrors['item_id'] = 'Item Id is required';

      if (!isMissing(data['item_id'])) {
        const ids = await getRefIdSet('products');
        if (!ids.has(String(data['item_id']))) fieldErrors['item_id'] = 'Item Id has an invalid reference';
      }

      if (!isMissing(data['expected_quantity'])) {
        const num = typeof data['expected_quantity'] === 'number' ? data['expected_quantity'] : Number(data['expected_quantity']);
        if (Number.isNaN(num)) {
          fieldErrors['expected_quantity'] = 'Expected Quantity must be a number';
        } else {

          if (!Number.isInteger(num)) fieldErrors['expected_quantity'] = 'Expected Quantity must be an integer';

        }
      }

      if (!isMissing(data['counted_quantity'])) {
        const num = typeof data['counted_quantity'] === 'number' ? data['counted_quantity'] : Number(data['counted_quantity']);
        if (Number.isNaN(num)) {
          fieldErrors['counted_quantity'] = 'Counted Quantity must be a number';
        } else {

          if (!Number.isInteger(num)) fieldErrors['counted_quantity'] = 'Counted Quantity must be an integer';

        }
      }

      if (!isMissing(data['variance_quantity'])) {
        const num = typeof data['variance_quantity'] === 'number' ? data['variance_quantity'] : Number(data['variance_quantity']);
        if (Number.isNaN(num)) {
          fieldErrors['variance_quantity'] = 'Variance Quantity must be a number';
        } else {

          if (!Number.isInteger(num)) fieldErrors['variance_quantity'] = 'Variance Quantity must be an integer';

        }
      }

      const __allowed_status = ['Pending', 'Counted', 'Posted'];
      if (!isMissing(data['status']) && !__allowed_status.includes(String(data['status']))) fieldErrors['status'] = 'Status must be one of: Pending, Counted, Posted';

      if (Object.keys(fieldErrors).length) {
        const err = new Error('Validation failed');
        err.statusCode = 400;
        err.fieldErrors = fieldErrors;
        throw err;
      }

    
      {
      const __cfg = this.mixinConfig?.inventory_reservation || this.mixinConfig?.inventoryReservation || {};
            const __qtyField = __cfg.quantity_field || __cfg.quantityField || 'quantity';
            const __reservedField = __cfg.reserved_field || __cfg.reservedField || 'reserved_quantity';
            const __committedField = __cfg.committed_field || __cfg.committedField || 'committed_quantity';
            const __availableField = __cfg.available_field || __cfg.availableField || 'available_quantity';
            const __autoAvailable = __cfg.auto_calculate_available === true || __cfg.autoCalculateAvailable === true;
            const __enforce = __cfg.enforce !== false && __cfg.enforceRules !== false;
      
            const __readNumber = (value) => {
              if (value === undefined || value === null || value === '') return null;
              const num = Number(value);
              return Number.isNaN(num) ? null : num;
            };
      
            const __qty = __readNumber(data[__qtyField]);
            const __reserved = __readNumber(data[__reservedField]);
            const __committed = __readNumber(data[__committedField]);
            const __hasReservations = __reserved !== null || __committed !== null;
      
            if (__enforce && __qty !== null && __hasReservations) {
              const __reservedVal = __reserved ?? 0;
              const __committedVal = __committed ?? 0;
              if (__reservedVal < 0 || __committedVal < 0) {
                throw new Error('Reserved and committed quantities cannot be negative');
              }
              if (__reservedVal + __committedVal > __qty) {
                throw new Error('Reserved + committed quantities cannot exceed on-hand quantity');
              }
            }
      
            if (__autoAvailable && __qty !== null && __hasReservations && __availableField) {
              const __reservedVal = __reserved ?? 0;
              const __committedVal = __committed ?? 0;
              data[__availableField] = __qty - __reservedVal - __committedVal;
            }
      }

    
    // @HOOK: BEFORE_CREATE_TRANSFORMATION
    
      {
      const __cfg =
              this.mixinConfig?.inventory_cycle_count_line ||
              this.mixinConfig?.inventoryCycleCountLine ||
              this.mixinConfig?.inventory_cycle_count ||
              this.mixinConfig?.inventoryCycleCount ||
              {};
            const __expectedField = __cfg.line_expected_field || __cfg.lineExpectedField || 'expected_quantity';
            const __countedField = __cfg.line_counted_field || __cfg.lineCountedField || 'counted_quantity';
            const __varianceField = __cfg.line_variance_field || __cfg.lineVarianceField || 'variance_quantity';
            const __statusField = __cfg.line_status_field || __cfg.lineStatusField || 'status';
      
            const __toNum = (raw, fieldName) => {
              const n = Number(raw);
              if (!Number.isFinite(n)) throw new Error(`${fieldName} must be numeric`);
              return n;
            };
      
            if (data[__expectedField] === undefined || data[__expectedField] === null || data[__expectedField] === '') {
              data[__expectedField] = 0;
            }
            const __expected = __toNum(data[__expectedField], __expectedField);
            if (__expected < 0) throw new Error(`${__expectedField} cannot be negative`);
      
            if (data[__statusField] === undefined) {
              data[__statusField] = 'Pending';
            }
      
            const __hasCount =
              data[__countedField] !== undefined &&
              data[__countedField] !== null &&
              data[__countedField] !== '';
            if (__hasCount) {
              const __counted = __toNum(data[__countedField], __countedField);
              if (__counted < 0) throw new Error(`${__countedField} cannot be negative`);
              data[__varianceField] = __counted - __expected;
              data[__statusField] = 'Counted';
            }
      }

    
      {
      const __cfg = this.mixinConfig?.inventory_lifecycle || this.mixinConfig?.inventoryLifecycle || {};
            const __statusField = __cfg.status_field || __cfg.statusField || 'status';
            const __statuses = Array.isArray(__cfg.statuses) && __cfg.statuses.length ? __cfg.statuses : null;
            const __defaultStatus = __cfg.default_status || __cfg.defaultStatus;
      
            if (data && data[__statusField] === undefined && __defaultStatus) {
              data[__statusField] = __defaultStatus;
            }
      
            if (__statuses && data && data[__statusField] !== undefined && !__statuses.includes(data[__statusField])) {
              throw new Error(`${__statusField} must be one of: ${__statuses.join(', ')}`);
            }
      }

    
      {
      // InventoryMixin: Initialize quantity if not present
            if (data.quantity === undefined || data.quantity === null) {
              data.quantity = 0;
            }
            data.quantity = Number(data.quantity);
            if (isNaN(data.quantity)) throw new Error('Quantity must be a number');
      }

    
    const result = await this.repository.create(this.slug, data);
    
    // @HOOK: AFTER_CREATE_LOGGING
    
    return result;
  }

  async update(id, data) {
    // @HOOK: BEFORE_UPDATE_VALIDATION
    
      // Schema-driven validation (generated)
      const existing = await this.repository.findById(this.slug, id);
      if (!existing) return null;
      const merged = { ...existing, ...data };

      const fieldErrors = {};
      const isMissing = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
      const isMissingNonString = (v) => v === undefined || v === null;

      const __refIdSets = {};
      const getRefIdSet = async (slug) => {
        if (__refIdSets[slug]) return __refIdSets[slug];
        const all = await this.repository.findAll(slug);
        __refIdSets[slug] = new Set(all.map((x) => x.id));
        return __refIdSets[slug];
      };

      if (isMissing(merged['cycle_count_session_id'])) fieldErrors['cycle_count_session_id'] = 'Cycle Count Session Id is required';

      if (!isMissing(merged['cycle_count_session_id'])) {
        const ids = await getRefIdSet('cycle_count_sessions');
        if (!ids.has(String(merged['cycle_count_session_id']))) fieldErrors['cycle_count_session_id'] = 'Cycle Count Session Id has an invalid reference';
      }

      if (isMissing(merged['item_id'])) fieldErrors['item_id'] = 'Item Id is required';

      if (!isMissing(merged['item_id'])) {
        const ids = await getRefIdSet('products');
        if (!ids.has(String(merged['item_id']))) fieldErrors['item_id'] = 'Item Id has an invalid reference';
      }

      if (!isMissing(merged['expected_quantity'])) {
        const num = typeof merged['expected_quantity'] === 'number' ? merged['expected_quantity'] : Number(merged['expected_quantity']);
        if (Number.isNaN(num)) {
          fieldErrors['expected_quantity'] = 'Expected Quantity must be a number';
        } else {

          if (!Number.isInteger(num)) fieldErrors['expected_quantity'] = 'Expected Quantity must be an integer';

        }
      }

      if (!isMissing(merged['counted_quantity'])) {
        const num = typeof merged['counted_quantity'] === 'number' ? merged['counted_quantity'] : Number(merged['counted_quantity']);
        if (Number.isNaN(num)) {
          fieldErrors['counted_quantity'] = 'Counted Quantity must be a number';
        } else {

          if (!Number.isInteger(num)) fieldErrors['counted_quantity'] = 'Counted Quantity must be an integer';

        }
      }

      if (!isMissing(merged['variance_quantity'])) {
        const num = typeof merged['variance_quantity'] === 'number' ? merged['variance_quantity'] : Number(merged['variance_quantity']);
        if (Number.isNaN(num)) {
          fieldErrors['variance_quantity'] = 'Variance Quantity must be a number';
        } else {

          if (!Number.isInteger(num)) fieldErrors['variance_quantity'] = 'Variance Quantity must be an integer';

        }
      }

      const __allowed_status = ['Pending', 'Counted', 'Posted'];
      if (!isMissing(merged['status']) && !__allowed_status.includes(String(merged['status']))) fieldErrors['status'] = 'Status must be one of: Pending, Counted, Posted';

      if (Object.keys(fieldErrors).length) {
        const err = new Error('Validation failed');
        err.statusCode = 400;
        err.fieldErrors = fieldErrors;
        throw err;
      }

    
      {
      const __cfg =
              this.mixinConfig?.inventory_cycle_count_line ||
              this.mixinConfig?.inventoryCycleCountLine ||
              this.mixinConfig?.inventory_cycle_count ||
              this.mixinConfig?.inventoryCycleCount ||
              {};
            const __expectedField = __cfg.line_expected_field || __cfg.lineExpectedField || 'expected_quantity';
            const __countedField = __cfg.line_counted_field || __cfg.lineCountedField || 'counted_quantity';
            const __varianceField = __cfg.line_variance_field || __cfg.lineVarianceField || 'variance_quantity';
            const __statusField = __cfg.line_status_field || __cfg.lineStatusField || 'status';
      
            const __existing = await this.repository.findById(this.slug, id);
            if (!__existing) throw new Error('Cycle count line not found');
      
            const __toNum = (raw, fieldName) => {
              const n = Number(raw);
              if (!Number.isFinite(n)) throw new Error(`${fieldName} must be numeric`);
              return n;
            };
      
            const __expectedRaw =
              data[__expectedField] !== undefined ? data[__expectedField] : __existing[__expectedField];
            const __countedRaw =
              data[__countedField] !== undefined ? data[__countedField] : __existing[__countedField];
      
            const __expected = __toNum(__expectedRaw, __expectedField);
            if (__expected < 0) throw new Error(`${__expectedField} cannot be negative`);
      
            const __hasCount =
              __countedRaw !== undefined &&
              __countedRaw !== null &&
              __countedRaw !== '';
            if (__hasCount) {
              const __counted = __toNum(__countedRaw, __countedField);
              if (__counted < 0) throw new Error(`${__countedField} cannot be negative`);
              data[__varianceField] = __counted - __expected;
              if (!data[__statusField]) data[__statusField] = 'Counted';
            } else if (!data[__statusField] && !__existing[__statusField]) {
              data[__statusField] = 'Pending';
            }
      }

    
      {
      const __cfg = this.mixinConfig?.inventory_reservation || this.mixinConfig?.inventoryReservation || {};
            const __qtyField = __cfg.quantity_field || __cfg.quantityField || 'quantity';
            const __reservedField = __cfg.reserved_field || __cfg.reservedField || 'reserved_quantity';
            const __committedField = __cfg.committed_field || __cfg.committedField || 'committed_quantity';
            const __availableField = __cfg.available_field || __cfg.availableField || 'available_quantity';
            const __autoAvailable = __cfg.auto_calculate_available === true || __cfg.autoCalculateAvailable === true;
            const __enforce = __cfg.enforce !== false && __cfg.enforceRules !== false;
      
            const __existing = await this.repository.findById(this.slug, id);
      
            const __readNumber = (value) => {
              if (value === undefined || value === null || value === '') return null;
              const num = Number(value);
              return Number.isNaN(num) ? null : num;
            };
      
            const __getValue = (field) => {
              if (data && data[field] !== undefined) return __readNumber(data[field]);
              if (__existing && __existing[field] !== undefined) return __readNumber(__existing[field]);
              return null;
            };
      
            const __qty = __getValue(__qtyField);
            const __reserved = __getValue(__reservedField);
            const __committed = __getValue(__committedField);
            const __hasReservations = __reserved !== null || __committed !== null;
      
            if (__enforce && __qty !== null && __hasReservations) {
              const __reservedVal = __reserved ?? 0;
              const __committedVal = __committed ?? 0;
              if (__reservedVal < 0 || __committedVal < 0) {
                throw new Error('Reserved and committed quantities cannot be negative');
              }
              if (__reservedVal + __committedVal > __qty) {
                throw new Error('Reserved + committed quantities cannot exceed on-hand quantity');
              }
            }
      
            if (__autoAvailable && __qty !== null && __hasReservations && __availableField) {
              const __reservedVal = __reserved ?? 0;
              const __committedVal = __committed ?? 0;
              data[__availableField] = __qty - __reservedVal - __committedVal;
            }
      }

    
      {
      const __cfg = this.mixinConfig?.inventory_lifecycle || this.mixinConfig?.inventoryLifecycle || {};
            const __statusField = __cfg.status_field || __cfg.statusField || 'status';
            const __statuses = Array.isArray(__cfg.statuses) && __cfg.statuses.length ? __cfg.statuses : null;
            const __enforceTransitions = __cfg.enforce_transitions === true || __cfg.enforceTransitions === true;
            const __customTransitions = __cfg.transitions && typeof __cfg.transitions === 'object' ? __cfg.transitions : null;
            const __defaultTransitions = {
              Draft: ['Active', 'Obsolete'],
              Active: ['Obsolete'],
              Obsolete: [],
            };
            const __transitions = __customTransitions || (__cfg.use_default_transitions === true || __cfg.useDefaultTransitions === true ? __defaultTransitions : null);
      
            if (data && data[__statusField] !== undefined) {
              const __nextStatus = data[__statusField];
              if (__statuses && !__statuses.includes(__nextStatus)) {
                throw new Error(`${__statusField} must be one of: ${__statuses.join(', ')}`);
              }
      
              if (__enforceTransitions && __transitions) {
                const __existing = await this.repository.findById(this.slug, id);
                const __currentStatus = __existing ? __existing[__statusField] : null;
      
                if (__currentStatus && __currentStatus !== __nextStatus) {
                  const __allowed = Array.isArray(__transitions[__currentStatus]) ? __transitions[__currentStatus] : [];
                  if (!__allowed.includes(__nextStatus)) {
                    throw new Error(`Invalid status transition: ${__currentStatus} -> ${__nextStatus}`);
                  }
                }
              }
            }
      }

    
      {
      // InventoryMixin: Validate quantity updates
            if (data.quantity !== undefined) {
              const newQty = Number(data.quantity);
              if (isNaN(newQty)) throw new Error('Quantity must be a number');
      
              const inventoryConfig = this.mixinConfig?.inventory || {};
              const allowNegative = inventoryConfig.allow_negative === true || inventoryConfig.allowNegative === true;
      
              // Prevent negative stock unless allow_negative is true
              if (!allowNegative && newQty < 0) {
                throw new Error('Stock cannot be negative');
              }
            }
      }

    
    const result = await this.repository.update(this.slug, id, data);
    
    // @HOOK: AFTER_UPDATE_LOGGING

    return result;
  }

  async delete(id) {
    // @HOOK: BEFORE_DELETE_VALIDATION

    const result = await this.repository.delete(this.slug, id);
    
    // @HOOK: AFTER_DELETE_LOGGING

    return result;
  }

  async findById(id) {
    return this.repository.findById(this.slug, id);
  }

  async findAll(filter = {}) {
    return this.repository.findAll(this.slug, filter);
  }

  // @HOOK: ADDITIONAL_METHODS
    
  async adjustStock(id, delta) {
    const inventoryConfig = this.mixinConfig?.inventory || {};
    const allowNegative = inventoryConfig.allow_negative === true || inventoryConfig.allowNegative === true;

    if (typeof this.repository.atomicAdjustQuantity === 'function') {
      return this.repository.atomicAdjustQuantity(this.slug, id, delta, {
        quantityField: 'quantity',
        allow_negative_stock: allowNegative,
      });
    }

    const item = await this.repository.findById(this.slug, id);
    if (!item) throw new Error('Item not found');

    const currentQty = Number(item.quantity) || 0;
    const newQty = currentQty + delta;

    if (!allowNegative && newQty < 0) {
      throw new Error(`Insufficient stock. Current: ${currentQty}, Delta: ${delta}`);
    }

    return this.repository.update(this.slug, id, { quantity: newQty });
  }
  
}

module.exports = Cycle_count_linesService;
