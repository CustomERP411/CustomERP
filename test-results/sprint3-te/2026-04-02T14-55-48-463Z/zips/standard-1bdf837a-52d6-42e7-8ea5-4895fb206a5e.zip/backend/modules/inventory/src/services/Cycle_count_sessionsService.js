// brick-library/backend-bricks/core/BaseService.js.hbs
class Cycle_count_sessionsService {
  constructor(repository, mixinConfig = {}) {
    this.repository = repository;
    this.slug = 'cycle_count_sessions';
    this.mixinConfig = mixinConfig && typeof mixinConfig === 'object' ? mixinConfig : {};
  }

  async create(data) {
    // @HOOK: BEFORE_CREATE_VALIDATION
    
      // Schema-driven validation (generated)
      const fieldErrors = {};
      const isMissing = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
      const isMissingNonString = (v) => v === undefined || v === null;

      const existingItems = await this.repository.findAll(this.slug);

      if (!isMissing(data['session_number']) && existingItems.some((it) => String(it['session_number']) === String(data['session_number']))) {
        fieldErrors['session_number'] = 'Session Number must be unique';
      }

      if (isMissing(data['status'])) fieldErrors['status'] = 'Status is required';

      const __allowed_status = ['Draft', 'InProgress', 'PendingApproval', 'Approved', 'Posted'];
      if (!isMissing(data['status']) && !__allowed_status.includes(String(data['status']))) fieldErrors['status'] = 'Status must be one of: Draft, InProgress, PendingApproval, Approved, Posted';

      if (Object.keys(fieldErrors).length) {
        const err = new Error('Validation failed');
        err.statusCode = 400;
        err.fieldErrors = fieldErrors;
        throw err;
      }

    
      {
      const __cfg = this.mixinConfig?.inventory_reservation || this.mixinConfig?.inventoryReservation || {};
            const __qtyField = __cfg.quantity_field || __cfg.quantityField || 'quantity';
            const __reservedField = __cfg.reserved_field || __cfg.reservedField || 'reserved_quantity';
            const __committedField = __cfg.committed_field || __cfg.committedField || 'committed_quantity';
            const __availableField = __cfg.available_field || __cfg.availableField || 'available_quantity';
            const __autoAvailable = __cfg.auto_calculate_available === true || __cfg.autoCalculateAvailable === true;
            const __enforce = __cfg.enforce !== false && __cfg.enforceRules !== false;
      
            const __readNumber = (value) => {
              if (value === undefined || value === null || value === '') return null;
              const num = Number(value);
              return Number.isNaN(num) ? null : num;
            };
      
            const __qty = __readNumber(data[__qtyField]);
            const __reserved = __readNumber(data[__reservedField]);
            const __committed = __readNumber(data[__committedField]);
            const __hasReservations = __reserved !== null || __committed !== null;
      
            if (__enforce && __qty !== null && __hasReservations) {
              const __reservedVal = __reserved ?? 0;
              const __committedVal = __committed ?? 0;
              if (__reservedVal < 0 || __committedVal < 0) {
                throw new Error('Reserved and committed quantities cannot be negative');
              }
              if (__reservedVal + __committedVal > __qty) {
                throw new Error('Reserved + committed quantities cannot exceed on-hand quantity');
              }
            }
      
            if (__autoAvailable && __qty !== null && __hasReservations && __availableField) {
              const __reservedVal = __reserved ?? 0;
              const __committedVal = __committed ?? 0;
              data[__availableField] = __qty - __reservedVal - __committedVal;
            }
      }

    
    // @HOOK: BEFORE_CREATE_TRANSFORMATION
    
      {
      const __cfg = this.mixinConfig?.inventory_lifecycle || this.mixinConfig?.inventoryLifecycle || {};
            const __statusField = __cfg.status_field || __cfg.statusField || 'status';
            const __statuses = Array.isArray(__cfg.statuses) && __cfg.statuses.length ? __cfg.statuses : null;
            const __defaultStatus = __cfg.default_status || __cfg.defaultStatus;
      
            if (data && data[__statusField] === undefined && __defaultStatus) {
              data[__statusField] = __defaultStatus;
            }
      
            if (__statuses && data && data[__statusField] !== undefined && !__statuses.includes(data[__statusField])) {
              throw new Error(`${__statusField} must be one of: ${__statuses.join(', ')}`);
            }
      }

    
      {
      // InventoryMixin: Initialize quantity if not present
            if (data.quantity === undefined || data.quantity === null) {
              data.quantity = 0;
            }
            data.quantity = Number(data.quantity);
            if (isNaN(data.quantity)) throw new Error('Quantity must be a number');
      }

    
    const result = await this.repository.create(this.slug, data);
    
    // @HOOK: AFTER_CREATE_LOGGING
    
    return result;
  }

  async update(id, data) {
    // @HOOK: BEFORE_UPDATE_VALIDATION
    
      // Schema-driven validation (generated)
      const existing = await this.repository.findById(this.slug, id);
      if (!existing) return null;
      const merged = { ...existing, ...data };

      const fieldErrors = {};
      const isMissing = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
      const isMissingNonString = (v) => v === undefined || v === null;

      const existingItems = await this.repository.findAll(this.slug);

      if (!isMissing(merged['session_number']) && existingItems.some((it) => it.id !== id && String(it['session_number']) === String(merged['session_number']))) {
        fieldErrors['session_number'] = 'Session Number must be unique';
      }

      if (isMissing(merged['status'])) fieldErrors['status'] = 'Status is required';

      const __allowed_status = ['Draft', 'InProgress', 'PendingApproval', 'Approved', 'Posted'];
      if (!isMissing(merged['status']) && !__allowed_status.includes(String(merged['status']))) fieldErrors['status'] = 'Status must be one of: Draft, InProgress, PendingApproval, Approved, Posted';

      if (Object.keys(fieldErrors).length) {
        const err = new Error('Validation failed');
        err.statusCode = 400;
        err.fieldErrors = fieldErrors;
        throw err;
      }

    
      {
      const __cfg = this.mixinConfig?.inventory_reservation || this.mixinConfig?.inventoryReservation || {};
            const __qtyField = __cfg.quantity_field || __cfg.quantityField || 'quantity';
            const __reservedField = __cfg.reserved_field || __cfg.reservedField || 'reserved_quantity';
            const __committedField = __cfg.committed_field || __cfg.committedField || 'committed_quantity';
            const __availableField = __cfg.available_field || __cfg.availableField || 'available_quantity';
            const __autoAvailable = __cfg.auto_calculate_available === true || __cfg.autoCalculateAvailable === true;
            const __enforce = __cfg.enforce !== false && __cfg.enforceRules !== false;
      
            const __existing = await this.repository.findById(this.slug, id);
      
            const __readNumber = (value) => {
              if (value === undefined || value === null || value === '') return null;
              const num = Number(value);
              return Number.isNaN(num) ? null : num;
            };
      
            const __getValue = (field) => {
              if (data && data[field] !== undefined) return __readNumber(data[field]);
              if (__existing && __existing[field] !== undefined) return __readNumber(__existing[field]);
              return null;
            };
      
            const __qty = __getValue(__qtyField);
            const __reserved = __getValue(__reservedField);
            const __committed = __getValue(__committedField);
            const __hasReservations = __reserved !== null || __committed !== null;
      
            if (__enforce && __qty !== null && __hasReservations) {
              const __reservedVal = __reserved ?? 0;
              const __committedVal = __committed ?? 0;
              if (__reservedVal < 0 || __committedVal < 0) {
                throw new Error('Reserved and committed quantities cannot be negative');
              }
              if (__reservedVal + __committedVal > __qty) {
                throw new Error('Reserved + committed quantities cannot exceed on-hand quantity');
              }
            }
      
            if (__autoAvailable && __qty !== null && __hasReservations && __availableField) {
              const __reservedVal = __reserved ?? 0;
              const __committedVal = __committed ?? 0;
              data[__availableField] = __qty - __reservedVal - __committedVal;
            }
      }

    
      {
      const __cfg = this.mixinConfig?.inventory_lifecycle || this.mixinConfig?.inventoryLifecycle || {};
            const __statusField = __cfg.status_field || __cfg.statusField || 'status';
            const __statuses = Array.isArray(__cfg.statuses) && __cfg.statuses.length ? __cfg.statuses : null;
            const __enforceTransitions = __cfg.enforce_transitions === true || __cfg.enforceTransitions === true;
            const __customTransitions = __cfg.transitions && typeof __cfg.transitions === 'object' ? __cfg.transitions : null;
            const __defaultTransitions = {
              Draft: ['Active', 'Obsolete'],
              Active: ['Obsolete'],
              Obsolete: [],
            };
            const __transitions = __customTransitions || (__cfg.use_default_transitions === true || __cfg.useDefaultTransitions === true ? __defaultTransitions : null);
      
            if (data && data[__statusField] !== undefined) {
              const __nextStatus = data[__statusField];
              if (__statuses && !__statuses.includes(__nextStatus)) {
                throw new Error(`${__statusField} must be one of: ${__statuses.join(', ')}`);
              }
      
              if (__enforceTransitions && __transitions) {
                const __existing = await this.repository.findById(this.slug, id);
                const __currentStatus = __existing ? __existing[__statusField] : null;
      
                if (__currentStatus && __currentStatus !== __nextStatus) {
                  const __allowed = Array.isArray(__transitions[__currentStatus]) ? __transitions[__currentStatus] : [];
                  if (!__allowed.includes(__nextStatus)) {
                    throw new Error(`Invalid status transition: ${__currentStatus} -> ${__nextStatus}`);
                  }
                }
              }
            }
      }

    
      {
      // InventoryMixin: Validate quantity updates
            if (data.quantity !== undefined) {
              const newQty = Number(data.quantity);
              if (isNaN(newQty)) throw new Error('Quantity must be a number');
      
              const inventoryConfig = this.mixinConfig?.inventory || {};
              const allowNegative = inventoryConfig.allow_negative === true || inventoryConfig.allowNegative === true;
      
              // Prevent negative stock unless allow_negative is true
              if (!allowNegative && newQty < 0) {
                throw new Error('Stock cannot be negative');
              }
            }
      }

    
    const result = await this.repository.update(this.slug, id, data);
    
    // @HOOK: AFTER_UPDATE_LOGGING

    return result;
  }

  async delete(id) {
    // @HOOK: BEFORE_DELETE_VALIDATION
    
      // Delete protection (generated): prevent deleting a record that is referenced by others
      const dependents = [];

      {
        const rows = await this.repository.findAll('cycle_count_lines');
        const matches = rows.filter((row) => String(row['cycle_count_session_id'] ?? '') === String(id));
        if (matches.length) {
          dependents.push({
            entity: 'cycle_count_lines',
            via: ['cycle_count_session_id'],
            count: matches.length,
            preview: matches.slice(0, 10).map((r) => ({ id: r.id, display: r['cycle_count_session_id'] || r.id })),
          });
        }
      }

      if (dependents.length) {
        const err = new Error('Cannot delete: this record is referenced by other records');
        err.statusCode = 409;
        err.dependents = dependents;
        throw err;
      }


    const result = await this.repository.delete(this.slug, id);
    
    // @HOOK: AFTER_DELETE_LOGGING

    return result;
  }

  async findById(id) {
    return this.repository.findById(this.slug, id);
  }

  async findAll(filter = {}) {
    return this.repository.findAll(this.slug, filter);
  }

  // @HOOK: ADDITIONAL_METHODS
    
  _invCycleCfg() {
    const cfg =
      this.mixinConfig?.inventory_cycle_count_workflow ||
      this.mixinConfig?.inventoryCycleCountWorkflow ||
      this.mixinConfig?.inventory_cycle_count ||
      this.mixinConfig?.inventoryCycleCount ||
      {};
    return {
      stock_entity: cfg.stock_entity || cfg.stockEntity || 'products',
      quantity_field: cfg.quantity_field || cfg.quantityField || 'quantity',
      session_entity: cfg.session_entity || cfg.sessionEntity || this.slug,
      line_entity: cfg.line_entity || cfg.lineEntity || 'cycle_count_lines',
      line_session_field: cfg.line_session_field || cfg.lineSessionField || 'cycle_count_session_id',
      line_item_field: cfg.line_item_field || cfg.lineItemField || 'item_id',
      line_expected_field: cfg.line_expected_field || cfg.lineExpectedField || 'expected_quantity',
      line_counted_field: cfg.line_counted_field || cfg.lineCountedField || 'counted_quantity',
      line_variance_field: cfg.line_variance_field || cfg.lineVarianceField || 'variance_quantity',
      line_status_field: cfg.line_status_field || cfg.lineStatusField || 'status',
      session_status_field: cfg.session_status_field || cfg.sessionStatusField || 'status',
      allow_negative_stock:
        cfg.allow_negative_stock === true ||
        cfg.allowNegativeStock === true,
    };
  }

  _invCycleErr(message, statusCode = 400, details = null) {
    const err = new Error(message);
    err.statusCode = statusCode;
    if (details) err.details = details;
    return err;
  }

  _invCycleNum(raw, fallback = 0) {
    if (raw === undefined || raw === null || raw === '') return fallback;
    const n = Number(raw);
    return Number.isFinite(n) ? n : fallback;
  }

  async startCycleSession(sessionId, payload = {}) {
    const cfg = this._invCycleCfg();
    if (cfg.session_entity !== this.slug) {
      throw this._invCycleErr(
        `Cycle workflow can only run on '${cfg.session_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    const nowIso = new Date().toISOString();
    return this.repository.withTransaction(async (client) => {
      const session = await this.repository.findByIdForUpdate(this.slug, sessionId, client);
      if (!session) throw this._invCycleErr('Cycle session not found', 404);
      const status = String(session[cfg.session_status_field] || 'Draft');
      if (!['Draft', 'Pending'].includes(status)) {
        throw this._invCycleErr('Only Draft/Pending sessions can be started', 409, { status });
      }

      return this.repository.updateWithClient(
        this.slug,
        sessionId,
        {
          [cfg.session_status_field]: 'InProgress',
          started_at: nowIso,
          note: payload.note || session.note || null,
        },
        client
      );
    });
  }

  async recalculateCycleCount(sessionId, payload = {}) {
    const cfg = this._invCycleCfg();
    if (cfg.session_entity !== this.slug) {
      throw this._invCycleErr(
        `Cycle workflow can only run on '${cfg.session_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    return this.repository.withTransaction(async (client) => {
      const session = await this.repository.findByIdForUpdate(this.slug, sessionId, client);
      if (!session) throw this._invCycleErr('Cycle session not found', 404);

      const lines = await this.repository.findAllWithClient(
        cfg.line_entity,
        { [cfg.line_session_field]: sessionId },
        client
      );
      if (!Array.isArray(lines) || lines.length === 0) {
        throw this._invCycleErr('Cycle session has no lines', 400);
      }

      let totalLines = 0;
      let varianceTotal = 0;
      let countedLines = 0;
      for (const line of lines) {
        const lineId = line.id;
        const itemId = line[cfg.line_item_field];
        if (!lineId || !itemId) continue;

        const stockItem = await this.repository.findByIdForUpdate(cfg.stock_entity, itemId, client);
        const expected = this._invCycleNum(stockItem ? stockItem[cfg.quantity_field] : 0, 0);
        const counted = this._invCycleNum(line[cfg.line_counted_field], expected);
        const variance = counted - expected;
        const lineStatus =
          line[cfg.line_counted_field] !== undefined &&
          line[cfg.line_counted_field] !== null &&
          line[cfg.line_counted_field] !== ''
            ? 'Counted'
            : 'Pending';

        await this.repository.updateWithClient(
          cfg.line_entity,
          lineId,
          {
            [cfg.line_expected_field]: expected,
            [cfg.line_variance_field]: variance,
            [cfg.line_status_field]: lineStatus,
          },
          client
        );

        totalLines += 1;
        if (lineStatus === 'Counted') countedLines += 1;
        varianceTotal += variance;
      }

      const sessionStatus = countedLines > 0 ? 'PendingApproval' : 'InProgress';
      const updatedSession = await this.repository.updateWithClient(
        this.slug,
        sessionId,
        {
          [cfg.session_status_field]: sessionStatus,
          note: payload.note || session.note || null,
        },
        client
      );

      return {
        session: updatedSession,
        totals: {
          line_count: totalLines,
          counted_line_count: countedLines,
          variance_total: varianceTotal,
        },
      };
    });
  }

  async approveCycleSession(sessionId, payload = {}) {
    const cfg = this._invCycleCfg();
    if (cfg.session_entity !== this.slug) {
      throw this._invCycleErr(
        `Cycle workflow can only run on '${cfg.session_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    const nowIso = new Date().toISOString();
    return this.repository.withTransaction(async (client) => {
      const session = await this.repository.findByIdForUpdate(this.slug, sessionId, client);
      if (!session) throw this._invCycleErr('Cycle session not found', 404);
      const status = String(session[cfg.session_status_field] || 'Draft');
      if (status !== 'PendingApproval') {
        throw this._invCycleErr('Only PendingApproval sessions can be approved (run Recalculate first)', 409, { status });
      }

      return this.repository.updateWithClient(
        this.slug,
        sessionId,
        {
          [cfg.session_status_field]: 'Approved',
          approved_at: nowIso,
          approved_by: payload.approved_by || payload.approvedBy || session.approved_by || null,
          note: payload.note || session.note || null,
        },
        client
      );
    });
  }

  async postCycleSession(sessionId, payload = {}) {
    const cfg = this._invCycleCfg();
    if (cfg.session_entity !== this.slug) {
      throw this._invCycleErr(
        `Cycle workflow can only run on '${cfg.session_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    return this.repository.withTransaction(async (client) => {
      const session = await this.repository.findByIdForUpdate(this.slug, sessionId, client);
      if (!session) throw this._invCycleErr('Cycle session not found', 404);

      const status = String(session[cfg.session_status_field] || 'Draft');
      if (status !== 'Approved') {
        throw this._invCycleErr('Only Approved sessions can be posted (run Approve first)', 409, { status });
      }

      const lines = await this.repository.findAllWithClient(
        cfg.line_entity,
        { [cfg.line_session_field]: sessionId },
        client
      );
      if (!Array.isArray(lines) || lines.length === 0) {
        throw this._invCycleErr('Cycle session has no lines', 400);
      }

      let postedLines = 0;
      let netAdjustment = 0;
      const stockChanges = [];
      for (const line of lines) {
        const lineId = line.id;
        const itemId = line[cfg.line_item_field];
        if (!lineId || !itemId) continue;

        let variance = this._invCycleNum(line[cfg.line_variance_field], null);
        if (variance === null) {
          const expected = this._invCycleNum(line[cfg.line_expected_field], 0);
          const counted = this._invCycleNum(line[cfg.line_counted_field], expected);
          variance = counted - expected;
        }

        if (variance !== 0) {
          const updatedStock = await this.repository.atomicAdjustQuantity(
            cfg.stock_entity,
            itemId,
            variance,
            {
              quantityField: cfg.quantity_field,
              allow_negative_stock: cfg.allow_negative_stock,
            },
            client
          );
          stockChanges.push({
            item_id: itemId,
            delta: variance,
            quantity: updatedStock ? updatedStock[cfg.quantity_field] : null,
          });
        }

        await this.repository.updateWithClient(
          cfg.line_entity,
          lineId,
          {
            [cfg.line_variance_field]: variance,
            [cfg.line_status_field]: 'Posted',
          },
          client
        );

        postedLines += 1;
        netAdjustment += variance;
      }

      const nowIso = new Date().toISOString();
      const postedSession = await this.repository.updateWithClient(
        this.slug,
        sessionId,
        {
          [cfg.session_status_field]: 'Posted',
          posted_at: nowIso,
          note: payload.note || session.note || null,
        },
        client
      );

      return {
        session: postedSession,
        totals: {
          posted_lines: postedLines,
          net_adjustment: netAdjustment,
        },
        stock_changes: stockChanges,
      };
    });
  }
  
    
  _invTxnConfig() {
    const cfg =
      this.mixinConfig?.inventory_transaction_safety ||
      this.mixinConfig?.inventoryTransactionSafety ||
      this.mixinConfig?.inventory_transactions ||
      this.mixinConfig?.inventoryTransactions ||
      {};
    const fields = cfg.fields && typeof cfg.fields === 'object' ? cfg.fields : {};
    const movementTypes = cfg.movement_types && typeof cfg.movement_types === 'object'
      ? cfg.movement_types
      : (cfg.movementTypes && typeof cfg.movementTypes === 'object' ? cfg.movementTypes : {});
    return {
      stock_entity: cfg.stock_entity || cfg.stockEntity || this.slug,
      quantity_field: cfg.quantity_field || cfg.quantityField || 'quantity',
      quantity_mode: String(cfg.quantity_mode || cfg.quantityMode || 'change').toLowerCase() === 'absolute' ? 'absolute' : 'change',
      movement_entity: cfg.movement_entity || cfg.movementEntity || 'stock_movements',
      allow_negative_stock:
        cfg.allow_negative_stock === true ||
        cfg.allowNegativeStock === true,
      log_movements: cfg.log_movements !== false && cfg.logMovements !== false,
      fields: {
        item_ref: fields.item_ref || fields.itemRef || 'item_id',
        qty: fields.qty || 'quantity',
        type: fields.type || 'movement_type',
        location: fields.location || fields.location_id || fields.locationId || 'location_id',
        reason: fields.reason || 'reason',
        reference_number: fields.reference_number || fields.referenceNumber || 'reference_number',
        date: fields.date || fields.movement_date || fields.movementDate || 'movement_date',
        from_location: fields.from_location || fields.fromLocation || fields.from_location_id || fields.fromLocationId || 'from_location_id',
        to_location: fields.to_location || fields.toLocation || fields.to_location_id || fields.toLocationId || 'to_location_id',
      },
      movement_types: {
        receive: movementTypes.receive || movementTypes.in || 'IN',
        issue: movementTypes.issue || movementTypes.out || 'OUT',
        adjust: movementTypes.adjust || 'ADJUSTMENT',
        transfer_out: movementTypes.transfer_out || movementTypes.transferOut || 'TRANSFER_OUT',
        transfer_in: movementTypes.transfer_in || movementTypes.transferIn || 'TRANSFER_IN',
      },
    };
  }

  _invTxnError(message, statusCode = 400, details = null) {
    const err = new Error(message);
    err.statusCode = statusCode;
    if (details) err.details = details;
    return err;
  }

  _invTxnPositiveNumber(raw, fieldName) {
    const num = Number(raw);
    if (!Number.isFinite(num) || num <= 0) {
      throw this._invTxnError(`${fieldName} must be greater than zero`, 400);
    }
    return num;
  }

  _invTxnMovementQuantity(mode, operation, quantity, delta) {
    if (mode === 'absolute') {
      return Math.abs(quantity);
    }
    if (operation === 'adjust') return delta;
    if (operation === 'issue') return -Math.abs(quantity);
    if (operation === 'receive') return Math.abs(quantity);
    return quantity;
  }

  _invTxnBuildMovementRow(cfg, operation, itemId, payload, movementQty, movementType, locationOverride = null) {
    const row = {};
    row[cfg.fields.item_ref] = itemId;
    row[cfg.fields.type] = movementType;
    row[cfg.fields.qty] = movementQty;

    const locationValue = locationOverride === null
      ? (payload.location_id || payload.locationId || payload[cfg.fields.location])
      : locationOverride;
    if (locationValue !== undefined && locationValue !== null && locationValue !== '') {
      row[cfg.fields.location] = locationValue;
    }

    const movementDate =
      payload.movement_date ||
      payload.movementDate ||
      payload.date ||
      payload[cfg.fields.date] ||
      new Date().toISOString();
    row[cfg.fields.date] = movementDate;

    const reason = payload.reason || payload.note || payload[cfg.fields.reason];
    if (reason !== undefined && reason !== null && reason !== '') {
      row[cfg.fields.reason] = reason;
    }

    const ref =
      payload.reference_number ||
      payload.referenceNumber ||
      payload[cfg.fields.reference_number];
    if (ref !== undefined && ref !== null && ref !== '') {
      row[cfg.fields.reference_number] = ref;
    }

    const fromLocation = payload.from_location_id || payload.fromLocationId || payload[cfg.fields.from_location];
    if (fromLocation !== undefined && fromLocation !== null && fromLocation !== '') {
      row[cfg.fields.from_location] = fromLocation;
    }
    const toLocation = payload.to_location_id || payload.toLocationId || payload[cfg.fields.to_location];
    if (toLocation !== undefined && toLocation !== null && toLocation !== '') {
      row[cfg.fields.to_location] = toLocation;
    }

    return row;
  }

  async _invTxnCreateMovements(client, cfg, rows) {
    if (!cfg.log_movements || !cfg.movement_entity) return;
    for (const row of rows) {
      await this.repository.createWithClient(cfg.movement_entity, row, client);
    }
  }

  async _invTxnApplyStockOperation(itemId, operation, payload = {}) {
    const cfg = this._invTxnConfig();
    const stockSlug = cfg.stock_entity || this.slug;
    if (stockSlug !== this.slug) {
      throw this._invTxnError(
        `Workflow can only run on '${stockSlug}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    let qty = 0;
    let delta = 0;

    if (operation === 'adjust') {
      const deltaRaw = payload.delta ?? payload.quantity ?? payload.qty ?? payload[cfg.fields.qty];
      const parsedDelta = Number(deltaRaw);
      if (!Number.isFinite(parsedDelta) || parsedDelta === 0) {
        throw this._invTxnError('delta must be a non-zero number for adjust operation', 400);
      }
      delta = parsedDelta;
      qty = Math.abs(parsedDelta);
    } else if (operation === 'receive' || operation === 'issue') {
      const qtyRaw =
        payload.quantity ??
        payload.qty ??
        payload[cfg.fields.qty];
      qty = this._invTxnPositiveNumber(qtyRaw, 'quantity');
      delta = operation === 'receive' ? qty : -qty;
    } else if (operation === 'transfer') {
      const qtyRaw =
        payload.quantity ??
        payload.qty ??
        payload[cfg.fields.qty];
      qty = this._invTxnPositiveNumber(qtyRaw, 'quantity');
      delta = 0;
      const fromLocation = payload.from_location_id || payload.fromLocationId || payload[cfg.fields.from_location];
      const toLocation = payload.to_location_id || payload.toLocationId || payload[cfg.fields.to_location];
      if (!fromLocation || !toLocation) {
        throw this._invTxnError('transfer requires both from and to locations', 400);
      }
      if (String(fromLocation) === String(toLocation)) {
        throw this._invTxnError('from and to locations must be different for transfer', 400);
      }
    } else {
      throw this._invTxnError(`Unsupported stock operation '${operation}'`, 400);
    }

    return this.repository.withTransaction(async (client) => {
      let updatedItem;
      if (delta !== 0) {
        updatedItem = await this.repository.atomicAdjustQuantity(
          this.slug,
          itemId,
          delta,
          {
            quantityField: cfg.quantity_field,
            allow_negative_stock: cfg.allow_negative_stock,
          },
          client
        );
      } else {
        updatedItem = await this.repository.findByIdForUpdate(this.slug, itemId, client);
        if (!updatedItem) throw this._invTxnError('Item not found', 404);
      }

      const movementRows = [];
      if (operation === 'transfer') {
        const outQty = cfg.quantity_mode === 'absolute' ? Math.abs(qty) : -Math.abs(qty);
        const inQty = cfg.quantity_mode === 'absolute' ? Math.abs(qty) : Math.abs(qty);
        movementRows.push(
          this._invTxnBuildMovementRow(
            cfg,
            operation,
            itemId,
            payload,
            outQty,
            cfg.movement_types.transfer_out,
            payload.from_location_id || payload.fromLocationId || payload[cfg.fields.from_location]
          )
        );
        movementRows.push(
          this._invTxnBuildMovementRow(
            cfg,
            operation,
            itemId,
            payload,
            inQty,
            cfg.movement_types.transfer_in,
            payload.to_location_id || payload.toLocationId || payload[cfg.fields.to_location]
          )
        );
      } else {
        const movementType =
          operation === 'receive'
            ? cfg.movement_types.receive
            : operation === 'issue'
              ? cfg.movement_types.issue
              : cfg.movement_types.adjust;
        const movementQty = this._invTxnMovementQuantity(cfg.quantity_mode, operation, qty, delta);
        movementRows.push(
          this._invTxnBuildMovementRow(cfg, operation, itemId, payload, movementQty, movementType)
        );
      }

      await this._invTxnCreateMovements(client, cfg, movementRows);

      return {
        operation,
        item: updatedItem,
        delta,
        movement_count: movementRows.length,
      };
    });
  }

  async applyStockReceive(itemId, payload = {}) {
    return this._invTxnApplyStockOperation(itemId, 'receive', payload);
  }

  async applyStockIssue(itemId, payload = {}) {
    return this._invTxnApplyStockOperation(itemId, 'issue', payload);
  }

  async applyStockAdjust(itemId, payload = {}) {
    return this._invTxnApplyStockOperation(itemId, 'adjust', payload);
  }

  async applyStockTransfer(itemId, payload = {}) {
    return this._invTxnApplyStockOperation(itemId, 'transfer', payload);
  }
  
    
  async adjustStock(id, delta) {
    const inventoryConfig = this.mixinConfig?.inventory || {};
    const allowNegative = inventoryConfig.allow_negative === true || inventoryConfig.allowNegative === true;

    if (typeof this.repository.atomicAdjustQuantity === 'function') {
      return this.repository.atomicAdjustQuantity(this.slug, id, delta, {
        quantityField: 'quantity',
        allow_negative_stock: allowNegative,
      });
    }

    const item = await this.repository.findById(this.slug, id);
    if (!item) throw new Error('Item not found');

    const currentQty = Number(item.quantity) || 0;
    const newQty = currentQty + delta;

    if (!allowNegative && newQty < 0) {
      throw new Error(`Insufficient stock. Current: ${currentQty}, Delta: ${delta}`);
    }

    return this.repository.update(this.slug, id, { quantity: newQty });
  }
  
}

module.exports = Cycle_count_sessionsService;
