// brick-library/backend-bricks/core/BaseService.js.hbs
class Goods_receiptsService {
  constructor(repository, mixinConfig = {}) {
    this.repository = repository;
    this.slug = 'goods_receipts';
    this.mixinConfig = mixinConfig && typeof mixinConfig === 'object' ? mixinConfig : {};
  }

  async create(data) {
    // @HOOK: BEFORE_CREATE_VALIDATION
    
      // Schema-driven validation (generated)
      const fieldErrors = {};
      const isMissing = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
      const isMissingNonString = (v) => v === undefined || v === null;

      const existingItems = await this.repository.findAll(this.slug);

      const __refIdSets = {};
      const getRefIdSet = async (slug) => {
        if (__refIdSets[slug]) return __refIdSets[slug];
        const all = await this.repository.findAll(slug);
        __refIdSets[slug] = new Set(all.map((x) => x.id));
        return __refIdSets[slug];
      };

      if (!isMissing(data['grn_number']) && existingItems.some((it) => String(it['grn_number']) === String(data['grn_number']))) {
        fieldErrors['grn_number'] = 'Grn Number must be unique';
      }

      if (!isMissing(data['purchase_order_id'])) {
        const ids = await getRefIdSet('purchase_orders');
        if (!ids.has(String(data['purchase_order_id']))) fieldErrors['purchase_order_id'] = 'Purchase Order Id has an invalid reference';
      }

      if (isMissing(data['status'])) fieldErrors['status'] = 'Status is required';

      const __allowed_status = ['Draft', 'Posted', 'Cancelled'];
      if (!isMissing(data['status']) && !__allowed_status.includes(String(data['status']))) fieldErrors['status'] = 'Status must be one of: Draft, Posted, Cancelled';

      if (Object.keys(fieldErrors).length) {
        const err = new Error('Validation failed');
        err.statusCode = 400;
        err.fieldErrors = fieldErrors;
        throw err;
      }

    
      {
      const __cfg = this.mixinConfig?.inventory_reservation || this.mixinConfig?.inventoryReservation || {};
            const __qtyField = __cfg.quantity_field || __cfg.quantityField || 'quantity';
            const __reservedField = __cfg.reserved_field || __cfg.reservedField || 'reserved_quantity';
            const __committedField = __cfg.committed_field || __cfg.committedField || 'committed_quantity';
            const __availableField = __cfg.available_field || __cfg.availableField || 'available_quantity';
            const __autoAvailable = __cfg.auto_calculate_available === true || __cfg.autoCalculateAvailable === true;
            const __enforce = __cfg.enforce !== false && __cfg.enforceRules !== false;
      
            const __readNumber = (value) => {
              if (value === undefined || value === null || value === '') return null;
              const num = Number(value);
              return Number.isNaN(num) ? null : num;
            };
      
            const __qty = __readNumber(data[__qtyField]);
            const __reserved = __readNumber(data[__reservedField]);
            const __committed = __readNumber(data[__committedField]);
            const __hasReservations = __reserved !== null || __committed !== null;
      
            if (__enforce && __qty !== null && __hasReservations) {
              const __reservedVal = __reserved ?? 0;
              const __committedVal = __committed ?? 0;
              if (__reservedVal < 0 || __committedVal < 0) {
                throw new Error('Reserved and committed quantities cannot be negative');
              }
              if (__reservedVal + __committedVal > __qty) {
                throw new Error('Reserved + committed quantities cannot exceed on-hand quantity');
              }
            }
      
            if (__autoAvailable && __qty !== null && __hasReservations && __availableField) {
              const __reservedVal = __reserved ?? 0;
              const __committedVal = __committed ?? 0;
              data[__availableField] = __qty - __reservedVal - __committedVal;
            }
      }

    
    // @HOOK: BEFORE_CREATE_TRANSFORMATION
    
      {
      const __cfg = this.mixinConfig?.inventory_lifecycle || this.mixinConfig?.inventoryLifecycle || {};
            const __statusField = __cfg.status_field || __cfg.statusField || 'status';
            const __statuses = Array.isArray(__cfg.statuses) && __cfg.statuses.length ? __cfg.statuses : null;
            const __defaultStatus = __cfg.default_status || __cfg.defaultStatus;
      
            if (data && data[__statusField] === undefined && __defaultStatus) {
              data[__statusField] = __defaultStatus;
            }
      
            if (__statuses && data && data[__statusField] !== undefined && !__statuses.includes(data[__statusField])) {
              throw new Error(`${__statusField} must be one of: ${__statuses.join(', ')}`);
            }
      }

    
      {
      // InventoryMixin: Initialize quantity if not present
            if (data.quantity === undefined || data.quantity === null) {
              data.quantity = 0;
            }
            data.quantity = Number(data.quantity);
            if (isNaN(data.quantity)) throw new Error('Quantity must be a number');
      }

    
    const result = await this.repository.create(this.slug, data);
    
    // @HOOK: AFTER_CREATE_LOGGING
    
    return result;
  }

  async update(id, data) {
    // @HOOK: BEFORE_UPDATE_VALIDATION
    
      // Schema-driven validation (generated)
      const existing = await this.repository.findById(this.slug, id);
      if (!existing) return null;
      const merged = { ...existing, ...data };

      const fieldErrors = {};
      const isMissing = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
      const isMissingNonString = (v) => v === undefined || v === null;

      const existingItems = await this.repository.findAll(this.slug);

      const __refIdSets = {};
      const getRefIdSet = async (slug) => {
        if (__refIdSets[slug]) return __refIdSets[slug];
        const all = await this.repository.findAll(slug);
        __refIdSets[slug] = new Set(all.map((x) => x.id));
        return __refIdSets[slug];
      };

      if (!isMissing(merged['grn_number']) && existingItems.some((it) => it.id !== id && String(it['grn_number']) === String(merged['grn_number']))) {
        fieldErrors['grn_number'] = 'Grn Number must be unique';
      }

      if (!isMissing(merged['purchase_order_id'])) {
        const ids = await getRefIdSet('purchase_orders');
        if (!ids.has(String(merged['purchase_order_id']))) fieldErrors['purchase_order_id'] = 'Purchase Order Id has an invalid reference';
      }

      if (isMissing(merged['status'])) fieldErrors['status'] = 'Status is required';

      const __allowed_status = ['Draft', 'Posted', 'Cancelled'];
      if (!isMissing(merged['status']) && !__allowed_status.includes(String(merged['status']))) fieldErrors['status'] = 'Status must be one of: Draft, Posted, Cancelled';

      if (Object.keys(fieldErrors).length) {
        const err = new Error('Validation failed');
        err.statusCode = 400;
        err.fieldErrors = fieldErrors;
        throw err;
      }

    
      {
      const __cfg = this.mixinConfig?.inventory_reservation || this.mixinConfig?.inventoryReservation || {};
            const __qtyField = __cfg.quantity_field || __cfg.quantityField || 'quantity';
            const __reservedField = __cfg.reserved_field || __cfg.reservedField || 'reserved_quantity';
            const __committedField = __cfg.committed_field || __cfg.committedField || 'committed_quantity';
            const __availableField = __cfg.available_field || __cfg.availableField || 'available_quantity';
            const __autoAvailable = __cfg.auto_calculate_available === true || __cfg.autoCalculateAvailable === true;
            const __enforce = __cfg.enforce !== false && __cfg.enforceRules !== false;
      
            const __existing = await this.repository.findById(this.slug, id);
      
            const __readNumber = (value) => {
              if (value === undefined || value === null || value === '') return null;
              const num = Number(value);
              return Number.isNaN(num) ? null : num;
            };
      
            const __getValue = (field) => {
              if (data && data[field] !== undefined) return __readNumber(data[field]);
              if (__existing && __existing[field] !== undefined) return __readNumber(__existing[field]);
              return null;
            };
      
            const __qty = __getValue(__qtyField);
            const __reserved = __getValue(__reservedField);
            const __committed = __getValue(__committedField);
            const __hasReservations = __reserved !== null || __committed !== null;
      
            if (__enforce && __qty !== null && __hasReservations) {
              const __reservedVal = __reserved ?? 0;
              const __committedVal = __committed ?? 0;
              if (__reservedVal < 0 || __committedVal < 0) {
                throw new Error('Reserved and committed quantities cannot be negative');
              }
              if (__reservedVal + __committedVal > __qty) {
                throw new Error('Reserved + committed quantities cannot exceed on-hand quantity');
              }
            }
      
            if (__autoAvailable && __qty !== null && __hasReservations && __availableField) {
              const __reservedVal = __reserved ?? 0;
              const __committedVal = __committed ?? 0;
              data[__availableField] = __qty - __reservedVal - __committedVal;
            }
      }

    
      {
      const __cfg = this.mixinConfig?.inventory_lifecycle || this.mixinConfig?.inventoryLifecycle || {};
            const __statusField = __cfg.status_field || __cfg.statusField || 'status';
            const __statuses = Array.isArray(__cfg.statuses) && __cfg.statuses.length ? __cfg.statuses : null;
            const __enforceTransitions = __cfg.enforce_transitions === true || __cfg.enforceTransitions === true;
            const __customTransitions = __cfg.transitions && typeof __cfg.transitions === 'object' ? __cfg.transitions : null;
            const __defaultTransitions = {
              Draft: ['Active', 'Obsolete'],
              Active: ['Obsolete'],
              Obsolete: [],
            };
            const __transitions = __customTransitions || (__cfg.use_default_transitions === true || __cfg.useDefaultTransitions === true ? __defaultTransitions : null);
      
            if (data && data[__statusField] !== undefined) {
              const __nextStatus = data[__statusField];
              if (__statuses && !__statuses.includes(__nextStatus)) {
                throw new Error(`${__statusField} must be one of: ${__statuses.join(', ')}`);
              }
      
              if (__enforceTransitions && __transitions) {
                const __existing = await this.repository.findById(this.slug, id);
                const __currentStatus = __existing ? __existing[__statusField] : null;
      
                if (__currentStatus && __currentStatus !== __nextStatus) {
                  const __allowed = Array.isArray(__transitions[__currentStatus]) ? __transitions[__currentStatus] : [];
                  if (!__allowed.includes(__nextStatus)) {
                    throw new Error(`Invalid status transition: ${__currentStatus} -> ${__nextStatus}`);
                  }
                }
              }
            }
      }

    
      {
      // InventoryMixin: Validate quantity updates
            if (data.quantity !== undefined) {
              const newQty = Number(data.quantity);
              if (isNaN(newQty)) throw new Error('Quantity must be a number');
      
              const inventoryConfig = this.mixinConfig?.inventory || {};
              const allowNegative = inventoryConfig.allow_negative === true || inventoryConfig.allowNegative === true;
      
              // Prevent negative stock unless allow_negative is true
              if (!allowNegative && newQty < 0) {
                throw new Error('Stock cannot be negative');
              }
            }
      }

    
    const result = await this.repository.update(this.slug, id, data);
    
    // @HOOK: AFTER_UPDATE_LOGGING

    return result;
  }

  async delete(id) {
    // @HOOK: BEFORE_DELETE_VALIDATION
    
      // Delete protection (generated): prevent deleting a record that is referenced by others
      const dependents = [];

      {
        const rows = await this.repository.findAll('goods_receipt_items');
        const matches = rows.filter((row) => String(row['goods_receipt_id'] ?? '') === String(id));
        if (matches.length) {
          dependents.push({
            entity: 'goods_receipt_items',
            via: ['goods_receipt_id'],
            count: matches.length,
            preview: matches.slice(0, 10).map((r) => ({ id: r.id, display: r['goods_receipt_id'] || r.id })),
          });
        }
      }

      if (dependents.length) {
        const err = new Error('Cannot delete: this record is referenced by other records');
        err.statusCode = 409;
        err.dependents = dependents;
        throw err;
      }


    const result = await this.repository.delete(this.slug, id);
    
    // @HOOK: AFTER_DELETE_LOGGING

    return result;
  }

  async findById(id) {
    return this.repository.findById(this.slug, id);
  }

  async findAll(filter = {}) {
    return this.repository.findAll(this.slug, filter);
  }

  // @HOOK: ADDITIONAL_METHODS
    
  _invInboundCfg() {
    const cfg =
      this.mixinConfig?.inventory_inbound_workflow ||
      this.mixinConfig?.inventoryInboundWorkflow ||
      this.mixinConfig?.inventory_inbound ||
      this.mixinConfig?.inventoryInbound ||
      {};
    return {
      stock_entity: cfg.stock_entity || cfg.stockEntity || 'products',
      quantity_field: cfg.quantity_field || cfg.quantityField || 'quantity',
      purchase_order_entity: cfg.purchase_order_entity || cfg.purchaseOrderEntity || 'purchase_orders',
      purchase_order_item_entity: cfg.purchase_order_item_entity || cfg.purchaseOrderItemEntity || 'purchase_order_items',
      grn_entity: cfg.grn_entity || cfg.grnEntity || this.slug,
      grn_item_entity: cfg.grn_item_entity || cfg.grnItemEntity || 'goods_receipt_items',
      po_item_parent_field: cfg.po_item_parent_field || cfg.poItemParentField || 'purchase_order_id',
      po_item_item_field: cfg.po_item_item_field || cfg.poItemItemField || 'item_id',
      po_item_ordered_field: cfg.po_item_ordered_field || cfg.poItemOrderedField || 'ordered_quantity',
      po_item_received_field: cfg.po_item_received_field || cfg.poItemReceivedField || 'received_quantity',
      po_item_status_field: cfg.po_item_status_field || cfg.poItemStatusField || 'status',
      po_status_field: cfg.po_status_field || cfg.poStatusField || 'status',
      grn_parent_field: cfg.grn_parent_field || cfg.grnParentField || 'purchase_order_id',
      grn_item_parent_field: cfg.grn_item_parent_field || cfg.grnItemParentField || 'goods_receipt_id',
      grn_item_po_item_field: cfg.grn_item_po_item_field || cfg.grnItemPoItemField || 'purchase_order_item_id',
      grn_item_item_field: cfg.grn_item_item_field || cfg.grnItemItemField || 'item_id',
      grn_item_received_field: cfg.grn_item_received_field || cfg.grnItemReceivedField || 'received_quantity',
      grn_item_accepted_field: cfg.grn_item_accepted_field || cfg.grnItemAcceptedField || 'accepted_quantity',
      grn_status_field: cfg.grn_status_field || cfg.grnStatusField || 'status',
      allow_over_receipt: cfg.allow_over_receipt === true || cfg.allowOverReceipt === true,
    };
  }

  _invInboundErr(message, statusCode = 400, details = null) {
    const err = new Error(message);
    err.statusCode = statusCode;
    if (details) err.details = details;
    return err;
  }

  _invInboundNum(raw) {
    const n = Number(raw);
    return Number.isFinite(n) ? n : 0;
  }

  async postGoodsReceipt(grnId, payload = {}) {
    const cfg = this._invInboundCfg();
    if (cfg.grn_entity !== this.slug) {
      throw this._invInboundErr(
        `Inbound workflow can only run on '${cfg.grn_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    return this.repository.withTransaction(async (client) => {
      const grn = await this.repository.findByIdForUpdate(this.slug, grnId, client);
      if (!grn) throw this._invInboundErr('Goods receipt not found', 404);

      const currentStatus = String(grn[cfg.grn_status_field] || 'Draft');
      if (currentStatus === 'Posted') {
        return {
          already_posted: true,
          goods_receipt: grn,
        };
      }
      if (currentStatus === 'Cancelled') {
        throw this._invInboundErr('Cancelled goods receipt cannot be posted', 409);
      }

      const grnItems = await this.repository.findAllWithClient(
        cfg.grn_item_entity,
        { [cfg.grn_item_parent_field]: grnId },
        client
      );
      if (!Array.isArray(grnItems) || grnItems.length === 0) {
        throw this._invInboundErr('Goods receipt has no lines to post', 400);
      }

      const poId = grn[cfg.grn_parent_field];
      const allowOverReceipt =
        payload.allow_over_receipt === true ||
        payload.allowOverReceipt === true ||
        cfg.allow_over_receipt === true ||
        grn.allow_over_receipt === true;

      let totalReceived = 0;
      const stockChanges = [];
      for (const line of grnItems) {
        const acceptedRaw = line[cfg.grn_item_accepted_field];
        const receivedRaw = line[cfg.grn_item_received_field];
        const lineQty = this._invInboundNum(
          acceptedRaw !== undefined && acceptedRaw !== null && acceptedRaw !== ''
            ? acceptedRaw
            : receivedRaw
        );
        if (lineQty <= 0) continue;

        const poItemId = line[cfg.grn_item_po_item_field];
        let poItem = null;
        if (poItemId) {
          poItem = await this.repository.findByIdForUpdate(cfg.purchase_order_item_entity, poItemId, client);
          if (!poItem) {
            throw this._invInboundErr(
              `Purchase order item '${poItemId}' linked from goods receipt line does not exist`,
              409
            );
          }

          const orderedQty = this._invInboundNum(poItem[cfg.po_item_ordered_field]);
          const currentReceivedQty = this._invInboundNum(poItem[cfg.po_item_received_field]);
          const nextReceivedQty = currentReceivedQty + lineQty;
          if (!allowOverReceipt && orderedQty > 0 && nextReceivedQty > orderedQty) {
            throw this._invInboundErr('Received quantity exceeds ordered quantity', 409, {
              po_item_id: poItemId,
              ordered_quantity: orderedQty,
              current_received_quantity: currentReceivedQty,
              posting_quantity: lineQty,
            });
          }

          const poItemStatus = nextReceivedQty >= orderedQty && orderedQty > 0
            ? 'Received'
            : (nextReceivedQty > 0 ? 'Partial' : 'Open');
          await this.repository.updateWithClient(
            cfg.purchase_order_item_entity,
            poItemId,
            {
              [cfg.po_item_received_field]: nextReceivedQty,
              [cfg.po_item_status_field]: poItemStatus,
            },
            client
          );
        }

        const stockItemId = line[cfg.grn_item_item_field] || (poItem ? poItem[cfg.po_item_item_field] : null);
        if (stockItemId) {
          const updatedStock = await this.repository.atomicAdjustQuantity(
            cfg.stock_entity,
            stockItemId,
            lineQty,
            {
              quantityField: cfg.quantity_field,
              allow_negative_stock: false,
            },
            client
          );
          stockChanges.push({
            item_id: stockItemId,
            quantity_delta: lineQty,
            quantity: updatedStock ? updatedStock[cfg.quantity_field] : null,
          });
        }
        totalReceived += lineQty;
      }

      let purchaseOrder = null;
      if (poId) {
        purchaseOrder = await this.repository.findByIdForUpdate(cfg.purchase_order_entity, poId, client);
      }

      if (purchaseOrder) {
        const poLines = await this.repository.findAllWithClient(
          cfg.purchase_order_item_entity,
          { [cfg.po_item_parent_field]: poId },
          client
        );
        const hasLines = Array.isArray(poLines) && poLines.length > 0;
        const isReceived = hasLines && poLines.every((line) => {
          const ordered = this._invInboundNum(line[cfg.po_item_ordered_field]);
          const received = this._invInboundNum(line[cfg.po_item_received_field]);
          return ordered <= 0 ? received > 0 : received >= ordered;
        });
        const hasAnyReceived = hasLines && poLines.some((line) => this._invInboundNum(line[cfg.po_item_received_field]) > 0);
        const poStatus = isReceived ? 'Received' : (hasAnyReceived ? 'Partial' : 'Open');
        purchaseOrder = await this.repository.updateWithClient(
          cfg.purchase_order_entity,
          poId,
          { [cfg.po_status_field]: poStatus },
          client
        );
      }

      const nowIso = new Date().toISOString();
      const goodsReceipt = await this.repository.updateWithClient(
        this.slug,
        grnId,
        {
          [cfg.grn_status_field]: 'Posted',
          posted_at: nowIso,
          received_at: grn.received_at || nowIso,
        },
        client
      );

      return {
        goods_receipt: goodsReceipt,
        purchase_order: purchaseOrder,
        total_received_quantity: totalReceived,
        stock_changes: stockChanges,
      };
    });
  }

  async cancelGoodsReceipt(grnId, payload = {}) {
    const cfg = this._invInboundCfg();
    if (cfg.grn_entity !== this.slug) {
      throw this._invInboundErr(
        `Inbound workflow can only run on '${cfg.grn_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    return this.repository.withTransaction(async (client) => {
      const grn = await this.repository.findByIdForUpdate(this.slug, grnId, client);
      if (!grn) throw this._invInboundErr('Goods receipt not found', 404);
      const currentStatus = String(grn[cfg.grn_status_field] || 'Draft');
      if (currentStatus === 'Posted') {
        throw this._invInboundErr('Posted goods receipt cannot be cancelled', 409);
      }
      if (currentStatus === 'Cancelled') {
        return {
          already_cancelled: true,
          goods_receipt: grn,
        };
      }

      const note = payload.note || payload.reason || null;
      const cancelled = await this.repository.updateWithClient(
        this.slug,
        grnId,
        {
          [cfg.grn_status_field]: 'Cancelled',
          cancelled_at: new Date().toISOString(),
          note: note || grn.note || null,
        },
        client
      );

      return {
        goods_receipt: cancelled,
      };
    });
  }
  
    
  _invTxnConfig() {
    const cfg =
      this.mixinConfig?.inventory_transaction_safety ||
      this.mixinConfig?.inventoryTransactionSafety ||
      this.mixinConfig?.inventory_transactions ||
      this.mixinConfig?.inventoryTransactions ||
      {};
    const fields = cfg.fields && typeof cfg.fields === 'object' ? cfg.fields : {};
    const movementTypes = cfg.movement_types && typeof cfg.movement_types === 'object'
      ? cfg.movement_types
      : (cfg.movementTypes && typeof cfg.movementTypes === 'object' ? cfg.movementTypes : {});
    return {
      stock_entity: cfg.stock_entity || cfg.stockEntity || this.slug,
      quantity_field: cfg.quantity_field || cfg.quantityField || 'quantity',
      quantity_mode: String(cfg.quantity_mode || cfg.quantityMode || 'change').toLowerCase() === 'absolute' ? 'absolute' : 'change',
      movement_entity: cfg.movement_entity || cfg.movementEntity || 'stock_movements',
      allow_negative_stock:
        cfg.allow_negative_stock === true ||
        cfg.allowNegativeStock === true,
      log_movements: cfg.log_movements !== false && cfg.logMovements !== false,
      fields: {
        item_ref: fields.item_ref || fields.itemRef || 'item_id',
        qty: fields.qty || 'quantity',
        type: fields.type || 'movement_type',
        location: fields.location || fields.location_id || fields.locationId || 'location_id',
        reason: fields.reason || 'reason',
        reference_number: fields.reference_number || fields.referenceNumber || 'reference_number',
        date: fields.date || fields.movement_date || fields.movementDate || 'movement_date',
        from_location: fields.from_location || fields.fromLocation || fields.from_location_id || fields.fromLocationId || 'from_location_id',
        to_location: fields.to_location || fields.toLocation || fields.to_location_id || fields.toLocationId || 'to_location_id',
      },
      movement_types: {
        receive: movementTypes.receive || movementTypes.in || 'IN',
        issue: movementTypes.issue || movementTypes.out || 'OUT',
        adjust: movementTypes.adjust || 'ADJUSTMENT',
        transfer_out: movementTypes.transfer_out || movementTypes.transferOut || 'TRANSFER_OUT',
        transfer_in: movementTypes.transfer_in || movementTypes.transferIn || 'TRANSFER_IN',
      },
    };
  }

  _invTxnError(message, statusCode = 400, details = null) {
    const err = new Error(message);
    err.statusCode = statusCode;
    if (details) err.details = details;
    return err;
  }

  _invTxnPositiveNumber(raw, fieldName) {
    const num = Number(raw);
    if (!Number.isFinite(num) || num <= 0) {
      throw this._invTxnError(`${fieldName} must be greater than zero`, 400);
    }
    return num;
  }

  _invTxnMovementQuantity(mode, operation, quantity, delta) {
    if (mode === 'absolute') {
      return Math.abs(quantity);
    }
    if (operation === 'adjust') return delta;
    if (operation === 'issue') return -Math.abs(quantity);
    if (operation === 'receive') return Math.abs(quantity);
    return quantity;
  }

  _invTxnBuildMovementRow(cfg, operation, itemId, payload, movementQty, movementType, locationOverride = null) {
    const row = {};
    row[cfg.fields.item_ref] = itemId;
    row[cfg.fields.type] = movementType;
    row[cfg.fields.qty] = movementQty;

    const locationValue = locationOverride === null
      ? (payload.location_id || payload.locationId || payload[cfg.fields.location])
      : locationOverride;
    if (locationValue !== undefined && locationValue !== null && locationValue !== '') {
      row[cfg.fields.location] = locationValue;
    }

    const movementDate =
      payload.movement_date ||
      payload.movementDate ||
      payload.date ||
      payload[cfg.fields.date] ||
      new Date().toISOString();
    row[cfg.fields.date] = movementDate;

    const reason = payload.reason || payload.note || payload[cfg.fields.reason];
    if (reason !== undefined && reason !== null && reason !== '') {
      row[cfg.fields.reason] = reason;
    }

    const ref =
      payload.reference_number ||
      payload.referenceNumber ||
      payload[cfg.fields.reference_number];
    if (ref !== undefined && ref !== null && ref !== '') {
      row[cfg.fields.reference_number] = ref;
    }

    const fromLocation = payload.from_location_id || payload.fromLocationId || payload[cfg.fields.from_location];
    if (fromLocation !== undefined && fromLocation !== null && fromLocation !== '') {
      row[cfg.fields.from_location] = fromLocation;
    }
    const toLocation = payload.to_location_id || payload.toLocationId || payload[cfg.fields.to_location];
    if (toLocation !== undefined && toLocation !== null && toLocation !== '') {
      row[cfg.fields.to_location] = toLocation;
    }

    return row;
  }

  async _invTxnCreateMovements(client, cfg, rows) {
    if (!cfg.log_movements || !cfg.movement_entity) return;
    for (const row of rows) {
      await this.repository.createWithClient(cfg.movement_entity, row, client);
    }
  }

  async _invTxnApplyStockOperation(itemId, operation, payload = {}) {
    const cfg = this._invTxnConfig();
    const stockSlug = cfg.stock_entity || this.slug;
    if (stockSlug !== this.slug) {
      throw this._invTxnError(
        `Workflow can only run on '${stockSlug}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    let qty = 0;
    let delta = 0;

    if (operation === 'adjust') {
      const deltaRaw = payload.delta ?? payload.quantity ?? payload.qty ?? payload[cfg.fields.qty];
      const parsedDelta = Number(deltaRaw);
      if (!Number.isFinite(parsedDelta) || parsedDelta === 0) {
        throw this._invTxnError('delta must be a non-zero number for adjust operation', 400);
      }
      delta = parsedDelta;
      qty = Math.abs(parsedDelta);
    } else if (operation === 'receive' || operation === 'issue') {
      const qtyRaw =
        payload.quantity ??
        payload.qty ??
        payload[cfg.fields.qty];
      qty = this._invTxnPositiveNumber(qtyRaw, 'quantity');
      delta = operation === 'receive' ? qty : -qty;
    } else if (operation === 'transfer') {
      const qtyRaw =
        payload.quantity ??
        payload.qty ??
        payload[cfg.fields.qty];
      qty = this._invTxnPositiveNumber(qtyRaw, 'quantity');
      delta = 0;
      const fromLocation = payload.from_location_id || payload.fromLocationId || payload[cfg.fields.from_location];
      const toLocation = payload.to_location_id || payload.toLocationId || payload[cfg.fields.to_location];
      if (!fromLocation || !toLocation) {
        throw this._invTxnError('transfer requires both from and to locations', 400);
      }
      if (String(fromLocation) === String(toLocation)) {
        throw this._invTxnError('from and to locations must be different for transfer', 400);
      }
    } else {
      throw this._invTxnError(`Unsupported stock operation '${operation}'`, 400);
    }

    return this.repository.withTransaction(async (client) => {
      let updatedItem;
      if (delta !== 0) {
        updatedItem = await this.repository.atomicAdjustQuantity(
          this.slug,
          itemId,
          delta,
          {
            quantityField: cfg.quantity_field,
            allow_negative_stock: cfg.allow_negative_stock,
          },
          client
        );
      } else {
        updatedItem = await this.repository.findByIdForUpdate(this.slug, itemId, client);
        if (!updatedItem) throw this._invTxnError('Item not found', 404);
      }

      const movementRows = [];
      if (operation === 'transfer') {
        const outQty = cfg.quantity_mode === 'absolute' ? Math.abs(qty) : -Math.abs(qty);
        const inQty = cfg.quantity_mode === 'absolute' ? Math.abs(qty) : Math.abs(qty);
        movementRows.push(
          this._invTxnBuildMovementRow(
            cfg,
            operation,
            itemId,
            payload,
            outQty,
            cfg.movement_types.transfer_out,
            payload.from_location_id || payload.fromLocationId || payload[cfg.fields.from_location]
          )
        );
        movementRows.push(
          this._invTxnBuildMovementRow(
            cfg,
            operation,
            itemId,
            payload,
            inQty,
            cfg.movement_types.transfer_in,
            payload.to_location_id || payload.toLocationId || payload[cfg.fields.to_location]
          )
        );
      } else {
        const movementType =
          operation === 'receive'
            ? cfg.movement_types.receive
            : operation === 'issue'
              ? cfg.movement_types.issue
              : cfg.movement_types.adjust;
        const movementQty = this._invTxnMovementQuantity(cfg.quantity_mode, operation, qty, delta);
        movementRows.push(
          this._invTxnBuildMovementRow(cfg, operation, itemId, payload, movementQty, movementType)
        );
      }

      await this._invTxnCreateMovements(client, cfg, movementRows);

      return {
        operation,
        item: updatedItem,
        delta,
        movement_count: movementRows.length,
      };
    });
  }

  async applyStockReceive(itemId, payload = {}) {
    return this._invTxnApplyStockOperation(itemId, 'receive', payload);
  }

  async applyStockIssue(itemId, payload = {}) {
    return this._invTxnApplyStockOperation(itemId, 'issue', payload);
  }

  async applyStockAdjust(itemId, payload = {}) {
    return this._invTxnApplyStockOperation(itemId, 'adjust', payload);
  }

  async applyStockTransfer(itemId, payload = {}) {
    return this._invTxnApplyStockOperation(itemId, 'transfer', payload);
  }
  
    
  async adjustStock(id, delta) {
    const inventoryConfig = this.mixinConfig?.inventory || {};
    const allowNegative = inventoryConfig.allow_negative === true || inventoryConfig.allowNegative === true;

    if (typeof this.repository.atomicAdjustQuantity === 'function') {
      return this.repository.atomicAdjustQuantity(this.slug, id, delta, {
        quantityField: 'quantity',
        allow_negative_stock: allowNegative,
      });
    }

    const item = await this.repository.findById(this.slug, id);
    if (!item) throw new Error('Item not found');

    const currentQty = Number(item.quantity) || 0;
    const newQty = currentQty + delta;

    if (!allowNegative && newQty < 0) {
      throw new Error(`Insufficient stock. Current: ${currentQty}, Delta: ${delta}`);
    }

    return this.repository.update(this.slug, id, { quantity: newQty });
  }
  
}

module.exports = Goods_receiptsService;
