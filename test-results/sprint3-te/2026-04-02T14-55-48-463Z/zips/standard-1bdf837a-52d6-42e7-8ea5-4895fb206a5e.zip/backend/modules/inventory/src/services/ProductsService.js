// brick-library/backend-bricks/core/BaseService.js.hbs
class ProductsService {
  constructor(repository, mixinConfig = {}) {
    this.repository = repository;
    this.slug = 'products';
    this.mixinConfig = mixinConfig && typeof mixinConfig === 'object' ? mixinConfig : {};
  }

  async create(data) {
    // @HOOK: BEFORE_CREATE_VALIDATION
    
      // Schema-driven validation (generated)
      const fieldErrors = {};
      const isMissing = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
      const isMissingNonString = (v) => v === undefined || v === null;

      const existingItems = await this.repository.findAll(this.slug);

      const __refIdSets = {};
      const getRefIdSet = async (slug) => {
        if (__refIdSets[slug]) return __refIdSets[slug];
        const all = await this.repository.findAll(slug);
        __refIdSets[slug] = new Set(all.map((x) => x.id));
        return __refIdSets[slug];
      };

      if (isMissing(data['name'])) fieldErrors['name'] = 'Name is required';

      if (!isMissing(data['sku']) && existingItems.some((it) => String(it['sku']) === String(data['sku']))) {
        fieldErrors['sku'] = 'Sku must be unique';
      }

      if (isMissing(data['quantity'])) fieldErrors['quantity'] = 'Quantity is required';

      if (!isMissing(data['quantity'])) {
        const num = typeof data['quantity'] === 'number' ? data['quantity'] : Number(data['quantity']);
        if (Number.isNaN(num)) {
          fieldErrors['quantity'] = 'Quantity must be a number';
        } else {

          if (!Number.isInteger(num)) fieldErrors['quantity'] = 'Quantity must be an integer';

        }
      }

      if (!isMissing(data['reorder_point'])) {
        const num = typeof data['reorder_point'] === 'number' ? data['reorder_point'] : Number(data['reorder_point']);
        if (Number.isNaN(num)) {
          fieldErrors['reorder_point'] = 'Reorder Point must be a number';
        } else {

          if (!Number.isInteger(num)) fieldErrors['reorder_point'] = 'Reorder Point must be an integer';

        }
      }

      if (!isMissing(data['cost_price'])) {
        const num = typeof data['cost_price'] === 'number' ? data['cost_price'] : Number(data['cost_price']);
        if (Number.isNaN(num)) {
          fieldErrors['cost_price'] = 'Cost Price must be a number';
        } else {

        }
      }

      if (!isMissing(data['total_value'])) {
        const num = typeof data['total_value'] === 'number' ? data['total_value'] : Number(data['total_value']);
        if (Number.isNaN(num)) {
          fieldErrors['total_value'] = 'Total Value must be a number';
        } else {

        }
      }

      if (!isMissing(data['reserved_quantity'])) {
        const num = typeof data['reserved_quantity'] === 'number' ? data['reserved_quantity'] : Number(data['reserved_quantity']);
        if (Number.isNaN(num)) {
          fieldErrors['reserved_quantity'] = 'Reserved Quantity must be a number';
        } else {

          if (!Number.isInteger(num)) fieldErrors['reserved_quantity'] = 'Reserved Quantity must be an integer';

        }
      }

      if (!isMissing(data['committed_quantity'])) {
        const num = typeof data['committed_quantity'] === 'number' ? data['committed_quantity'] : Number(data['committed_quantity']);
        if (Number.isNaN(num)) {
          fieldErrors['committed_quantity'] = 'Committed Quantity must be a number';
        } else {

          if (!Number.isInteger(num)) fieldErrors['committed_quantity'] = 'Committed Quantity must be an integer';

        }
      }

      if (!isMissing(data['available_quantity'])) {
        const num = typeof data['available_quantity'] === 'number' ? data['available_quantity'] : Number(data['available_quantity']);
        if (Number.isNaN(num)) {
          fieldErrors['available_quantity'] = 'Available Quantity must be a number';
        } else {

          if (!Number.isInteger(num)) fieldErrors['available_quantity'] = 'Available Quantity must be an integer';

        }
      }

      if (!isMissing(data['serial_number']) && existingItems.some((it) => String(it['serial_number']) === String(data['serial_number']))) {
        fieldErrors['serial_number'] = 'Serial Number must be unique';
      }

      if (!isMissing(data['location_id'])) {
        const ids = await getRefIdSet('locations');
        if (!ids.has(String(data['location_id']))) fieldErrors['location_id'] = 'Location Id has an invalid reference';
      }

      if (Object.keys(fieldErrors).length) {
        const err = new Error('Validation failed');
        err.statusCode = 400;
        err.fieldErrors = fieldErrors;
        throw err;
      }

    
      {
      // LocationMixin: Ensure location reference is present
            // Supports either a single location_id or multiple location_ids (array of IDs).
            const locationConfig = this.mixinConfig?.location || {};
            const requireLocation = locationConfig.require_location !== false && locationConfig.requireLocation !== false;
            if (requireLocation) {
              const hasSingle = data.location_id !== undefined && data.location_id !== null && String(data.location_id).trim() !== '';
              const hasMulti = Array.isArray(data.location_ids) && data.location_ids.length > 0;
              if (!hasSingle && !hasMulti) {
                throw new Error('Location is required');
              }
            }
            // Optional: Verify location exists (requires repository access)
            // const loc = await this.repository.findById('locations', data.location_id);
            // if (!loc) throw new Error('Invalid location ID');
      }

    
      {
      if (!data.serial_number || !String(data.serial_number).trim()) {
              throw new Error('Serial number is required');
            }
            data.serial_number = String(data.serial_number).trim();
      
            const serialConfig = this.mixinConfig?.serial_tracking || {};
            const enforceUnique = serialConfig.enforce_unique !== false && serialConfig.enforceUnique !== false;
            const quantityPolicy = serialConfig.quantity_policy || serialConfig.quantityPolicy || 'fixed_one';
      
            if (enforceUnique) {
              const existing = await this.repository.findAll(this.slug, { serial_number: data.serial_number });
              if (existing.length > 0) {
                const err = new Error(`Serial number '${data.serial_number}' is already in use`);
                err.statusCode = 409;
                throw err;
              }
            }
      
            if (quantityPolicy !== 'allow_any') {
              data.quantity = 1;
            }
      }

    
      {
      // BatchTrackingMixin: Ensure batch number is provided
            if (!data.batch_number) {
              throw new Error('Batch number is required for this item');
            }
      
            const batchConfig = this.mixinConfig?.batch_tracking || {};
            const requireExpiry = batchConfig.require_expiry === true || batchConfig.requireExpiry === true;
            const allowPastExpiry = batchConfig.allow_past_expiry !== false && batchConfig.allowPastExpiry !== false;
      
            if (requireExpiry && !data.expiry_date) {
              throw new Error('Expiry date is required for this item');
            }
            
            // BatchTrackingMixin: Validate expiry date if provided
            if (data.expiry_date) {
              const expiry = new Date(data.expiry_date);
              if (isNaN(expiry.getTime())) {
                throw new Error('Invalid expiry date format');
              }
              if (!allowPastExpiry && expiry < new Date()) {
                throw new Error('Expiry date cannot be in the past');
              }
              }
      }

    
      {
      const __cfg = this.mixinConfig?.inventory_reservation || this.mixinConfig?.inventoryReservation || {};
            const __qtyField = __cfg.quantity_field || __cfg.quantityField || 'quantity';
            const __reservedField = __cfg.reserved_field || __cfg.reservedField || 'reserved_quantity';
            const __committedField = __cfg.committed_field || __cfg.committedField || 'committed_quantity';
            const __availableField = __cfg.available_field || __cfg.availableField || 'available_quantity';
            const __autoAvailable = __cfg.auto_calculate_available === true || __cfg.autoCalculateAvailable === true;
            const __enforce = __cfg.enforce !== false && __cfg.enforceRules !== false;
      
            const __readNumber = (value) => {
              if (value === undefined || value === null || value === '') return null;
              const num = Number(value);
              return Number.isNaN(num) ? null : num;
            };
      
            const __qty = __readNumber(data[__qtyField]);
            const __reserved = __readNumber(data[__reservedField]);
            const __committed = __readNumber(data[__committedField]);
            const __hasReservations = __reserved !== null || __committed !== null;
      
            if (__enforce && __qty !== null && __hasReservations) {
              const __reservedVal = __reserved ?? 0;
              const __committedVal = __committed ?? 0;
              if (__reservedVal < 0 || __committedVal < 0) {
                throw new Error('Reserved and committed quantities cannot be negative');
              }
              if (__reservedVal + __committedVal > __qty) {
                throw new Error('Reserved + committed quantities cannot exceed on-hand quantity');
              }
            }
      
            if (__autoAvailable && __qty !== null && __hasReservations && __availableField) {
              const __reservedVal = __reserved ?? 0;
              const __committedVal = __committed ?? 0;
              data[__availableField] = __qty - __reservedVal - __committedVal;
            }
      }

    
    // @HOOK: BEFORE_CREATE_TRANSFORMATION
    
      {
      // BatchTrackingMixin: Normalize batch fields
            data.batch_number = String(data.batch_number).trim().toUpperCase();
            if (data.expiry_date) {
              data.expiry_date = new Date(data.expiry_date).toISOString();
            }
      }

    
      {
      const __cfg = this.mixinConfig?.inventory_lifecycle || this.mixinConfig?.inventoryLifecycle || {};
            const __statusField = __cfg.status_field || __cfg.statusField || 'status';
            const __statuses = Array.isArray(__cfg.statuses) && __cfg.statuses.length ? __cfg.statuses : null;
            const __defaultStatus = __cfg.default_status || __cfg.defaultStatus;
      
            if (data && data[__statusField] === undefined && __defaultStatus) {
              data[__statusField] = __defaultStatus;
            }
      
            if (__statuses && data && data[__statusField] !== undefined && !__statuses.includes(data[__statusField])) {
              throw new Error(`${__statusField} must be one of: ${__statuses.join(', ')}`);
            }
      }

    
      {
      // InventoryMixin: Initialize quantity if not present
            if (data.quantity === undefined || data.quantity === null) {
              data.quantity = 0;
            }
            data.quantity = Number(data.quantity);
            if (isNaN(data.quantity)) throw new Error('Quantity must be a number');
      }

    
    const result = await this.repository.create(this.slug, data);
    
    // @HOOK: AFTER_CREATE_LOGGING
    
    return result;
  }

  async update(id, data) {
    // @HOOK: BEFORE_UPDATE_VALIDATION
    
      // Schema-driven validation (generated)
      const existing = await this.repository.findById(this.slug, id);
      if (!existing) return null;
      const merged = { ...existing, ...data };

      const fieldErrors = {};
      const isMissing = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
      const isMissingNonString = (v) => v === undefined || v === null;

      const existingItems = await this.repository.findAll(this.slug);

      const __refIdSets = {};
      const getRefIdSet = async (slug) => {
        if (__refIdSets[slug]) return __refIdSets[slug];
        const all = await this.repository.findAll(slug);
        __refIdSets[slug] = new Set(all.map((x) => x.id));
        return __refIdSets[slug];
      };

      if (isMissing(merged['name'])) fieldErrors['name'] = 'Name is required';

      if (!isMissing(merged['sku']) && existingItems.some((it) => it.id !== id && String(it['sku']) === String(merged['sku']))) {
        fieldErrors['sku'] = 'Sku must be unique';
      }

      if (isMissing(merged['quantity'])) fieldErrors['quantity'] = 'Quantity is required';

      if (!isMissing(merged['quantity'])) {
        const num = typeof merged['quantity'] === 'number' ? merged['quantity'] : Number(merged['quantity']);
        if (Number.isNaN(num)) {
          fieldErrors['quantity'] = 'Quantity must be a number';
        } else {

          if (!Number.isInteger(num)) fieldErrors['quantity'] = 'Quantity must be an integer';

        }
      }

      if (!isMissing(merged['reorder_point'])) {
        const num = typeof merged['reorder_point'] === 'number' ? merged['reorder_point'] : Number(merged['reorder_point']);
        if (Number.isNaN(num)) {
          fieldErrors['reorder_point'] = 'Reorder Point must be a number';
        } else {

          if (!Number.isInteger(num)) fieldErrors['reorder_point'] = 'Reorder Point must be an integer';

        }
      }

      if (!isMissing(merged['cost_price'])) {
        const num = typeof merged['cost_price'] === 'number' ? merged['cost_price'] : Number(merged['cost_price']);
        if (Number.isNaN(num)) {
          fieldErrors['cost_price'] = 'Cost Price must be a number';
        } else {

        }
      }

      if (!isMissing(merged['total_value'])) {
        const num = typeof merged['total_value'] === 'number' ? merged['total_value'] : Number(merged['total_value']);
        if (Number.isNaN(num)) {
          fieldErrors['total_value'] = 'Total Value must be a number';
        } else {

        }
      }

      if (!isMissing(merged['reserved_quantity'])) {
        const num = typeof merged['reserved_quantity'] === 'number' ? merged['reserved_quantity'] : Number(merged['reserved_quantity']);
        if (Number.isNaN(num)) {
          fieldErrors['reserved_quantity'] = 'Reserved Quantity must be a number';
        } else {

          if (!Number.isInteger(num)) fieldErrors['reserved_quantity'] = 'Reserved Quantity must be an integer';

        }
      }

      if (!isMissing(merged['committed_quantity'])) {
        const num = typeof merged['committed_quantity'] === 'number' ? merged['committed_quantity'] : Number(merged['committed_quantity']);
        if (Number.isNaN(num)) {
          fieldErrors['committed_quantity'] = 'Committed Quantity must be a number';
        } else {

          if (!Number.isInteger(num)) fieldErrors['committed_quantity'] = 'Committed Quantity must be an integer';

        }
      }

      if (!isMissing(merged['available_quantity'])) {
        const num = typeof merged['available_quantity'] === 'number' ? merged['available_quantity'] : Number(merged['available_quantity']);
        if (Number.isNaN(num)) {
          fieldErrors['available_quantity'] = 'Available Quantity must be a number';
        } else {

          if (!Number.isInteger(num)) fieldErrors['available_quantity'] = 'Available Quantity must be an integer';

        }
      }

      if (!isMissing(merged['serial_number']) && existingItems.some((it) => it.id !== id && String(it['serial_number']) === String(merged['serial_number']))) {
        fieldErrors['serial_number'] = 'Serial Number must be unique';
      }

      if (!isMissing(merged['location_id'])) {
        const ids = await getRefIdSet('locations');
        if (!ids.has(String(merged['location_id']))) fieldErrors['location_id'] = 'Location Id has an invalid reference';
      }

      if (Object.keys(fieldErrors).length) {
        const err = new Error('Validation failed');
        err.statusCode = 400;
        err.fieldErrors = fieldErrors;
        throw err;
      }

    
      {
      // SerialTrackingMixin: Cannot change quantity of serialized item
            const serialConfig = this.mixinConfig?.serial_tracking || {};
            const quantityPolicy = serialConfig.quantity_policy || serialConfig.quantityPolicy || 'fixed_one';
            if (quantityPolicy !== 'allow_any') {
              if (data.quantity !== undefined && data.quantity !== 1) {
                throw new Error('Serialized items must have quantity of 1');
              }
            }
      }

    
      {
      const __cfg = this.mixinConfig?.inventory_reservation || this.mixinConfig?.inventoryReservation || {};
            const __qtyField = __cfg.quantity_field || __cfg.quantityField || 'quantity';
            const __reservedField = __cfg.reserved_field || __cfg.reservedField || 'reserved_quantity';
            const __committedField = __cfg.committed_field || __cfg.committedField || 'committed_quantity';
            const __availableField = __cfg.available_field || __cfg.availableField || 'available_quantity';
            const __autoAvailable = __cfg.auto_calculate_available === true || __cfg.autoCalculateAvailable === true;
            const __enforce = __cfg.enforce !== false && __cfg.enforceRules !== false;
      
            const __existing = await this.repository.findById(this.slug, id);
      
            const __readNumber = (value) => {
              if (value === undefined || value === null || value === '') return null;
              const num = Number(value);
              return Number.isNaN(num) ? null : num;
            };
      
            const __getValue = (field) => {
              if (data && data[field] !== undefined) return __readNumber(data[field]);
              if (__existing && __existing[field] !== undefined) return __readNumber(__existing[field]);
              return null;
            };
      
            const __qty = __getValue(__qtyField);
            const __reserved = __getValue(__reservedField);
            const __committed = __getValue(__committedField);
            const __hasReservations = __reserved !== null || __committed !== null;
      
            if (__enforce && __qty !== null && __hasReservations) {
              const __reservedVal = __reserved ?? 0;
              const __committedVal = __committed ?? 0;
              if (__reservedVal < 0 || __committedVal < 0) {
                throw new Error('Reserved and committed quantities cannot be negative');
              }
              if (__reservedVal + __committedVal > __qty) {
                throw new Error('Reserved + committed quantities cannot exceed on-hand quantity');
              }
            }
      
            if (__autoAvailable && __qty !== null && __hasReservations && __availableField) {
              const __reservedVal = __reserved ?? 0;
              const __committedVal = __committed ?? 0;
              data[__availableField] = __qty - __reservedVal - __committedVal;
            }
      }

    
      {
      const __cfg = this.mixinConfig?.inventory_lifecycle || this.mixinConfig?.inventoryLifecycle || {};
            const __statusField = __cfg.status_field || __cfg.statusField || 'status';
            const __statuses = Array.isArray(__cfg.statuses) && __cfg.statuses.length ? __cfg.statuses : null;
            const __enforceTransitions = __cfg.enforce_transitions === true || __cfg.enforceTransitions === true;
            const __customTransitions = __cfg.transitions && typeof __cfg.transitions === 'object' ? __cfg.transitions : null;
            const __defaultTransitions = {
              Draft: ['Active', 'Obsolete'],
              Active: ['Obsolete'],
              Obsolete: [],
            };
            const __transitions = __customTransitions || (__cfg.use_default_transitions === true || __cfg.useDefaultTransitions === true ? __defaultTransitions : null);
      
            if (data && data[__statusField] !== undefined) {
              const __nextStatus = data[__statusField];
              if (__statuses && !__statuses.includes(__nextStatus)) {
                throw new Error(`${__statusField} must be one of: ${__statuses.join(', ')}`);
              }
      
              if (__enforceTransitions && __transitions) {
                const __existing = await this.repository.findById(this.slug, id);
                const __currentStatus = __existing ? __existing[__statusField] : null;
      
                if (__currentStatus && __currentStatus !== __nextStatus) {
                  const __allowed = Array.isArray(__transitions[__currentStatus]) ? __transitions[__currentStatus] : [];
                  if (!__allowed.includes(__nextStatus)) {
                    throw new Error(`Invalid status transition: ${__currentStatus} -> ${__nextStatus}`);
                  }
                }
              }
            }
      }

    
      {
      // InventoryMixin: Validate quantity updates
            if (data.quantity !== undefined) {
              const newQty = Number(data.quantity);
              if (isNaN(newQty)) throw new Error('Quantity must be a number');
      
              const inventoryConfig = this.mixinConfig?.inventory || {};
              const allowNegative = inventoryConfig.allow_negative === true || inventoryConfig.allowNegative === true;
      
              // Prevent negative stock unless allow_negative is true
              if (!allowNegative && newQty < 0) {
                throw new Error('Stock cannot be negative');
              }
            }
      }

    
    const result = await this.repository.update(this.slug, id, data);
    
    // @HOOK: AFTER_UPDATE_LOGGING

    return result;
  }

  async delete(id) {
    // @HOOK: BEFORE_DELETE_VALIDATION
    
      // Delete protection (generated): prevent deleting a record that is referenced by others
      const dependents = [];

      {
        const rows = await this.repository.findAll('stock_movements');
        const matches = rows.filter((row) => String(row['item_id'] ?? '') === String(id));
        if (matches.length) {
          dependents.push({
            entity: 'stock_movements',
            via: ['item_id'],
            count: matches.length,
            preview: matches.slice(0, 10).map((r) => ({ id: r.id, display: r['item_id'] || r.id })),
          });
        }
      }

      {
        const rows = await this.repository.findAll('stock_reservations');
        const matches = rows.filter((row) => String(row['item_id'] ?? '') === String(id));
        if (matches.length) {
          dependents.push({
            entity: 'stock_reservations',
            via: ['item_id'],
            count: matches.length,
            preview: matches.slice(0, 10).map((r) => ({ id: r.id, display: r['reservation_number'] || r.id })),
          });
        }
      }

      {
        const rows = await this.repository.findAll('purchase_order_items');
        const matches = rows.filter((row) => String(row['item_id'] ?? '') === String(id));
        if (matches.length) {
          dependents.push({
            entity: 'purchase_order_items',
            via: ['item_id'],
            count: matches.length,
            preview: matches.slice(0, 10).map((r) => ({ id: r.id, display: r['purchase_order_id'] || r.id })),
          });
        }
      }

      {
        const rows = await this.repository.findAll('goods_receipt_items');
        const matches = rows.filter((row) => String(row['item_id'] ?? '') === String(id));
        if (matches.length) {
          dependents.push({
            entity: 'goods_receipt_items',
            via: ['item_id'],
            count: matches.length,
            preview: matches.slice(0, 10).map((r) => ({ id: r.id, display: r['goods_receipt_id'] || r.id })),
          });
        }
      }

      {
        const rows = await this.repository.findAll('cycle_count_lines');
        const matches = rows.filter((row) => String(row['item_id'] ?? '') === String(id));
        if (matches.length) {
          dependents.push({
            entity: 'cycle_count_lines',
            via: ['item_id'],
            count: matches.length,
            preview: matches.slice(0, 10).map((r) => ({ id: r.id, display: r['cycle_count_session_id'] || r.id })),
          });
        }
      }

      if (dependents.length) {
        const err = new Error('Cannot delete: this record is referenced by other records');
        err.statusCode = 409;
        err.dependents = dependents;
        throw err;
      }


    const result = await this.repository.delete(this.slug, id);
    
    // @HOOK: AFTER_DELETE_LOGGING

    return result;
  }

  async findById(id) {
    return this.repository.findById(this.slug, id);
  }

  async findAll(filter = {}) {
    return this.repository.findAll(this.slug, filter);
  }

  // @HOOK: ADDITIONAL_METHODS
    
  async moveStock(itemId, targetLocationId, quantity) {
    const locationConfig = this.mixinConfig?.location || {};
    const displayField = locationConfig.display_field || locationConfig.displayField || 'name';

    const doMove = async (client) => {
      const findById = client
        ? (slug, id) => this.repository.findByIdForUpdate(slug, id, client)
        : (slug, id) => this.repository.findById(slug, id);
      const update = client
        ? (slug, id, patch) => this.repository.updateWithClient(slug, id, patch, client)
        : (slug, id, patch) => this.repository.update(slug, id, patch);
      const findAll = client
        ? (slug, filter) => this.repository.findAllWithClient(slug, filter, client)
        : (slug, filter) => this.repository.findAll(slug, filter);
      const create = client
        ? (slug, data) => this.repository.createWithClient(slug, data, client)
        : (slug, data) => this.repository.create(slug, data);

      const item = await findById(this.slug, itemId);
      if (!item) throw new Error('Item not found');

      const currentQty = Number(item.quantity) || 0;
      if (currentQty < quantity) throw new Error('Insufficient quantity to move');

      await update(this.slug, itemId, { quantity: currentQty - quantity });

      const matchField = item[displayField] ? displayField : (item.name ? 'name' : null);
      const filter = { location_id: targetLocationId };
      if (matchField) filter[matchField] = item[matchField];

      const targetItems = await findAll(this.slug, filter);

      if (targetItems.length > 0) {
        const targetItem = targetItems[0];
        const targetQty = Number(targetItem.quantity) || 0;
        await update(this.slug, targetItem.id, { quantity: targetQty + quantity });
        return targetItem;
      } else {
        const { id: _discardId, ...itemData } = item;
        return create(this.slug, { ...itemData, location_id: targetLocationId, quantity: quantity });
      }
    };

    if (typeof this.repository.withTransaction === 'function') {
      return this.repository.withTransaction(doMove);
    }
    return doMove(null);
  }
  
    
  async findByBatch(batchNumber) {
    return this.repository.findAll(this.slug, { batch_number: batchNumber });
  }

  async getExpiredItems(beforeDate) {
    const cutoff = beforeDate instanceof Date ? beforeDate : new Date();
    const cutoffIso = cutoff.toISOString();

    if (typeof this.repository.findAllWhere === 'function') {
      return this.repository.findAllWhere(this.slug, 'expiry_date', '<', cutoffIso);
    }

    const allItems = await this.repository.findAll(this.slug);
    return allItems.filter(item => item.expiry_date && new Date(item.expiry_date) < cutoff);
  }
  
    
  _invResCfg() {
    const cfg =
      this.mixinConfig?.inventory_reservation_workflow ||
      this.mixinConfig?.inventoryReservationWorkflow ||
      this.mixinConfig?.inventory_reservation ||
      this.mixinConfig?.inventoryReservation ||
      {};
    return {
      stock_entity: cfg.stock_entity || cfg.stockEntity || this.slug,
      reservation_entity: cfg.reservation_entity || cfg.reservationEntity || 'stock_reservations',
      item_field: cfg.item_field || cfg.itemField || cfg.item_ref_field || cfg.itemRefField || 'item_id',
      quantity_field: cfg.quantity_field || cfg.quantityField || 'quantity',
      status_field: cfg.status_field || cfg.statusField || 'status',
      stock_quantity_field: cfg.stock_quantity_field || cfg.stockQuantityField || 'quantity',
      reserved_field: cfg.reserved_field || cfg.reservedField || 'reserved_quantity',
      committed_field: cfg.committed_field || cfg.committedField || 'committed_quantity',
      available_field: cfg.available_field || cfg.availableField || 'available_quantity',
      consume_on_commit: cfg.consume_on_commit === true || cfg.consumeOnCommit === true,
    };
  }

  _invResErr(message, statusCode = 400, details = null) {
    const err = new Error(message);
    err.statusCode = statusCode;
    if (details) err.details = details;
    return err;
  }

  _invResPositive(raw, fieldName = 'quantity') {
    const num = Number(raw);
    if (!Number.isFinite(num) || num <= 0) {
      throw this._invResErr(`${fieldName} must be greater than zero`, 400);
    }
    return num;
  }

  _invResNowIso() {
    return new Date().toISOString();
  }

  async listReservations(itemId, filter = {}) {
    const cfg = this._invResCfg();
    if (cfg.stock_entity !== this.slug) {
      throw this._invResErr(
        `Reservation workflow can only run on '${cfg.stock_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    const where = {
      [cfg.item_field]: itemId,
    };

    if (filter && Object.prototype.hasOwnProperty.call(filter, cfg.status_field)) {
      where[cfg.status_field] = filter[cfg.status_field];
    } else if (filter && Object.prototype.hasOwnProperty.call(filter, 'status')) {
      where[cfg.status_field] = filter.status;
    }

    return this.repository.findAll(cfg.reservation_entity, where);
  }

  async reserveStock(itemId, payload = {}) {
    const cfg = this._invResCfg();
    if (cfg.stock_entity !== this.slug) {
      throw this._invResErr(
        `Reservation workflow can only run on '${cfg.stock_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    const quantity = this._invResPositive(
      payload.quantity ?? payload.qty ?? payload[cfg.quantity_field],
      cfg.quantity_field
    );
    const nowIso = this._invResNowIso();

    return this.repository.withTransaction(async (client) => {
      const stock = await this.repository.atomicAdjustReservation(
        this.slug,
        itemId,
        {
          quantityField: cfg.stock_quantity_field,
          reservedField: cfg.reserved_field,
          committedField: cfg.committed_field,
          availableField: cfg.available_field,
          reservedDelta: quantity,
          committedDelta: 0,
          quantityDelta: 0,
          allow_negative_stock: false,
        },
        client
      );

      const reservationNumber =
        payload.reservation_number ||
        payload.reservationNumber ||
        payload.code ||
        `RSV-${Date.now()}-${Math.floor(Math.random() * 10000)}`;

      const record = {
        reservation_number: reservationNumber,
        [cfg.item_field]: itemId,
        [cfg.quantity_field]: quantity,
        [cfg.status_field]: 'Pending',
        reserved_at: nowIso,
      };

      const sourceReference =
        payload.source_reference ||
        payload.sourceReference ||
        payload.reference_number ||
        payload.referenceNumber ||
        null;
      if (sourceReference) record.source_reference = sourceReference;
      if (payload.note) record.note = payload.note;

      const reservation = await this.repository.createWithClient(cfg.reservation_entity, record, client);

      return {
        reservation,
        stock,
      };
    });
  }

  async releaseReservation(itemId, reservationId, payload = {}) {
    const cfg = this._invResCfg();
    if (cfg.stock_entity !== this.slug) {
      throw this._invResErr(
        `Reservation workflow can only run on '${cfg.stock_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    return this.repository.withTransaction(async (client) => {
      const reservation = await this.repository.findByIdForUpdate(cfg.reservation_entity, reservationId, client);
      if (!reservation) throw this._invResErr('Reservation not found', 404);
      if (String(reservation[cfg.item_field]) !== String(itemId)) {
        throw this._invResErr('Reservation does not belong to this item', 400);
      }

      const currentStatus = String(reservation[cfg.status_field] || 'Pending');
      if (currentStatus !== 'Pending') {
        throw this._invResErr('Only pending reservations can be released', 409, { status: currentStatus });
      }

      const quantity = this._invResPositive(reservation[cfg.quantity_field], cfg.quantity_field);

      const stock = await this.repository.atomicAdjustReservation(
        this.slug,
        itemId,
        {
          quantityField: cfg.stock_quantity_field,
          reservedField: cfg.reserved_field,
          committedField: cfg.committed_field,
          availableField: cfg.available_field,
          reservedDelta: -quantity,
          committedDelta: 0,
          quantityDelta: 0,
          allow_negative_stock: false,
        },
        client
      );

      const updatePayload = {
        [cfg.status_field]: 'Released',
        released_at: this._invResNowIso(),
      };
      if (payload.note) updatePayload.note = payload.note;
      const updatedReservation = await this.repository.updateWithClient(
        cfg.reservation_entity,
        reservationId,
        updatePayload,
        client
      );

      return {
        reservation: updatedReservation,
        stock,
      };
    });
  }

  async commitReservation(itemId, reservationId, payload = {}) {
    const cfg = this._invResCfg();
    if (cfg.stock_entity !== this.slug) {
      throw this._invResErr(
        `Reservation workflow can only run on '${cfg.stock_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    return this.repository.withTransaction(async (client) => {
      const reservation = await this.repository.findByIdForUpdate(cfg.reservation_entity, reservationId, client);
      if (!reservation) throw this._invResErr('Reservation not found', 404);
      if (String(reservation[cfg.item_field]) !== String(itemId)) {
        throw this._invResErr('Reservation does not belong to this item', 400);
      }

      const currentStatus = String(reservation[cfg.status_field] || 'Pending');
      if (currentStatus !== 'Pending') {
        throw this._invResErr('Only pending reservations can be committed', 409, { status: currentStatus });
      }

      const quantity = this._invResPositive(reservation[cfg.quantity_field], cfg.quantity_field);
      const stockAdjustment = cfg.consume_on_commit
        ? {
            quantityDelta: -quantity,
            reservedDelta: -quantity,
            committedDelta: 0,
          }
        : {
            quantityDelta: 0,
            reservedDelta: -quantity,
            committedDelta: quantity,
          };

      const stock = await this.repository.atomicAdjustReservation(
        this.slug,
        itemId,
        {
          quantityField: cfg.stock_quantity_field,
          reservedField: cfg.reserved_field,
          committedField: cfg.committed_field,
          availableField: cfg.available_field,
          ...stockAdjustment,
          allow_negative_stock: false,
        },
        client
      );

      const updatePayload = {
        [cfg.status_field]: 'Committed',
        committed_at: this._invResNowIso(),
      };
      if (payload.note) updatePayload.note = payload.note;
      const updatedReservation = await this.repository.updateWithClient(
        cfg.reservation_entity,
        reservationId,
        updatePayload,
        client
      );

      return {
        reservation: updatedReservation,
        stock,
      };
    });
  }
  
    
  _invTxnConfig() {
    const cfg =
      this.mixinConfig?.inventory_transaction_safety ||
      this.mixinConfig?.inventoryTransactionSafety ||
      this.mixinConfig?.inventory_transactions ||
      this.mixinConfig?.inventoryTransactions ||
      {};
    const fields = cfg.fields && typeof cfg.fields === 'object' ? cfg.fields : {};
    const movementTypes = cfg.movement_types && typeof cfg.movement_types === 'object'
      ? cfg.movement_types
      : (cfg.movementTypes && typeof cfg.movementTypes === 'object' ? cfg.movementTypes : {});
    return {
      stock_entity: cfg.stock_entity || cfg.stockEntity || this.slug,
      quantity_field: cfg.quantity_field || cfg.quantityField || 'quantity',
      quantity_mode: String(cfg.quantity_mode || cfg.quantityMode || 'change').toLowerCase() === 'absolute' ? 'absolute' : 'change',
      movement_entity: cfg.movement_entity || cfg.movementEntity || 'stock_movements',
      allow_negative_stock:
        cfg.allow_negative_stock === true ||
        cfg.allowNegativeStock === true,
      log_movements: cfg.log_movements !== false && cfg.logMovements !== false,
      fields: {
        item_ref: fields.item_ref || fields.itemRef || 'item_id',
        qty: fields.qty || 'quantity',
        type: fields.type || 'movement_type',
        location: fields.location || fields.location_id || fields.locationId || 'location_id',
        reason: fields.reason || 'reason',
        reference_number: fields.reference_number || fields.referenceNumber || 'reference_number',
        date: fields.date || fields.movement_date || fields.movementDate || 'movement_date',
        from_location: fields.from_location || fields.fromLocation || fields.from_location_id || fields.fromLocationId || 'from_location_id',
        to_location: fields.to_location || fields.toLocation || fields.to_location_id || fields.toLocationId || 'to_location_id',
      },
      movement_types: {
        receive: movementTypes.receive || movementTypes.in || 'IN',
        issue: movementTypes.issue || movementTypes.out || 'OUT',
        adjust: movementTypes.adjust || 'ADJUSTMENT',
        transfer_out: movementTypes.transfer_out || movementTypes.transferOut || 'TRANSFER_OUT',
        transfer_in: movementTypes.transfer_in || movementTypes.transferIn || 'TRANSFER_IN',
      },
    };
  }

  _invTxnError(message, statusCode = 400, details = null) {
    const err = new Error(message);
    err.statusCode = statusCode;
    if (details) err.details = details;
    return err;
  }

  _invTxnPositiveNumber(raw, fieldName) {
    const num = Number(raw);
    if (!Number.isFinite(num) || num <= 0) {
      throw this._invTxnError(`${fieldName} must be greater than zero`, 400);
    }
    return num;
  }

  _invTxnMovementQuantity(mode, operation, quantity, delta) {
    if (mode === 'absolute') {
      return Math.abs(quantity);
    }
    if (operation === 'adjust') return delta;
    if (operation === 'issue') return -Math.abs(quantity);
    if (operation === 'receive') return Math.abs(quantity);
    return quantity;
  }

  _invTxnBuildMovementRow(cfg, operation, itemId, payload, movementQty, movementType, locationOverride = null) {
    const row = {};
    row[cfg.fields.item_ref] = itemId;
    row[cfg.fields.type] = movementType;
    row[cfg.fields.qty] = movementQty;

    const locationValue = locationOverride === null
      ? (payload.location_id || payload.locationId || payload[cfg.fields.location])
      : locationOverride;
    if (locationValue !== undefined && locationValue !== null && locationValue !== '') {
      row[cfg.fields.location] = locationValue;
    }

    const movementDate =
      payload.movement_date ||
      payload.movementDate ||
      payload.date ||
      payload[cfg.fields.date] ||
      new Date().toISOString();
    row[cfg.fields.date] = movementDate;

    const reason = payload.reason || payload.note || payload[cfg.fields.reason];
    if (reason !== undefined && reason !== null && reason !== '') {
      row[cfg.fields.reason] = reason;
    }

    const ref =
      payload.reference_number ||
      payload.referenceNumber ||
      payload[cfg.fields.reference_number];
    if (ref !== undefined && ref !== null && ref !== '') {
      row[cfg.fields.reference_number] = ref;
    }

    const fromLocation = payload.from_location_id || payload.fromLocationId || payload[cfg.fields.from_location];
    if (fromLocation !== undefined && fromLocation !== null && fromLocation !== '') {
      row[cfg.fields.from_location] = fromLocation;
    }
    const toLocation = payload.to_location_id || payload.toLocationId || payload[cfg.fields.to_location];
    if (toLocation !== undefined && toLocation !== null && toLocation !== '') {
      row[cfg.fields.to_location] = toLocation;
    }

    return row;
  }

  async _invTxnCreateMovements(client, cfg, rows) {
    if (!cfg.log_movements || !cfg.movement_entity) return;
    for (const row of rows) {
      await this.repository.createWithClient(cfg.movement_entity, row, client);
    }
  }

  async _invTxnApplyStockOperation(itemId, operation, payload = {}) {
    const cfg = this._invTxnConfig();
    const stockSlug = cfg.stock_entity || this.slug;
    if (stockSlug !== this.slug) {
      throw this._invTxnError(
        `Workflow can only run on '${stockSlug}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    let qty = 0;
    let delta = 0;

    if (operation === 'adjust') {
      const deltaRaw = payload.delta ?? payload.quantity ?? payload.qty ?? payload[cfg.fields.qty];
      const parsedDelta = Number(deltaRaw);
      if (!Number.isFinite(parsedDelta) || parsedDelta === 0) {
        throw this._invTxnError('delta must be a non-zero number for adjust operation', 400);
      }
      delta = parsedDelta;
      qty = Math.abs(parsedDelta);
    } else if (operation === 'receive' || operation === 'issue') {
      const qtyRaw =
        payload.quantity ??
        payload.qty ??
        payload[cfg.fields.qty];
      qty = this._invTxnPositiveNumber(qtyRaw, 'quantity');
      delta = operation === 'receive' ? qty : -qty;
    } else if (operation === 'transfer') {
      const qtyRaw =
        payload.quantity ??
        payload.qty ??
        payload[cfg.fields.qty];
      qty = this._invTxnPositiveNumber(qtyRaw, 'quantity');
      delta = 0;
      const fromLocation = payload.from_location_id || payload.fromLocationId || payload[cfg.fields.from_location];
      const toLocation = payload.to_location_id || payload.toLocationId || payload[cfg.fields.to_location];
      if (!fromLocation || !toLocation) {
        throw this._invTxnError('transfer requires both from and to locations', 400);
      }
      if (String(fromLocation) === String(toLocation)) {
        throw this._invTxnError('from and to locations must be different for transfer', 400);
      }
    } else {
      throw this._invTxnError(`Unsupported stock operation '${operation}'`, 400);
    }

    return this.repository.withTransaction(async (client) => {
      let updatedItem;
      if (delta !== 0) {
        updatedItem = await this.repository.atomicAdjustQuantity(
          this.slug,
          itemId,
          delta,
          {
            quantityField: cfg.quantity_field,
            allow_negative_stock: cfg.allow_negative_stock,
          },
          client
        );
      } else {
        updatedItem = await this.repository.findByIdForUpdate(this.slug, itemId, client);
        if (!updatedItem) throw this._invTxnError('Item not found', 404);
      }

      const movementRows = [];
      if (operation === 'transfer') {
        const outQty = cfg.quantity_mode === 'absolute' ? Math.abs(qty) : -Math.abs(qty);
        const inQty = cfg.quantity_mode === 'absolute' ? Math.abs(qty) : Math.abs(qty);
        movementRows.push(
          this._invTxnBuildMovementRow(
            cfg,
            operation,
            itemId,
            payload,
            outQty,
            cfg.movement_types.transfer_out,
            payload.from_location_id || payload.fromLocationId || payload[cfg.fields.from_location]
          )
        );
        movementRows.push(
          this._invTxnBuildMovementRow(
            cfg,
            operation,
            itemId,
            payload,
            inQty,
            cfg.movement_types.transfer_in,
            payload.to_location_id || payload.toLocationId || payload[cfg.fields.to_location]
          )
        );
      } else {
        const movementType =
          operation === 'receive'
            ? cfg.movement_types.receive
            : operation === 'issue'
              ? cfg.movement_types.issue
              : cfg.movement_types.adjust;
        const movementQty = this._invTxnMovementQuantity(cfg.quantity_mode, operation, qty, delta);
        movementRows.push(
          this._invTxnBuildMovementRow(cfg, operation, itemId, payload, movementQty, movementType)
        );
      }

      await this._invTxnCreateMovements(client, cfg, movementRows);

      return {
        operation,
        item: updatedItem,
        delta,
        movement_count: movementRows.length,
      };
    });
  }

  async applyStockReceive(itemId, payload = {}) {
    return this._invTxnApplyStockOperation(itemId, 'receive', payload);
  }

  async applyStockIssue(itemId, payload = {}) {
    return this._invTxnApplyStockOperation(itemId, 'issue', payload);
  }

  async applyStockAdjust(itemId, payload = {}) {
    return this._invTxnApplyStockOperation(itemId, 'adjust', payload);
  }

  async applyStockTransfer(itemId, payload = {}) {
    return this._invTxnApplyStockOperation(itemId, 'transfer', payload);
  }
  
    
  async adjustStock(id, delta) {
    const inventoryConfig = this.mixinConfig?.inventory || {};
    const allowNegative = inventoryConfig.allow_negative === true || inventoryConfig.allowNegative === true;

    if (typeof this.repository.atomicAdjustQuantity === 'function') {
      return this.repository.atomicAdjustQuantity(this.slug, id, delta, {
        quantityField: 'quantity',
        allow_negative_stock: allowNegative,
      });
    }

    const item = await this.repository.findById(this.slug, id);
    if (!item) throw new Error('Item not found');

    const currentQty = Number(item.quantity) || 0;
    const newQty = currentQty + delta;

    if (!allowNegative && newQty < 0) {
      throw new Error(`Insufficient stock. Current: ${currentQty}, Delta: ${delta}`);
    }

    return this.repository.update(this.slug, id, { quantity: newQty });
  }
  
}

module.exports = ProductsService;
