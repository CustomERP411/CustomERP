// brick-library/backend-bricks/core/BaseService.js.hbs
class Purchase_order_itemsService {
  constructor(repository, mixinConfig = {}) {
    this.repository = repository;
    this.slug = 'purchase_order_items';
    this.mixinConfig = mixinConfig && typeof mixinConfig === 'object' ? mixinConfig : {};
  }

  async create(data) {
    // @HOOK: BEFORE_CREATE_VALIDATION
    
      // Schema-driven validation (generated)
      const fieldErrors = {};
      const isMissing = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
      const isMissingNonString = (v) => v === undefined || v === null;

      const __refIdSets = {};
      const getRefIdSet = async (slug) => {
        if (__refIdSets[slug]) return __refIdSets[slug];
        const all = await this.repository.findAll(slug);
        __refIdSets[slug] = new Set(all.map((x) => x.id));
        return __refIdSets[slug];
      };

      if (isMissing(data['purchase_order_id'])) fieldErrors['purchase_order_id'] = 'Purchase Order Id is required';

      if (!isMissing(data['purchase_order_id'])) {
        const ids = await getRefIdSet('purchase_orders');
        if (!ids.has(String(data['purchase_order_id']))) fieldErrors['purchase_order_id'] = 'Purchase Order Id has an invalid reference';
      }

      if (isMissing(data['item_id'])) fieldErrors['item_id'] = 'Item Id is required';

      if (!isMissing(data['item_id'])) {
        const ids = await getRefIdSet('products');
        if (!ids.has(String(data['item_id']))) fieldErrors['item_id'] = 'Item Id has an invalid reference';
      }

      if (isMissing(data['ordered_quantity'])) fieldErrors['ordered_quantity'] = 'Ordered Quantity is required';

      if (!isMissing(data['ordered_quantity'])) {
        const num = typeof data['ordered_quantity'] === 'number' ? data['ordered_quantity'] : Number(data['ordered_quantity']);
        if (Number.isNaN(num)) {
          fieldErrors['ordered_quantity'] = 'Ordered Quantity must be a number';
        } else {

          if (!Number.isInteger(num)) fieldErrors['ordered_quantity'] = 'Ordered Quantity must be an integer';

        }
      }

      if (!isMissing(data['received_quantity'])) {
        const num = typeof data['received_quantity'] === 'number' ? data['received_quantity'] : Number(data['received_quantity']);
        if (Number.isNaN(num)) {
          fieldErrors['received_quantity'] = 'Received Quantity must be a number';
        } else {

          if (!Number.isInteger(num)) fieldErrors['received_quantity'] = 'Received Quantity must be an integer';

        }
      }

      const __allowed_status = ['Open', 'Partial', 'Received'];
      if (!isMissing(data['status']) && !__allowed_status.includes(String(data['status']))) fieldErrors['status'] = 'Status must be one of: Open, Partial, Received';

      if (!isMissing(data['unit_cost'])) {
        const num = typeof data['unit_cost'] === 'number' ? data['unit_cost'] : Number(data['unit_cost']);
        if (Number.isNaN(num)) {
          fieldErrors['unit_cost'] = 'Unit Cost must be a number';
        } else {

          if (num < 0) fieldErrors['unit_cost'] = 'Unit Cost must be ≥ 0';

        }
      }

      if (Object.keys(fieldErrors).length) {
        const err = new Error('Validation failed');
        err.statusCode = 400;
        err.fieldErrors = fieldErrors;
        throw err;
      }

    
      {
      const __cfg = this.mixinConfig?.inventory_reservation || this.mixinConfig?.inventoryReservation || {};
            const __qtyField = __cfg.quantity_field || __cfg.quantityField || 'quantity';
            const __reservedField = __cfg.reserved_field || __cfg.reservedField || 'reserved_quantity';
            const __committedField = __cfg.committed_field || __cfg.committedField || 'committed_quantity';
            const __availableField = __cfg.available_field || __cfg.availableField || 'available_quantity';
            const __autoAvailable = __cfg.auto_calculate_available === true || __cfg.autoCalculateAvailable === true;
            const __enforce = __cfg.enforce !== false && __cfg.enforceRules !== false;
      
            const __readNumber = (value) => {
              if (value === undefined || value === null || value === '') return null;
              const num = Number(value);
              return Number.isNaN(num) ? null : num;
            };
      
            const __qty = __readNumber(data[__qtyField]);
            const __reserved = __readNumber(data[__reservedField]);
            const __committed = __readNumber(data[__committedField]);
            const __hasReservations = __reserved !== null || __committed !== null;
      
            if (__enforce && __qty !== null && __hasReservations) {
              const __reservedVal = __reserved ?? 0;
              const __committedVal = __committed ?? 0;
              if (__reservedVal < 0 || __committedVal < 0) {
                throw new Error('Reserved and committed quantities cannot be negative');
              }
              if (__reservedVal + __committedVal > __qty) {
                throw new Error('Reserved + committed quantities cannot exceed on-hand quantity');
              }
            }
      
            if (__autoAvailable && __qty !== null && __hasReservations && __availableField) {
              const __reservedVal = __reserved ?? 0;
              const __committedVal = __committed ?? 0;
              data[__availableField] = __qty - __reservedVal - __committedVal;
            }
      }

    
    // @HOOK: BEFORE_CREATE_TRANSFORMATION
    
      {
      const __cfg = this.mixinConfig?.inventory_lifecycle || this.mixinConfig?.inventoryLifecycle || {};
            const __statusField = __cfg.status_field || __cfg.statusField || 'status';
            const __statuses = Array.isArray(__cfg.statuses) && __cfg.statuses.length ? __cfg.statuses : null;
            const __defaultStatus = __cfg.default_status || __cfg.defaultStatus;
      
            if (data && data[__statusField] === undefined && __defaultStatus) {
              data[__statusField] = __defaultStatus;
            }
      
            if (__statuses && data && data[__statusField] !== undefined && !__statuses.includes(data[__statusField])) {
              throw new Error(`${__statusField} must be one of: ${__statuses.join(', ')}`);
            }
      }

    
      {
      // InventoryMixin: Initialize quantity if not present
            if (data.quantity === undefined || data.quantity === null) {
              data.quantity = 0;
            }
            data.quantity = Number(data.quantity);
            if (isNaN(data.quantity)) throw new Error('Quantity must be a number');
      }

    
    const result = await this.repository.create(this.slug, data);
    
    // @HOOK: AFTER_CREATE_LOGGING
    
    return result;
  }

  async update(id, data) {
    // @HOOK: BEFORE_UPDATE_VALIDATION
    
      // Schema-driven validation (generated)
      const existing = await this.repository.findById(this.slug, id);
      if (!existing) return null;
      const merged = { ...existing, ...data };

      const fieldErrors = {};
      const isMissing = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
      const isMissingNonString = (v) => v === undefined || v === null;

      const __refIdSets = {};
      const getRefIdSet = async (slug) => {
        if (__refIdSets[slug]) return __refIdSets[slug];
        const all = await this.repository.findAll(slug);
        __refIdSets[slug] = new Set(all.map((x) => x.id));
        return __refIdSets[slug];
      };

      if (isMissing(merged['purchase_order_id'])) fieldErrors['purchase_order_id'] = 'Purchase Order Id is required';

      if (!isMissing(merged['purchase_order_id'])) {
        const ids = await getRefIdSet('purchase_orders');
        if (!ids.has(String(merged['purchase_order_id']))) fieldErrors['purchase_order_id'] = 'Purchase Order Id has an invalid reference';
      }

      if (isMissing(merged['item_id'])) fieldErrors['item_id'] = 'Item Id is required';

      if (!isMissing(merged['item_id'])) {
        const ids = await getRefIdSet('products');
        if (!ids.has(String(merged['item_id']))) fieldErrors['item_id'] = 'Item Id has an invalid reference';
      }

      if (isMissing(merged['ordered_quantity'])) fieldErrors['ordered_quantity'] = 'Ordered Quantity is required';

      if (!isMissing(merged['ordered_quantity'])) {
        const num = typeof merged['ordered_quantity'] === 'number' ? merged['ordered_quantity'] : Number(merged['ordered_quantity']);
        if (Number.isNaN(num)) {
          fieldErrors['ordered_quantity'] = 'Ordered Quantity must be a number';
        } else {

          if (!Number.isInteger(num)) fieldErrors['ordered_quantity'] = 'Ordered Quantity must be an integer';

        }
      }

      if (!isMissing(merged['received_quantity'])) {
        const num = typeof merged['received_quantity'] === 'number' ? merged['received_quantity'] : Number(merged['received_quantity']);
        if (Number.isNaN(num)) {
          fieldErrors['received_quantity'] = 'Received Quantity must be a number';
        } else {

          if (!Number.isInteger(num)) fieldErrors['received_quantity'] = 'Received Quantity must be an integer';

        }
      }

      const __allowed_status = ['Open', 'Partial', 'Received'];
      if (!isMissing(merged['status']) && !__allowed_status.includes(String(merged['status']))) fieldErrors['status'] = 'Status must be one of: Open, Partial, Received';

      if (!isMissing(merged['unit_cost'])) {
        const num = typeof merged['unit_cost'] === 'number' ? merged['unit_cost'] : Number(merged['unit_cost']);
        if (Number.isNaN(num)) {
          fieldErrors['unit_cost'] = 'Unit Cost must be a number';
        } else {

          if (num < 0) fieldErrors['unit_cost'] = 'Unit Cost must be ≥ 0';

        }
      }

      if (Object.keys(fieldErrors).length) {
        const err = new Error('Validation failed');
        err.statusCode = 400;
        err.fieldErrors = fieldErrors;
        throw err;
      }

    
      {
      const __cfg = this.mixinConfig?.inventory_reservation || this.mixinConfig?.inventoryReservation || {};
            const __qtyField = __cfg.quantity_field || __cfg.quantityField || 'quantity';
            const __reservedField = __cfg.reserved_field || __cfg.reservedField || 'reserved_quantity';
            const __committedField = __cfg.committed_field || __cfg.committedField || 'committed_quantity';
            const __availableField = __cfg.available_field || __cfg.availableField || 'available_quantity';
            const __autoAvailable = __cfg.auto_calculate_available === true || __cfg.autoCalculateAvailable === true;
            const __enforce = __cfg.enforce !== false && __cfg.enforceRules !== false;
      
            const __existing = await this.repository.findById(this.slug, id);
      
            const __readNumber = (value) => {
              if (value === undefined || value === null || value === '') return null;
              const num = Number(value);
              return Number.isNaN(num) ? null : num;
            };
      
            const __getValue = (field) => {
              if (data && data[field] !== undefined) return __readNumber(data[field]);
              if (__existing && __existing[field] !== undefined) return __readNumber(__existing[field]);
              return null;
            };
      
            const __qty = __getValue(__qtyField);
            const __reserved = __getValue(__reservedField);
            const __committed = __getValue(__committedField);
            const __hasReservations = __reserved !== null || __committed !== null;
      
            if (__enforce && __qty !== null && __hasReservations) {
              const __reservedVal = __reserved ?? 0;
              const __committedVal = __committed ?? 0;
              if (__reservedVal < 0 || __committedVal < 0) {
                throw new Error('Reserved and committed quantities cannot be negative');
              }
              if (__reservedVal + __committedVal > __qty) {
                throw new Error('Reserved + committed quantities cannot exceed on-hand quantity');
              }
            }
      
            if (__autoAvailable && __qty !== null && __hasReservations && __availableField) {
              const __reservedVal = __reserved ?? 0;
              const __committedVal = __committed ?? 0;
              data[__availableField] = __qty - __reservedVal - __committedVal;
            }
      }

    
      {
      const __cfg = this.mixinConfig?.inventory_lifecycle || this.mixinConfig?.inventoryLifecycle || {};
            const __statusField = __cfg.status_field || __cfg.statusField || 'status';
            const __statuses = Array.isArray(__cfg.statuses) && __cfg.statuses.length ? __cfg.statuses : null;
            const __enforceTransitions = __cfg.enforce_transitions === true || __cfg.enforceTransitions === true;
            const __customTransitions = __cfg.transitions && typeof __cfg.transitions === 'object' ? __cfg.transitions : null;
            const __defaultTransitions = {
              Draft: ['Active', 'Obsolete'],
              Active: ['Obsolete'],
              Obsolete: [],
            };
            const __transitions = __customTransitions || (__cfg.use_default_transitions === true || __cfg.useDefaultTransitions === true ? __defaultTransitions : null);
      
            if (data && data[__statusField] !== undefined) {
              const __nextStatus = data[__statusField];
              if (__statuses && !__statuses.includes(__nextStatus)) {
                throw new Error(`${__statusField} must be one of: ${__statuses.join(', ')}`);
              }
      
              if (__enforceTransitions && __transitions) {
                const __existing = await this.repository.findById(this.slug, id);
                const __currentStatus = __existing ? __existing[__statusField] : null;
      
                if (__currentStatus && __currentStatus !== __nextStatus) {
                  const __allowed = Array.isArray(__transitions[__currentStatus]) ? __transitions[__currentStatus] : [];
                  if (!__allowed.includes(__nextStatus)) {
                    throw new Error(`Invalid status transition: ${__currentStatus} -> ${__nextStatus}`);
                  }
                }
              }
            }
      }

    
      {
      // InventoryMixin: Validate quantity updates
            if (data.quantity !== undefined) {
              const newQty = Number(data.quantity);
              if (isNaN(newQty)) throw new Error('Quantity must be a number');
      
              const inventoryConfig = this.mixinConfig?.inventory || {};
              const allowNegative = inventoryConfig.allow_negative === true || inventoryConfig.allowNegative === true;
      
              // Prevent negative stock unless allow_negative is true
              if (!allowNegative && newQty < 0) {
                throw new Error('Stock cannot be negative');
              }
            }
      }

    
    const result = await this.repository.update(this.slug, id, data);
    
    // @HOOK: AFTER_UPDATE_LOGGING

    return result;
  }

  async delete(id) {
    // @HOOK: BEFORE_DELETE_VALIDATION
    
      // Delete protection (generated): prevent deleting a record that is referenced by others
      const dependents = [];

      {
        const rows = await this.repository.findAll('goods_receipt_items');
        const matches = rows.filter((row) => String(row['purchase_order_item_id'] ?? '') === String(id));
        if (matches.length) {
          dependents.push({
            entity: 'goods_receipt_items',
            via: ['purchase_order_item_id'],
            count: matches.length,
            preview: matches.slice(0, 10).map((r) => ({ id: r.id, display: r['goods_receipt_id'] || r.id })),
          });
        }
      }

      if (dependents.length) {
        const err = new Error('Cannot delete: this record is referenced by other records');
        err.statusCode = 409;
        err.dependents = dependents;
        throw err;
      }


    const result = await this.repository.delete(this.slug, id);
    
    // @HOOK: AFTER_DELETE_LOGGING

    return result;
  }

  async findById(id) {
    return this.repository.findById(this.slug, id);
  }

  async findAll(filter = {}) {
    return this.repository.findAll(this.slug, filter);
  }

  // @HOOK: ADDITIONAL_METHODS
    
  async adjustStock(id, delta) {
    const inventoryConfig = this.mixinConfig?.inventory || {};
    const allowNegative = inventoryConfig.allow_negative === true || inventoryConfig.allowNegative === true;

    if (typeof this.repository.atomicAdjustQuantity === 'function') {
      return this.repository.atomicAdjustQuantity(this.slug, id, delta, {
        quantityField: 'quantity',
        allow_negative_stock: allowNegative,
      });
    }

    const item = await this.repository.findById(this.slug, id);
    if (!item) throw new Error('Item not found');

    const currentQty = Number(item.quantity) || 0;
    const newQty = currentQty + delta;

    if (!allowNegative && newQty < 0) {
      throw new Error(`Insufficient stock. Current: ${currentQty}, Delta: ${delta}`);
    }

    return this.repository.update(this.slug, id, { quantity: newQty });
  }
  
}

module.exports = Purchase_order_itemsService;
