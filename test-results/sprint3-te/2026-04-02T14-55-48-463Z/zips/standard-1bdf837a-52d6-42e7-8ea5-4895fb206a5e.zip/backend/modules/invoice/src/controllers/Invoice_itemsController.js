// brick-library/backend-bricks/core/BaseController.js.hbs
const RepositoryProvider = require('../repository/PostgresProvider');
const Invoice_itemsService = require('../services/Invoice_itemsService');

class Invoice_itemsController {
  constructor() {
    this.repository = new RepositoryProvider();
    this.service = new Invoice_itemsService(this.repository, {"InvoiceCalculationEngineMixin":{"invoice_item_entity":"invoice_items","item_invoice_field":"invoice_id","item_quantity_field":"quantity","item_unit_price_field":"unit_price","item_line_subtotal_field":"line_subtotal","item_discount_type_field":"line_discount_type","item_discount_value_field":"line_discount_value","item_discount_total_field":"line_discount_total","item_tax_rate_field":"line_tax_rate","item_tax_total_field":"line_tax_total","item_additional_charge_field":"line_additional_charge","item_line_total_field":"line_total","subtotal_field":"subtotal","tax_total_field":"tax_total","discount_total_field":"discount_total","additional_charges_field":"additional_charges_total","grand_total_field":"grand_total","enabled":true,"item_entity":"invoice_items","invoice_entity":"invoices","paid_total_field":"paid_total","outstanding_field":"outstanding_balance"},"invoice_calculation_engine":{"invoice_item_entity":"invoice_items","item_invoice_field":"invoice_id","item_quantity_field":"quantity","item_unit_price_field":"unit_price","item_line_subtotal_field":"line_subtotal","item_discount_type_field":"line_discount_type","item_discount_value_field":"line_discount_value","item_discount_total_field":"line_discount_total","item_tax_rate_field":"line_tax_rate","item_tax_total_field":"line_tax_total","item_additional_charge_field":"line_additional_charge","item_line_total_field":"line_total","subtotal_field":"subtotal","tax_total_field":"tax_total","discount_total_field":"discount_total","additional_charges_field":"additional_charges_total","grand_total_field":"grand_total","enabled":true,"item_entity":"invoice_items","invoice_entity":"invoices","paid_total_field":"paid_total","outstanding_field":"outstanding_balance"},"invoiceCalculationEngine":{"invoice_item_entity":"invoice_items","item_invoice_field":"invoice_id","item_quantity_field":"quantity","item_unit_price_field":"unit_price","item_line_subtotal_field":"line_subtotal","item_discount_type_field":"line_discount_type","item_discount_value_field":"line_discount_value","item_discount_total_field":"line_discount_total","item_tax_rate_field":"line_tax_rate","item_tax_total_field":"line_tax_total","item_additional_charge_field":"line_additional_charge","item_line_total_field":"line_total","subtotal_field":"subtotal","tax_total_field":"tax_total","discount_total_field":"discount_total","additional_charges_field":"additional_charges_total","grand_total_field":"grand_total","enabled":true,"item_entity":"invoice_items","invoice_entity":"invoices","paid_total_field":"paid_total","outstanding_field":"outstanding_balance"}});
  }

  _errorPayload(error) {
    return {
      error: error.message,
      field_errors: error.fieldErrors || undefined,
      dependents: error.dependents || undefined,
      details: error.details || undefined,
    };
  }

  _resolveStatus(error, fallback = 500) {
    return error.statusCode || error.status || fallback;
  }

  async runAction(req, res, methodName, ...args) {
    try {
      const method = this.service && this.service[methodName];
      if (typeof method !== 'function') {
        return res.status(404).json({ error: `Action '${methodName}' is not available` });
      }
      const result = await method.apply(this.service, args);
      if (result === undefined) {
        return res.status(204).send();
      }
      return res.json(result);
    } catch (error) {
      const status = this._resolveStatus(error, 400);
      return res.status(status).json(this._errorPayload(error));
    }
  }

  async getAll(req, res) {
    try {
      const items = await this.service.findAll(req.query);
      res.json(items);
    } catch (error) {
      res.status(500).json(this._errorPayload(error));
    }
  }

  async getById(req, res) {
    try {
      const item = await this.service.findById(req.params.id);
      if (!item) return res.status(404).json({ error: 'Not found' });
      res.json(item);
    } catch (error) {
      res.status(500).json(this._errorPayload(error));
    }
  }

  async create(req, res) {
    try {
      const item = await this.service.create(req.body);
      res.status(201).json(item);
    } catch (error) {
      const status = this._resolveStatus(error, 400);
      res.status(status).json(this._errorPayload(error));
    }
  }

  async update(req, res) {
    try {
      const item = await this.service.update(req.params.id, req.body);
      if (!item) return res.status(404).json({ error: 'Not found' });
      res.json(item);
    } catch (error) {
      const status = this._resolveStatus(error, 400);
      res.status(status).json(this._errorPayload(error));
    }
  }

  async delete(req, res) {
    try {
      const result = await this.service.delete(req.params.id);
      if (!result) return res.status(404).json({ error: 'Not found' });
      res.status(204).send();
    } catch (error) {
      const status = this._resolveStatus(error, 500);
      res.status(status).json(this._errorPayload(error));
    }
  }
}

module.exports = Invoice_itemsController;

