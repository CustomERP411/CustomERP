// brick-library/backend-bricks/core/BaseController.js.hbs
const RepositoryProvider = require('../repository/PostgresProvider');
const InvoicesService = require('../services/InvoicesService');

class InvoicesController {
  constructor() {
    this.repository = new RepositoryProvider();
    this.service = new InvoicesService(this.repository, {"InvoiceTransactionSafetyMixin":{"notes":{"enabled":true,"note_entity":"invoice_notes","invoice_entity":"invoices"},"prefix":"INV-","enabled":true,"currency":"USD","payments":{"enabled":true,"invoice_entity":"invoices","payment_entity":"invoice_payments","allocation_entity":"invoice_payment_allocations"},"tax_rate":0,"lifecycle":{"enabled":true,"statuses":["Draft","Sent","Paid","Overdue","Cancelled"],"enforce_transitions":true},"item_entity":"invoice_items","transactions":{"enabled":true,"invoice_entity":"invoices"},"invoice_entity":"invoices","customer_entity":"customers","recurring_billing":{"enabled":true,"schedule_entity":"recurring_invoice_schedules"},"calculation_engine":{"enabled":true,"item_entity":"invoice_items","invoice_entity":"invoices"},"default_payment_terms":"due_on_receipt","invoice_item_entity":"invoice_items","invoice_number_field":"invoice_number","idempotency_field":"idempotency_key","posted_at_field":"posted_at","status_field":"status","grand_total_field":"grand_total","paid_total_field":"paid_total","outstanding_field":"outstanding_balance","number_prefix":"INV-","number_padding":6},"invoice_transaction_safety":{"notes":{"enabled":true,"note_entity":"invoice_notes","invoice_entity":"invoices"},"prefix":"INV-","enabled":true,"currency":"USD","payments":{"enabled":true,"invoice_entity":"invoices","payment_entity":"invoice_payments","allocation_entity":"invoice_payment_allocations"},"tax_rate":0,"lifecycle":{"enabled":true,"statuses":["Draft","Sent","Paid","Overdue","Cancelled"],"enforce_transitions":true},"item_entity":"invoice_items","transactions":{"enabled":true,"invoice_entity":"invoices"},"invoice_entity":"invoices","customer_entity":"customers","recurring_billing":{"enabled":true,"schedule_entity":"recurring_invoice_schedules"},"calculation_engine":{"enabled":true,"item_entity":"invoice_items","invoice_entity":"invoices"},"default_payment_terms":"due_on_receipt","invoice_item_entity":"invoice_items","invoice_number_field":"invoice_number","idempotency_field":"idempotency_key","posted_at_field":"posted_at","status_field":"status","grand_total_field":"grand_total","paid_total_field":"paid_total","outstanding_field":"outstanding_balance","number_prefix":"INV-","number_padding":6},"invoiceTransactionSafety":{"notes":{"enabled":true,"note_entity":"invoice_notes","invoice_entity":"invoices"},"prefix":"INV-","enabled":true,"currency":"USD","payments":{"enabled":true,"invoice_entity":"invoices","payment_entity":"invoice_payments","allocation_entity":"invoice_payment_allocations"},"tax_rate":0,"lifecycle":{"enabled":true,"statuses":["Draft","Sent","Paid","Overdue","Cancelled"],"enforce_transitions":true},"item_entity":"invoice_items","transactions":{"enabled":true,"invoice_entity":"invoices"},"invoice_entity":"invoices","customer_entity":"customers","recurring_billing":{"enabled":true,"schedule_entity":"recurring_invoice_schedules"},"calculation_engine":{"enabled":true,"item_entity":"invoice_items","invoice_entity":"invoices"},"default_payment_terms":"due_on_receipt","invoice_item_entity":"invoice_items","invoice_number_field":"invoice_number","idempotency_field":"idempotency_key","posted_at_field":"posted_at","status_field":"status","grand_total_field":"grand_total","paid_total_field":"paid_total","outstanding_field":"outstanding_balance","number_prefix":"INV-","number_padding":6},"InvoiceMixin":{"notes":{"enabled":true,"note_entity":"invoice_notes","invoice_entity":"invoices"},"prefix":"INV-","enabled":true,"currency":"USD","payments":{"enabled":true,"invoice_entity":"invoices","payment_entity":"invoice_payments","allocation_entity":"invoice_payment_allocations"},"tax_rate":0,"lifecycle":{"enabled":true,"statuses":["Draft","Sent","Paid","Overdue","Cancelled"],"enforce_transitions":true},"item_entity":"invoice_items","transactions":{"enabled":true,"invoice_entity":"invoices"},"invoice_entity":"invoices","customer_entity":"customers","recurring_billing":{"enabled":true,"schedule_entity":"recurring_invoice_schedules"},"calculation_engine":{"enabled":true,"item_entity":"invoice_items","invoice_entity":"invoices"},"default_payment_terms":"due_on_receipt","use_calculation_engine":true,"calculation_engine_enabled":true,"auto_number_mode":"workflow","status_field":"status","statuses":["Draft","Sent","Paid","Overdue","Cancelled"]},"invoice":{"notes":{"enabled":true,"note_entity":"invoice_notes","invoice_entity":"invoices"},"prefix":"INV-","enabled":true,"currency":"USD","payments":{"enabled":true,"invoice_entity":"invoices","payment_entity":"invoice_payments","allocation_entity":"invoice_payment_allocations"},"tax_rate":0,"lifecycle":{"enabled":true,"statuses":["Draft","Sent","Paid","Overdue","Cancelled"],"enforce_transitions":true},"item_entity":"invoice_items","transactions":{"enabled":true,"invoice_entity":"invoices"},"invoice_entity":"invoices","customer_entity":"customers","recurring_billing":{"enabled":true,"schedule_entity":"recurring_invoice_schedules"},"calculation_engine":{"enabled":true,"item_entity":"invoice_items","invoice_entity":"invoices"},"default_payment_terms":"due_on_receipt","use_calculation_engine":true,"calculation_engine_enabled":true,"auto_number_mode":"workflow","status_field":"status","statuses":["Draft","Sent","Paid","Overdue","Cancelled"]},"InvoicePaymentWorkflowMixin":{"payment_entity":"invoice_payments","allocation_entity":"invoice_payment_allocations","payment_number_field":"payment_number","payment_customer_field":"customer_id","payment_date_field":"payment_date","payment_method_field":"payment_method","amount_field":"amount","unallocated_field":"unallocated_amount","status_field":"status","allocation_payment_field":"payment_id","allocation_invoice_field":"invoice_id","allocation_amount_field":"amount","allocation_date_field":"allocated_at","enabled":true,"invoice_entity":"invoices","invoice_status_field":"status","invoice_grand_total_field":"grand_total","invoice_paid_total_field":"paid_total","invoice_outstanding_field":"outstanding_balance","payment_amount_field":"amount","payment_unallocated_field":"unallocated_amount","payment_status_field":"status","payment_number_prefix":"PAY-","payment_number_padding":6},"invoice_payment_workflow":{"payment_entity":"invoice_payments","allocation_entity":"invoice_payment_allocations","payment_number_field":"payment_number","payment_customer_field":"customer_id","payment_date_field":"payment_date","payment_method_field":"payment_method","amount_field":"amount","unallocated_field":"unallocated_amount","status_field":"status","allocation_payment_field":"payment_id","allocation_invoice_field":"invoice_id","allocation_amount_field":"amount","allocation_date_field":"allocated_at","enabled":true,"invoice_entity":"invoices","invoice_status_field":"status","invoice_grand_total_field":"grand_total","invoice_paid_total_field":"paid_total","invoice_outstanding_field":"outstanding_balance","payment_amount_field":"amount","payment_unallocated_field":"unallocated_amount","payment_status_field":"status","payment_number_prefix":"PAY-","payment_number_padding":6},"invoicePaymentWorkflow":{"payment_entity":"invoice_payments","allocation_entity":"invoice_payment_allocations","payment_number_field":"payment_number","payment_customer_field":"customer_id","payment_date_field":"payment_date","payment_method_field":"payment_method","amount_field":"amount","unallocated_field":"unallocated_amount","status_field":"status","allocation_payment_field":"payment_id","allocation_invoice_field":"invoice_id","allocation_amount_field":"amount","allocation_date_field":"allocated_at","enabled":true,"invoice_entity":"invoices","invoice_status_field":"status","invoice_grand_total_field":"grand_total","invoice_paid_total_field":"paid_total","invoice_outstanding_field":"outstanding_balance","payment_amount_field":"amount","payment_unallocated_field":"unallocated_amount","payment_status_field":"status","payment_number_prefix":"PAY-","payment_number_padding":6},"InvoiceNoteWorkflowMixin":{"note_entity":"invoice_notes","note_number_field":"note_number","note_invoice_field":"source_invoice_id","note_type_field":"note_type","note_status_field":"status","note_amount_field":"amount","note_tax_total_field":"tax_total","note_grand_total_field":"grand_total","note_posted_at_field":"posted_at","enabled":true,"invoice_entity":"invoices","invoice_status_field":"status","invoice_grand_total_field":"grand_total","invoice_paid_total_field":"paid_total","invoice_outstanding_field":"outstanding_balance","note_number_credit_prefix":"CN-","note_number_debit_prefix":"DN-","note_number_padding":6},"invoice_note_workflow":{"note_entity":"invoice_notes","note_number_field":"note_number","note_invoice_field":"source_invoice_id","note_type_field":"note_type","note_status_field":"status","note_amount_field":"amount","note_tax_total_field":"tax_total","note_grand_total_field":"grand_total","note_posted_at_field":"posted_at","enabled":true,"invoice_entity":"invoices","invoice_status_field":"status","invoice_grand_total_field":"grand_total","invoice_paid_total_field":"paid_total","invoice_outstanding_field":"outstanding_balance","note_number_credit_prefix":"CN-","note_number_debit_prefix":"DN-","note_number_padding":6},"invoiceNoteWorkflow":{"note_entity":"invoice_notes","note_number_field":"note_number","note_invoice_field":"source_invoice_id","note_type_field":"note_type","note_status_field":"status","note_amount_field":"amount","note_tax_total_field":"tax_total","note_grand_total_field":"grand_total","note_posted_at_field":"posted_at","enabled":true,"invoice_entity":"invoices","invoice_status_field":"status","invoice_grand_total_field":"grand_total","invoice_paid_total_field":"paid_total","invoice_outstanding_field":"outstanding_balance","note_number_credit_prefix":"CN-","note_number_debit_prefix":"DN-","note_number_padding":6},"InvoiceLifecycleMixin":{"status_field":"status","statuses":["Draft","Sent","Paid","Overdue","Cancelled"],"enforce_transitions":true,"enabled":true,"transitions":{"Draft":["Sent","Cancelled"],"Sent":["Paid","Overdue","Cancelled"],"Overdue":["Paid","Cancelled"],"Paid":[],"Cancelled":[]}},"invoice_lifecycle":{"status_field":"status","statuses":["Draft","Sent","Paid","Overdue","Cancelled"],"enforce_transitions":true,"enabled":true,"transitions":{"Draft":["Sent","Cancelled"],"Sent":["Paid","Overdue","Cancelled"],"Overdue":["Paid","Cancelled"],"Paid":[],"Cancelled":[]}},"invoiceLifecycle":{"status_field":"status","statuses":["Draft","Sent","Paid","Overdue","Cancelled"],"enforce_transitions":true,"enabled":true,"transitions":{"Draft":["Sent","Cancelled"],"Sent":["Paid","Overdue","Cancelled"],"Overdue":["Paid","Cancelled"],"Paid":[],"Cancelled":[]}}});
  }

  _errorPayload(error) {
    return {
      error: error.message,
      field_errors: error.fieldErrors || undefined,
      dependents: error.dependents || undefined,
      details: error.details || undefined,
    };
  }

  _resolveStatus(error, fallback = 500) {
    return error.statusCode || error.status || fallback;
  }

  async runAction(req, res, methodName, ...args) {
    try {
      const method = this.service && this.service[methodName];
      if (typeof method !== 'function') {
        return res.status(404).json({ error: `Action '${methodName}' is not available` });
      }
      const result = await method.apply(this.service, args);
      if (result === undefined) {
        return res.status(204).send();
      }
      return res.json(result);
    } catch (error) {
      const status = this._resolveStatus(error, 400);
      return res.status(status).json(this._errorPayload(error));
    }
  }

  async getAll(req, res) {
    try {
      const items = await this.service.findAll(req.query);
      res.json(items);
    } catch (error) {
      res.status(500).json(this._errorPayload(error));
    }
  }

  async getById(req, res) {
    try {
      const item = await this.service.findById(req.params.id);
      if (!item) return res.status(404).json({ error: 'Not found' });
      res.json(item);
    } catch (error) {
      res.status(500).json(this._errorPayload(error));
    }
  }

  async create(req, res) {
    try {
      const item = await this.service.create(req.body);
      res.status(201).json(item);
    } catch (error) {
      const status = this._resolveStatus(error, 400);
      res.status(status).json(this._errorPayload(error));
    }
  }

  async update(req, res) {
    try {
      const item = await this.service.update(req.params.id, req.body);
      if (!item) return res.status(404).json({ error: 'Not found' });
      res.json(item);
    } catch (error) {
      const status = this._resolveStatus(error, 400);
      res.status(status).json(this._errorPayload(error));
    }
  }

  async delete(req, res) {
    try {
      const result = await this.service.delete(req.params.id);
      if (!result) return res.status(404).json({ error: 'Not found' });
      res.status(204).send();
    } catch (error) {
      const status = this._resolveStatus(error, 500);
      res.status(status).json(this._errorPayload(error));
    }
  }
}

module.exports = InvoicesController;

