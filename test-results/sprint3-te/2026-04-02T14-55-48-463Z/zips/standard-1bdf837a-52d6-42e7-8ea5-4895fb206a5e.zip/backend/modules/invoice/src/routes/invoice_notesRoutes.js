
const express = require('express');
const router = express.Router();
const Invoice_notesController = require('../controllers/Invoice_notesController');

const controller = new Invoice_notesController();

router.get('/', (req, res) => controller.getAll(req, res));
router.get('/:id', (req, res) => controller.getById(req, res));
router.post('/', (req, res) => controller.create(req, res));
router.put('/:id', (req, res) => controller.update(req, res));
router.delete('/:id', (req, res) => controller.delete(req, res));

router.post('/:id/post', (req, res) => controller.runAction(req, res, 'postInvoiceNote', req.params.id, req.body || {}));
router.post('/:id/cancel', (req, res) => controller.runAction(req, res, 'cancelInvoiceNote', req.params.id, req.body || {}));


module.exports = router;
