
const express = require('express');
const router = express.Router();
const Invoice_paymentsController = require('../controllers/Invoice_paymentsController');

const controller = new Invoice_paymentsController();

router.get('/', (req, res) => controller.getAll(req, res));
router.get('/:id', (req, res) => controller.getById(req, res));
router.post('/', (req, res) => controller.create(req, res));
router.put('/:id', (req, res) => controller.update(req, res));
router.delete('/:id', (req, res) => controller.delete(req, res));

router.post('/:id/post', (req, res) => controller.runAction(req, res, 'postPayment', req.params.id, req.body || {}));
router.post('/:id/cancel', (req, res) => controller.runAction(req, res, 'cancelPayment', req.params.id, req.body || {}));


module.exports = router;
