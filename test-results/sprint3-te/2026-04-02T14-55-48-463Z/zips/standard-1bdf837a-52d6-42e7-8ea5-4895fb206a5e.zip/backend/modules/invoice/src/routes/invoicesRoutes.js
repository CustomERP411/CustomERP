
const express = require('express');
const router = express.Router();
const InvoicesController = require('../controllers/InvoicesController');

const controller = new InvoicesController();

router.get('/', (req, res) => controller.getAll(req, res));
router.get('/:id', (req, res) => controller.getById(req, res));
router.post('/', (req, res) => controller.create(req, res));
router.put('/:id', (req, res) => controller.update(req, res));
router.delete('/:id', (req, res) => controller.delete(req, res));

router.post('/:id/issue', (req, res) => controller.runAction(req, res, 'issueInvoice', req.params.id, req.body || {}));
router.post('/:id/cancel', (req, res) => controller.runAction(req, res, 'cancelInvoice', req.params.id, req.body || {}));
router.get('/:id/payments', (req, res) => controller.runAction(req, res, 'listInvoicePayments', req.params.id, req.query || {}));
router.post('/:id/payments', (req, res) => controller.runAction(req, res, 'recordInvoicePayment', req.params.id, req.body || {}));
router.get('/:id/notes', (req, res) => controller.runAction(req, res, 'listInvoiceNotes', req.params.id, req.query || {}));
router.post('/:id/notes', (req, res) => controller.runAction(req, res, 'createInvoiceNote', req.params.id, req.body || {}));


module.exports = router;
