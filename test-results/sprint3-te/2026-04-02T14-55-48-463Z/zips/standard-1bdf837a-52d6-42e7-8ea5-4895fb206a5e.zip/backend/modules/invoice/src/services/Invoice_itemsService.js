// brick-library/backend-bricks/core/BaseService.js.hbs
class Invoice_itemsService {
  constructor(repository, mixinConfig = {}) {
    this.repository = repository;
    this.slug = 'invoice_items';
    this.mixinConfig = mixinConfig && typeof mixinConfig === 'object' ? mixinConfig : {};
  }

  async create(data) {
    // @HOOK: BEFORE_CREATE_VALIDATION
    
      // Schema-driven validation (generated)
      const fieldErrors = {};
      const isMissing = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
      const isMissingNonString = (v) => v === undefined || v === null;

      const __refIdSets = {};
      const getRefIdSet = async (slug) => {
        if (__refIdSets[slug]) return __refIdSets[slug];
        const all = await this.repository.findAll(slug);
        __refIdSets[slug] = new Set(all.map((x) => x.id));
        return __refIdSets[slug];
      };

      if (isMissing(data['invoice_id'])) fieldErrors['invoice_id'] = 'Invoice Id is required';

      if (!isMissing(data['invoice_id'])) {
        const ids = await getRefIdSet('invoices');
        if (!ids.has(String(data['invoice_id']))) fieldErrors['invoice_id'] = 'Invoice Id has an invalid reference';
      }

      if (isMissing(data['description'])) fieldErrors['description'] = 'Description is required';

      if (isMissing(data['quantity'])) fieldErrors['quantity'] = 'Quantity is required';

      if (!isMissing(data['quantity'])) {
        const num = typeof data['quantity'] === 'number' ? data['quantity'] : Number(data['quantity']);
        if (Number.isNaN(num)) {
          fieldErrors['quantity'] = 'Quantity must be a number';
        } else {

        }
      }

      if (isMissing(data['unit_price'])) fieldErrors['unit_price'] = 'Unit Price is required';

      if (!isMissing(data['unit_price'])) {
        const num = typeof data['unit_price'] === 'number' ? data['unit_price'] : Number(data['unit_price']);
        if (Number.isNaN(num)) {
          fieldErrors['unit_price'] = 'Unit Price must be a number';
        } else {

        }
      }

      if (!isMissing(data['line_total'])) {
        const num = typeof data['line_total'] === 'number' ? data['line_total'] : Number(data['line_total']);
        if (Number.isNaN(num)) {
          fieldErrors['line_total'] = 'Line Total must be a number';
        } else {

        }
      }

      if (!isMissing(data['line_subtotal'])) {
        const num = typeof data['line_subtotal'] === 'number' ? data['line_subtotal'] : Number(data['line_subtotal']);
        if (Number.isNaN(num)) {
          fieldErrors['line_subtotal'] = 'Line Subtotal must be a number';
        } else {

        }
      }

      const __allowed_line_discount_type = ['Percent', 'Fixed'];
      if (!isMissing(data['line_discount_type']) && !__allowed_line_discount_type.includes(String(data['line_discount_type']))) fieldErrors['line_discount_type'] = 'Line Discount Type must be one of: Percent, Fixed';

      if (!isMissing(data['line_discount_value'])) {
        const num = typeof data['line_discount_value'] === 'number' ? data['line_discount_value'] : Number(data['line_discount_value']);
        if (Number.isNaN(num)) {
          fieldErrors['line_discount_value'] = 'Line Discount Value must be a number';
        } else {

        }
      }

      if (!isMissing(data['line_discount_amount'])) {
        const num = typeof data['line_discount_amount'] === 'number' ? data['line_discount_amount'] : Number(data['line_discount_amount']);
        if (Number.isNaN(num)) {
          fieldErrors['line_discount_amount'] = 'Line Discount Amount must be a number';
        } else {

        }
      }

      if (!isMissing(data['line_tax_rate'])) {
        const num = typeof data['line_tax_rate'] === 'number' ? data['line_tax_rate'] : Number(data['line_tax_rate']);
        if (Number.isNaN(num)) {
          fieldErrors['line_tax_rate'] = 'Line Tax Rate must be a number';
        } else {

        }
      }

      if (!isMissing(data['line_tax_amount'])) {
        const num = typeof data['line_tax_amount'] === 'number' ? data['line_tax_amount'] : Number(data['line_tax_amount']);
        if (Number.isNaN(num)) {
          fieldErrors['line_tax_amount'] = 'Line Tax Amount must be a number';
        } else {

        }
      }

      if (!isMissing(data['line_charges'])) {
        const num = typeof data['line_charges'] === 'number' ? data['line_charges'] : Number(data['line_charges']);
        if (Number.isNaN(num)) {
          fieldErrors['line_charges'] = 'Line Charges must be a number';
        } else {

        }
      }

      if (!isMissing(data['line_discount_total'])) {
        const num = typeof data['line_discount_total'] === 'number' ? data['line_discount_total'] : Number(data['line_discount_total']);
        if (Number.isNaN(num)) {
          fieldErrors['line_discount_total'] = 'Discount Total must be a number';
        } else {

          if (num < 0) fieldErrors['line_discount_total'] = 'Discount Total must be ≥ 0';

        }
      }

      if (!isMissing(data['line_tax_total'])) {
        const num = typeof data['line_tax_total'] === 'number' ? data['line_tax_total'] : Number(data['line_tax_total']);
        if (Number.isNaN(num)) {
          fieldErrors['line_tax_total'] = 'Tax Total must be a number';
        } else {

          if (num < 0) fieldErrors['line_tax_total'] = 'Tax Total must be ≥ 0';

        }
      }

      if (!isMissing(data['line_additional_charge'])) {
        const num = typeof data['line_additional_charge'] === 'number' ? data['line_additional_charge'] : Number(data['line_additional_charge']);
        if (Number.isNaN(num)) {
          fieldErrors['line_additional_charge'] = 'Additional Charge must be a number';
        } else {

          if (num < 0) fieldErrors['line_additional_charge'] = 'Additional Charge must be ≥ 0';

        }
      }

      if (Object.keys(fieldErrors).length) {
        const err = new Error('Validation failed');
        err.statusCode = 400;
        err.fieldErrors = fieldErrors;
        throw err;
      }

    
      {
      const __cfg = this._invCalcConfig();
            if (this.slug === __cfg.item_entity) {
              const __rawQty = data[__cfg.item_quantity_field];
              const __rawPrice = data[__cfg.item_unit_price_field];
              const __qty = Number(__rawQty);
              const __price = Number(__rawPrice);
              if (!Number.isFinite(__qty) || !Number.isFinite(__price)) {
                throw new Error('Quantity and unit price must be numbers');
              }
              if (__qty < 0 || __price < 0) {
                throw new Error('Quantity and unit price cannot be negative');
              }
            }
      }

    
    // @HOOK: BEFORE_CREATE_TRANSFORMATION
    
      {
      const __cfg = this._invCalcConfig();
            if (this.slug === __cfg.item_entity) {
              const __line = this._invCalcNormalizeLine(data, {});
              Object.assign(data, __line);
            }
      }

    
    const result = await this.repository.create(this.slug, data);
    
    // @HOOK: AFTER_CREATE_LOGGING
    
      {
      const __cfg = this._invCalcConfig();
            if (this.slug === __cfg.item_entity) {
              await this._recalculateInvoiceFromLines(data[__cfg.item_invoice_field]);
            }
      }

    
    return result;
  }

  async update(id, data) {
    // @HOOK: BEFORE_UPDATE_VALIDATION
    
      // Schema-driven validation (generated)
      const existing = await this.repository.findById(this.slug, id);
      if (!existing) return null;
      const merged = { ...existing, ...data };

      const fieldErrors = {};
      const isMissing = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
      const isMissingNonString = (v) => v === undefined || v === null;

      const __refIdSets = {};
      const getRefIdSet = async (slug) => {
        if (__refIdSets[slug]) return __refIdSets[slug];
        const all = await this.repository.findAll(slug);
        __refIdSets[slug] = new Set(all.map((x) => x.id));
        return __refIdSets[slug];
      };

      if (isMissing(merged['invoice_id'])) fieldErrors['invoice_id'] = 'Invoice Id is required';

      if (!isMissing(merged['invoice_id'])) {
        const ids = await getRefIdSet('invoices');
        if (!ids.has(String(merged['invoice_id']))) fieldErrors['invoice_id'] = 'Invoice Id has an invalid reference';
      }

      if (isMissing(merged['description'])) fieldErrors['description'] = 'Description is required';

      if (isMissing(merged['quantity'])) fieldErrors['quantity'] = 'Quantity is required';

      if (!isMissing(merged['quantity'])) {
        const num = typeof merged['quantity'] === 'number' ? merged['quantity'] : Number(merged['quantity']);
        if (Number.isNaN(num)) {
          fieldErrors['quantity'] = 'Quantity must be a number';
        } else {

        }
      }

      if (isMissing(merged['unit_price'])) fieldErrors['unit_price'] = 'Unit Price is required';

      if (!isMissing(merged['unit_price'])) {
        const num = typeof merged['unit_price'] === 'number' ? merged['unit_price'] : Number(merged['unit_price']);
        if (Number.isNaN(num)) {
          fieldErrors['unit_price'] = 'Unit Price must be a number';
        } else {

        }
      }

      if (!isMissing(merged['line_total'])) {
        const num = typeof merged['line_total'] === 'number' ? merged['line_total'] : Number(merged['line_total']);
        if (Number.isNaN(num)) {
          fieldErrors['line_total'] = 'Line Total must be a number';
        } else {

        }
      }

      if (!isMissing(merged['line_subtotal'])) {
        const num = typeof merged['line_subtotal'] === 'number' ? merged['line_subtotal'] : Number(merged['line_subtotal']);
        if (Number.isNaN(num)) {
          fieldErrors['line_subtotal'] = 'Line Subtotal must be a number';
        } else {

        }
      }

      const __allowed_line_discount_type = ['Percent', 'Fixed'];
      if (!isMissing(merged['line_discount_type']) && !__allowed_line_discount_type.includes(String(merged['line_discount_type']))) fieldErrors['line_discount_type'] = 'Line Discount Type must be one of: Percent, Fixed';

      if (!isMissing(merged['line_discount_value'])) {
        const num = typeof merged['line_discount_value'] === 'number' ? merged['line_discount_value'] : Number(merged['line_discount_value']);
        if (Number.isNaN(num)) {
          fieldErrors['line_discount_value'] = 'Line Discount Value must be a number';
        } else {

        }
      }

      if (!isMissing(merged['line_discount_amount'])) {
        const num = typeof merged['line_discount_amount'] === 'number' ? merged['line_discount_amount'] : Number(merged['line_discount_amount']);
        if (Number.isNaN(num)) {
          fieldErrors['line_discount_amount'] = 'Line Discount Amount must be a number';
        } else {

        }
      }

      if (!isMissing(merged['line_tax_rate'])) {
        const num = typeof merged['line_tax_rate'] === 'number' ? merged['line_tax_rate'] : Number(merged['line_tax_rate']);
        if (Number.isNaN(num)) {
          fieldErrors['line_tax_rate'] = 'Line Tax Rate must be a number';
        } else {

        }
      }

      if (!isMissing(merged['line_tax_amount'])) {
        const num = typeof merged['line_tax_amount'] === 'number' ? merged['line_tax_amount'] : Number(merged['line_tax_amount']);
        if (Number.isNaN(num)) {
          fieldErrors['line_tax_amount'] = 'Line Tax Amount must be a number';
        } else {

        }
      }

      if (!isMissing(merged['line_charges'])) {
        const num = typeof merged['line_charges'] === 'number' ? merged['line_charges'] : Number(merged['line_charges']);
        if (Number.isNaN(num)) {
          fieldErrors['line_charges'] = 'Line Charges must be a number';
        } else {

        }
      }

      if (!isMissing(merged['line_discount_total'])) {
        const num = typeof merged['line_discount_total'] === 'number' ? merged['line_discount_total'] : Number(merged['line_discount_total']);
        if (Number.isNaN(num)) {
          fieldErrors['line_discount_total'] = 'Discount Total must be a number';
        } else {

          if (num < 0) fieldErrors['line_discount_total'] = 'Discount Total must be ≥ 0';

        }
      }

      if (!isMissing(merged['line_tax_total'])) {
        const num = typeof merged['line_tax_total'] === 'number' ? merged['line_tax_total'] : Number(merged['line_tax_total']);
        if (Number.isNaN(num)) {
          fieldErrors['line_tax_total'] = 'Tax Total must be a number';
        } else {

          if (num < 0) fieldErrors['line_tax_total'] = 'Tax Total must be ≥ 0';

        }
      }

      if (!isMissing(merged['line_additional_charge'])) {
        const num = typeof merged['line_additional_charge'] === 'number' ? merged['line_additional_charge'] : Number(merged['line_additional_charge']);
        if (Number.isNaN(num)) {
          fieldErrors['line_additional_charge'] = 'Additional Charge must be a number';
        } else {

          if (num < 0) fieldErrors['line_additional_charge'] = 'Additional Charge must be ≥ 0';

        }
      }

      if (Object.keys(fieldErrors).length) {
        const err = new Error('Validation failed');
        err.statusCode = 400;
        err.fieldErrors = fieldErrors;
        throw err;
      }

    
      {
      const __cfg = this._invCalcConfig();
            if (this.slug === __cfg.item_entity) {
              const __existing = await this.repository.findById(this.slug, id);
              this._invoiceCalcPrevInvoiceId = __existing ? __existing[__cfg.item_invoice_field] : null;
              const __line = this._invCalcNormalizeLine(data, __existing || {});
              Object.assign(data, __line);
            }
      }

    
    const result = await this.repository.update(this.slug, id, data);
    
    // @HOOK: AFTER_UPDATE_LOGGING
    
      {
      const __cfg = this._invCalcConfig();
            if (this.slug === __cfg.item_entity) {
              const __nextInvoiceId = data[__cfg.item_invoice_field] || this._invoiceCalcPrevInvoiceId;
              await this._recalculateInvoiceFromLines(__nextInvoiceId);
              if (data[__cfg.item_invoice_field] && this._invoiceCalcPrevInvoiceId && String(data[__cfg.item_invoice_field]) !== String(this._invoiceCalcPrevInvoiceId)) {
                await this._recalculateInvoiceFromLines(this._invoiceCalcPrevInvoiceId);
              }
            }
      }


    return result;
  }

  async delete(id) {
    // @HOOK: BEFORE_DELETE_VALIDATION
    
      {
      const __cfg = this._invCalcConfig();
            if (this.slug === __cfg.item_entity) {
              const __existing = await this.repository.findById(this.slug, id);
              this._invoiceCalcDeleteInvoiceId = __existing ? __existing[__cfg.item_invoice_field] : null;
            }
      }


    const result = await this.repository.delete(this.slug, id);
    
    // @HOOK: AFTER_DELETE_LOGGING
    
      {
      const __cfg = this._invCalcConfig();
            if (this.slug === __cfg.item_entity) {
              await this._recalculateInvoiceFromLines(this._invoiceCalcDeleteInvoiceId);
            }
      }


    return result;
  }

  async findById(id) {
    return this.repository.findById(this.slug, id);
  }

  async findAll(filter = {}) {
    return this.repository.findAll(this.slug, filter);
  }

  // @HOOK: ADDITIONAL_METHODS
    
  _invCalcConfig() {
    const cfg =
      this.mixinConfig?.invoice_calculation_engine ||
      this.mixinConfig?.invoiceCalculationEngine ||
      this.mixinConfig?.invoice_calc ||
      this.mixinConfig?.invoiceCalc ||
      {};
    return {
      invoice_entity: cfg.invoice_entity || cfg.invoiceEntity || 'invoices',
      item_entity: cfg.invoice_item_entity || cfg.invoiceItemEntity || 'invoice_items',
      item_invoice_field: cfg.item_invoice_field || cfg.itemInvoiceField || 'invoice_id',
      item_quantity_field: cfg.item_quantity_field || cfg.itemQuantityField || 'quantity',
      item_unit_price_field: cfg.item_unit_price_field || cfg.itemUnitPriceField || 'unit_price',
      item_line_subtotal_field: cfg.item_line_subtotal_field || cfg.itemLineSubtotalField || 'line_subtotal',
      item_discount_type_field: cfg.item_discount_type_field || cfg.itemDiscountTypeField || 'line_discount_type',
      item_discount_value_field: cfg.item_discount_value_field || cfg.itemDiscountValueField || 'line_discount_value',
      item_discount_total_field: cfg.item_discount_total_field || cfg.itemDiscountTotalField || 'line_discount_total',
      item_tax_rate_field: cfg.item_tax_rate_field || cfg.itemTaxRateField || 'line_tax_rate',
      item_tax_total_field: cfg.item_tax_total_field || cfg.itemTaxTotalField || 'line_tax_total',
      item_additional_charge_field: cfg.item_additional_charge_field || cfg.itemAdditionalChargeField || 'line_additional_charge',
      item_line_total_field: cfg.item_line_total_field || cfg.itemLineTotalField || 'line_total',
      subtotal_field: cfg.subtotal_field || cfg.subtotalField || 'subtotal',
      tax_total_field: cfg.tax_total_field || cfg.taxTotalField || 'tax_total',
      discount_total_field: cfg.discount_total_field || cfg.discountTotalField || 'discount_total',
      additional_charges_field: cfg.additional_charges_field || cfg.additionalChargesField || 'additional_charges_total',
      grand_total_field: cfg.grand_total_field || cfg.grandTotalField || 'grand_total',
      paid_total_field: cfg.paid_total_field || cfg.paidTotalField || 'paid_total',
      outstanding_field: cfg.outstanding_field || cfg.outstandingField || 'outstanding_balance',
    };
  }

  _invCalcNum(rawValue, fallback = 0) {
    const num = Number(rawValue);
    return Number.isFinite(num) ? num : fallback;
  }

  _invCalcRound(rawValue) {
    const num = this._invCalcNum(rawValue, 0);
    return Number(num.toFixed(2));
  }

  _invCalcNormalizeLine(data = {}, existing = {}) {
    const cfg = this._invCalcConfig();
    const input = data && typeof data === 'object' ? data : {};
    const prev = existing && typeof existing === 'object' ? existing : {};

    const quantity = this._invCalcNum(
      input[cfg.item_quantity_field] !== undefined ? input[cfg.item_quantity_field] : prev[cfg.item_quantity_field],
      0
    );
    const unitPrice = this._invCalcNum(
      input[cfg.item_unit_price_field] !== undefined ? input[cfg.item_unit_price_field] : prev[cfg.item_unit_price_field],
      0
    );
    if (quantity < 0 || unitPrice < 0) {
      throw new Error('Quantity and unit price cannot be negative');
    }

    const discountTypeRaw =
      input[cfg.item_discount_type_field] !== undefined
        ? input[cfg.item_discount_type_field]
        : prev[cfg.item_discount_type_field];
    const discountType = String(discountTypeRaw || 'Amount');
    const normalizedDiscountType = discountType.toLowerCase() === 'percent' ? 'Percent' : 'Amount';
    const discountValue = this._invCalcNum(
      input[cfg.item_discount_value_field] !== undefined
        ? input[cfg.item_discount_value_field]
        : prev[cfg.item_discount_value_field],
      0
    );
    if (discountValue < 0) {
      throw new Error('Discount value cannot be negative');
    }

    const taxRate = this._invCalcNum(
      input[cfg.item_tax_rate_field] !== undefined ? input[cfg.item_tax_rate_field] : prev[cfg.item_tax_rate_field],
      0
    );
    if (taxRate < 0) {
      throw new Error('Tax rate cannot be negative');
    }

    const additionalCharge = this._invCalcNum(
      input[cfg.item_additional_charge_field] !== undefined
        ? input[cfg.item_additional_charge_field]
        : prev[cfg.item_additional_charge_field],
      0
    );
    if (additionalCharge < 0) {
      throw new Error('Additional charge cannot be negative');
    }

    const lineSubtotal = this._invCalcRound(quantity * unitPrice);
    const discountBase =
      normalizedDiscountType === 'Percent'
        ? lineSubtotal * (Math.min(Math.max(discountValue, 0), 100) / 100)
        : Math.min(discountValue, lineSubtotal);
    const discountTotal = this._invCalcRound(discountBase);
    const taxableBase = this._invCalcRound(Math.max(lineSubtotal - discountTotal + additionalCharge, 0));
    const taxTotal = this._invCalcRound((taxableBase * taxRate) / 100);
    const lineTotal = this._invCalcRound(taxableBase + taxTotal);

    return {
      [cfg.item_quantity_field]: quantity,
      [cfg.item_unit_price_field]: unitPrice,
      [cfg.item_line_subtotal_field]: lineSubtotal,
      [cfg.item_discount_type_field]: normalizedDiscountType,
      [cfg.item_discount_value_field]: discountValue,
      [cfg.item_discount_total_field]: discountTotal,
      [cfg.item_tax_rate_field]: taxRate,
      [cfg.item_tax_total_field]: taxTotal,
      [cfg.item_additional_charge_field]: additionalCharge,
      [cfg.item_line_total_field]: lineTotal,
    };
  }

  async _recalculateInvoiceFromLines(invoiceId) {
    const cfg = this._invCalcConfig();
    if (!invoiceId) return null;

    const items = await this.repository.findAll(cfg.item_entity, {
      [cfg.item_invoice_field]: invoiceId,
    });
    const rows = Array.isArray(items) ? items : [];

    let subtotal = 0;
    let discountTotal = 0;
    let additionalChargesTotal = 0;
    let taxTotal = 0;
    let grandTotal = 0;

    for (const item of rows) {
      subtotal += this._invCalcNum(item[cfg.item_line_subtotal_field], this._invCalcNum(item[cfg.item_quantity_field], 0) * this._invCalcNum(item[cfg.item_unit_price_field], 0));
      discountTotal += this._invCalcNum(item[cfg.item_discount_total_field], 0);
      additionalChargesTotal += this._invCalcNum(item[cfg.item_additional_charge_field], 0);
      taxTotal += this._invCalcNum(item[cfg.item_tax_total_field], 0);
      grandTotal += this._invCalcNum(item[cfg.item_line_total_field], 0);
    }

    subtotal = this._invCalcRound(subtotal);
    discountTotal = this._invCalcRound(discountTotal);
    additionalChargesTotal = this._invCalcRound(additionalChargesTotal);
    taxTotal = this._invCalcRound(taxTotal);
    grandTotal = this._invCalcRound(grandTotal);

    const invoice = await this.repository.findById(cfg.invoice_entity, invoiceId);
    if (!invoice) return null;

    const paidTotal = this._invCalcRound(invoice[cfg.paid_total_field] || 0);
    const outstanding = this._invCalcRound(Math.max(grandTotal - paidTotal, 0));
    return this.repository.update(cfg.invoice_entity, invoiceId, {
      [cfg.subtotal_field]: subtotal,
      [cfg.discount_total_field]: discountTotal,
      [cfg.additional_charges_field]: additionalChargesTotal,
      [cfg.tax_total_field]: taxTotal,
      [cfg.grand_total_field]: grandTotal,
      [cfg.outstanding_field]: outstanding,
    });
  }
    
}

module.exports = Invoice_itemsService;
