// brick-library/backend-bricks/core/BaseService.js.hbs
class Invoice_notesService {
  constructor(repository, mixinConfig = {}) {
    this.repository = repository;
    this.slug = 'invoice_notes';
    this.mixinConfig = mixinConfig && typeof mixinConfig === 'object' ? mixinConfig : {};
  }

  async create(data) {
    // @HOOK: BEFORE_CREATE_VALIDATION
    
      // Schema-driven validation (generated)
      const fieldErrors = {};
      const isMissing = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
      const isMissingNonString = (v) => v === undefined || v === null;

      const existingItems = await this.repository.findAll(this.slug);

      const __refIdSets = {};
      const getRefIdSet = async (slug) => {
        if (__refIdSets[slug]) return __refIdSets[slug];
        const all = await this.repository.findAll(slug);
        __refIdSets[slug] = new Set(all.map((x) => x.id));
        return __refIdSets[slug];
      };

      if (!isMissing(data['note_number']) && existingItems.some((it) => String(it['note_number']) === String(data['note_number']))) {
        fieldErrors['note_number'] = 'Note Number must be unique';
      }

      if (isMissing(data['source_invoice_id'])) fieldErrors['source_invoice_id'] = 'Source Invoice Id is required';

      if (!isMissing(data['source_invoice_id'])) {
        const ids = await getRefIdSet('invoices');
        if (!ids.has(String(data['source_invoice_id']))) fieldErrors['source_invoice_id'] = 'Source Invoice Id has an invalid reference';
      }

      if (isMissing(data['note_type'])) fieldErrors['note_type'] = 'Note Type is required';

      const __allowed_note_type = ['Credit', 'Debit'];
      if (!isMissing(data['note_type']) && !__allowed_note_type.includes(String(data['note_type']))) fieldErrors['note_type'] = 'Note Type must be one of: Credit, Debit';

      if (isMissing(data['amount'])) fieldErrors['amount'] = 'Amount is required';

      if (!isMissing(data['amount'])) {
        const num = typeof data['amount'] === 'number' ? data['amount'] : Number(data['amount']);
        if (Number.isNaN(num)) {
          fieldErrors['amount'] = 'Amount must be a number';
        } else {

        }
      }

      if (!isMissing(data['tax_total'])) {
        const num = typeof data['tax_total'] === 'number' ? data['tax_total'] : Number(data['tax_total']);
        if (Number.isNaN(num)) {
          fieldErrors['tax_total'] = 'Tax Total must be a number';
        } else {

        }
      }

      if (!isMissing(data['grand_total'])) {
        const num = typeof data['grand_total'] === 'number' ? data['grand_total'] : Number(data['grand_total']);
        if (Number.isNaN(num)) {
          fieldErrors['grand_total'] = 'Grand Total must be a number';
        } else {

        }
      }

      const __allowed_status = ['Draft', 'Posted', 'Cancelled'];
      if (!isMissing(data['status']) && !__allowed_status.includes(String(data['status']))) fieldErrors['status'] = 'Status must be one of: Draft, Posted, Cancelled';

      if (Object.keys(fieldErrors).length) {
        const err = new Error('Validation failed');
        err.statusCode = 400;
        err.fieldErrors = fieldErrors;
        throw err;
      }

    
    // @HOOK: BEFORE_CREATE_TRANSFORMATION
    
      {
      const __cfg = this._invTxnCfg();
            if (this.slug === __cfg.invoice_entity) {
              if (data[__cfg.status_field] === undefined || data[__cfg.status_field] === null || data[__cfg.status_field] === '') {
                data[__cfg.status_field] = 'Draft';
              }
              const __grand = Number(data[__cfg.grand_total_field] || 0);
              const __paid = Number(data[__cfg.paid_total_field] || 0);
              if (!Number.isFinite(__paid) || __paid < 0) {
                data[__cfg.paid_total_field] = 0;
              }
              const __safeGrand = Number.isFinite(__grand) ? __grand : 0;
              const __safePaid = Number(data[__cfg.paid_total_field] || 0);
              if (data[__cfg.outstanding_field] === undefined || data[__cfg.outstanding_field] === null || data[__cfg.outstanding_field] === '') {
                data[__cfg.outstanding_field] = Number(Math.max(__safeGrand - __safePaid, 0).toFixed(2));
              }
              if (!data[__cfg.invoice_number_field]) {
                data[__cfg.invoice_number_field] = 'DRAFT-' + Date.now() + '-' + Math.floor(Math.random() * 100000);
              }
              if (__cfg.idempotency_field && !data[__cfg.idempotency_field]) {
                data[__cfg.idempotency_field] = 'inv-' + Date.now() + '-' + Math.floor(Math.random() * 100000);
              }
            }
      }

    
    const result = await this.repository.create(this.slug, data);
    
    // @HOOK: AFTER_CREATE_LOGGING
    
    return result;
  }

  async update(id, data) {
    // @HOOK: BEFORE_UPDATE_VALIDATION
    
      // Schema-driven validation (generated)
      const existing = await this.repository.findById(this.slug, id);
      if (!existing) return null;
      const merged = { ...existing, ...data };

      const fieldErrors = {};
      const isMissing = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
      const isMissingNonString = (v) => v === undefined || v === null;

      const existingItems = await this.repository.findAll(this.slug);

      const __refIdSets = {};
      const getRefIdSet = async (slug) => {
        if (__refIdSets[slug]) return __refIdSets[slug];
        const all = await this.repository.findAll(slug);
        __refIdSets[slug] = new Set(all.map((x) => x.id));
        return __refIdSets[slug];
      };

      if (!isMissing(merged['note_number']) && existingItems.some((it) => it.id !== id && String(it['note_number']) === String(merged['note_number']))) {
        fieldErrors['note_number'] = 'Note Number must be unique';
      }

      if (isMissing(merged['source_invoice_id'])) fieldErrors['source_invoice_id'] = 'Source Invoice Id is required';

      if (!isMissing(merged['source_invoice_id'])) {
        const ids = await getRefIdSet('invoices');
        if (!ids.has(String(merged['source_invoice_id']))) fieldErrors['source_invoice_id'] = 'Source Invoice Id has an invalid reference';
      }

      if (isMissing(merged['note_type'])) fieldErrors['note_type'] = 'Note Type is required';

      const __allowed_note_type = ['Credit', 'Debit'];
      if (!isMissing(merged['note_type']) && !__allowed_note_type.includes(String(merged['note_type']))) fieldErrors['note_type'] = 'Note Type must be one of: Credit, Debit';

      if (isMissing(merged['amount'])) fieldErrors['amount'] = 'Amount is required';

      if (!isMissing(merged['amount'])) {
        const num = typeof merged['amount'] === 'number' ? merged['amount'] : Number(merged['amount']);
        if (Number.isNaN(num)) {
          fieldErrors['amount'] = 'Amount must be a number';
        } else {

        }
      }

      if (!isMissing(merged['tax_total'])) {
        const num = typeof merged['tax_total'] === 'number' ? merged['tax_total'] : Number(merged['tax_total']);
        if (Number.isNaN(num)) {
          fieldErrors['tax_total'] = 'Tax Total must be a number';
        } else {

        }
      }

      if (!isMissing(merged['grand_total'])) {
        const num = typeof merged['grand_total'] === 'number' ? merged['grand_total'] : Number(merged['grand_total']);
        if (Number.isNaN(num)) {
          fieldErrors['grand_total'] = 'Grand Total must be a number';
        } else {

        }
      }

      const __allowed_status = ['Draft', 'Posted', 'Cancelled'];
      if (!isMissing(merged['status']) && !__allowed_status.includes(String(merged['status']))) fieldErrors['status'] = 'Status must be one of: Draft, Posted, Cancelled';

      if (Object.keys(fieldErrors).length) {
        const err = new Error('Validation failed');
        err.statusCode = 400;
        err.fieldErrors = fieldErrors;
        throw err;
      }

    
      {
      const __cfg = this._invTxnCfg();
            if (this.slug === __cfg.invoice_entity) {
              const __existing = await this.repository.findById(this.slug, id);
              if (__existing) {
                const __status = String(__existing[__cfg.status_field] || 'Draft');
                const __lockedStatuses = ['Paid', 'Cancelled'];
                if (__lockedStatuses.includes(__status)) {
                  const __forbidden = [
                    __cfg.grand_total_field,
                    __cfg.paid_total_field,
                    __cfg.outstanding_field,
                  ];
                  const __hasForbiddenPatch = __forbidden.some((k) => Object.prototype.hasOwnProperty.call(data, k));
                  if (__hasForbiddenPatch) {
                    throw new Error('Paid or cancelled invoices cannot be financially modified');
                  }
                }
              }
            }
      }

    
    const result = await this.repository.update(this.slug, id, data);
    
    // @HOOK: AFTER_UPDATE_LOGGING

    return result;
  }

  async delete(id) {
    // @HOOK: BEFORE_DELETE_VALIDATION

    const result = await this.repository.delete(this.slug, id);
    
    // @HOOK: AFTER_DELETE_LOGGING

    return result;
  }

  async findById(id) {
    return this.repository.findById(this.slug, id);
  }

  async findAll(filter = {}) {
    return this.repository.findAll(this.slug, filter);
  }

  // @HOOK: ADDITIONAL_METHODS
    
  _invNoteCfg() {
    const cfg =
      this.mixinConfig?.invoice_note_workflow ||
      this.mixinConfig?.invoiceNoteWorkflow ||
      this.mixinConfig?.invoice_notes ||
      this.mixinConfig?.invoiceNotes ||
      {};
    return {
      invoice_entity: cfg.invoice_entity || cfg.invoiceEntity || 'invoices',
      note_entity: cfg.note_entity || cfg.noteEntity || 'invoice_notes',
      invoice_status_field: cfg.invoice_status_field || cfg.invoiceStatusField || 'status',
      invoice_grand_total_field: cfg.invoice_grand_total_field || cfg.invoiceGrandTotalField || 'grand_total',
      invoice_paid_total_field: cfg.invoice_paid_total_field || cfg.invoicePaidTotalField || 'paid_total',
      invoice_outstanding_field: cfg.invoice_outstanding_field || cfg.invoiceOutstandingField || 'outstanding_balance',
      note_number_field: cfg.note_number_field || cfg.noteNumberField || 'note_number',
      note_invoice_field: cfg.note_invoice_field || cfg.noteInvoiceField || 'source_invoice_id',
      note_type_field: cfg.note_type_field || cfg.noteTypeField || 'note_type',
      note_status_field: cfg.note_status_field || cfg.noteStatusField || 'status',
      note_amount_field: cfg.note_amount_field || cfg.noteAmountField || 'amount',
      note_tax_total_field: cfg.note_tax_total_field || cfg.noteTaxTotalField || 'tax_total',
      note_grand_total_field: cfg.note_grand_total_field || cfg.noteGrandTotalField || 'grand_total',
      note_posted_at_field: cfg.note_posted_at_field || cfg.notePostedAtField || 'posted_at',
      note_number_credit_prefix: cfg.note_number_credit_prefix || cfg.noteNumberCreditPrefix || 'CN-',
      note_number_debit_prefix: cfg.note_number_debit_prefix || cfg.noteNumberDebitPrefix || 'DN-',
      note_number_padding: Number(cfg.note_number_padding || cfg.noteNumberPadding || 6) || 6,
    };
  }

  _invNoteErr(message, statusCode = 400, details = null) {
    const err = new Error(message);
    err.statusCode = statusCode;
    if (details) err.details = details;
    return err;
  }

  _invNoteRound(rawValue) {
    const num = Number(rawValue);
    if (!Number.isFinite(num)) return 0;
    return Number(num.toFixed(2));
  }

  _invNoteType(rawType) {
    const type = String(rawType || '').toLowerCase();
    if (type === 'credit') return 'Credit';
    if (type === 'debit') return 'Debit';
    throw this._invNoteErr('note_type must be Credit or Debit', 400);
  }

  async _invNoteAllocateNumber(client, cfg, noteType) {
    const prefix = noteType === 'Credit' ? cfg.note_number_credit_prefix : cfg.note_number_debit_prefix;
    if (this.repository && typeof this.repository.allocatePrefixedNumber === 'function') {
      return this.repository.allocatePrefixedNumber(
        cfg.note_entity,
        cfg.note_number_field,
        prefix,
        { padding: cfg.note_number_padding },
        client
      );
    }
    const rows = await this.repository.findAllWithClient(cfg.note_entity, {}, client);
    let max = 0;
    for (const row of rows || []) {
      const raw = String(row && row[cfg.note_number_field] ? row[cfg.note_number_field] : '');
      if (!raw.startsWith(prefix)) continue;
      const parsed = parseInt(raw.slice(prefix.length), 10);
      if (!Number.isNaN(parsed)) max = Math.max(max, parsed);
    }
    return prefix + String(max + 1).padStart(cfg.note_number_padding, '0');
  }

  async _invNoteApplyInvoiceImpact(client, cfg, note, direction) {
    const invoiceId = note[cfg.note_invoice_field];
    const invoice = await this.repository.findByIdForUpdate(cfg.invoice_entity, invoiceId, client);
    if (!invoice) throw this._invNoteErr('Source invoice not found', 404);

    const type = this._invNoteType(note[cfg.note_type_field]);
    const noteGrand = this._invNoteRound(
      note[cfg.note_grand_total_field] !== undefined
        ? note[cfg.note_grand_total_field]
        : (this._invNoteRound(note[cfg.note_amount_field]) + this._invNoteRound(note[cfg.note_tax_total_field]))
    );
    if (noteGrand <= 0) {
      throw this._invNoteErr('Note grand total must be greater than zero', 400);
    }

    const signByType = type === 'Credit' ? -1 : 1;
    const signedDelta = noteGrand * signByType * direction;

    const currentGrand = this._invNoteRound(invoice[cfg.invoice_grand_total_field] || 0);
    const currentPaid = this._invNoteRound(invoice[cfg.invoice_paid_total_field] || 0);
    let nextGrand = this._invNoteRound(currentGrand + signedDelta);
    if (nextGrand < 0) {
      throw this._invNoteErr('Credit note exceeds invoice grand total', 409, {
        invoice_id: invoiceId,
        current_grand_total: currentGrand,
        note_impact: signedDelta,
      });
    }
    if (currentPaid > nextGrand + 0.0001) {
      throw this._invNoteErr('Invoice paid total cannot exceed adjusted grand total', 409, {
        invoice_id: invoiceId,
        paid_total: currentPaid,
        adjusted_grand_total: nextGrand,
      });
    }

    const outstanding = this._invNoteRound(Math.max(nextGrand - currentPaid, 0));
    let status = String(invoice[cfg.invoice_status_field] || 'Draft');
    if (status !== 'Cancelled') {
      if (outstanding <= 0) status = 'Paid';
      else if (status === 'Paid') status = 'Sent';
      else if (status === 'Draft') status = 'Sent';
    }

    return this.repository.updateWithClient(cfg.invoice_entity, invoiceId, {
      [cfg.invoice_grand_total_field]: nextGrand,
      [cfg.invoice_outstanding_field]: outstanding,
      [cfg.invoice_status_field]: status,
    }, client);
  }

  async listInvoiceNotes(invoiceId, filter = {}) {
    const cfg = this._invNoteCfg();
    if (this.slug !== cfg.invoice_entity) {
      throw this._invNoteErr(
        `Invoice note listing can only run on '${cfg.invoice_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }
    const where = {
      [cfg.note_invoice_field]: invoiceId,
    };
    if (filter && Object.prototype.hasOwnProperty.call(filter, cfg.note_status_field)) {
      where[cfg.note_status_field] = filter[cfg.note_status_field];
    } else if (filter && Object.prototype.hasOwnProperty.call(filter, 'status')) {
      where[cfg.note_status_field] = filter.status;
    }
    return this.repository.findAll(cfg.note_entity, where);
  }

  async createInvoiceNote(invoiceId, payload = {}) {
    const cfg = this._invNoteCfg();
    if (this.slug !== cfg.invoice_entity) {
      throw this._invNoteErr(
        `Invoice note create can only run on '${cfg.invoice_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    const amount = this._invNoteRound(payload[cfg.note_amount_field] ?? payload.amount);
    if (!Number.isFinite(amount) || amount <= 0) {
      throw this._invNoteErr(`${cfg.note_amount_field} must be greater than zero`, 400);
    }
    const taxTotal = this._invNoteRound(payload[cfg.note_tax_total_field] ?? payload.tax_total ?? 0);
    if (taxTotal < 0) {
      throw this._invNoteErr(`${cfg.note_tax_total_field} cannot be negative`, 400);
    }
    const type = this._invNoteType(payload[cfg.note_type_field] ?? payload.note_type);
    const grandTotal = this._invNoteRound(
      payload[cfg.note_grand_total_field] !== undefined
        ? payload[cfg.note_grand_total_field]
        : amount + taxTotal
    );

    return this.repository.withTransaction(async (client) => {
      const sourceInvoice = await this.repository.findByIdForUpdate(cfg.invoice_entity, invoiceId, client);
      if (!sourceInvoice) throw this._invNoteErr('Source invoice not found', 404);

      const noteNumber =
        payload[cfg.note_number_field] ||
        payload.note_number ||
        payload.noteNumber ||
        await this._invNoteAllocateNumber(client, cfg, type);

      const record = {
        [cfg.note_number_field]: noteNumber,
        [cfg.note_invoice_field]: invoiceId,
        [cfg.note_type_field]: type,
        [cfg.note_status_field]: 'Draft',
        issue_date: payload.issue_date || payload.issueDate || new Date().toISOString().slice(0, 10),
        [cfg.note_amount_field]: amount,
        [cfg.note_tax_total_field]: taxTotal,
        [cfg.note_grand_total_field]: grandTotal,
      };
      if (payload.reason) record.reason = payload.reason;
      if (payload.note) record.note = payload.note;

      const note = await this.repository.createWithClient(cfg.note_entity, record, client);
      return {
        note,
        invoice: sourceInvoice,
      };
    });
  }

  async postInvoiceNote(noteId, payload = {}) {
    const cfg = this._invNoteCfg();
    if (this.slug !== cfg.note_entity) {
      throw this._invNoteErr(
        `Invoice note post can only run on '${cfg.note_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    return this.repository.withTransaction(async (client) => {
      const note = await this.repository.findByIdForUpdate(cfg.note_entity, noteId, client);
      if (!note) throw this._invNoteErr('Invoice note not found', 404);
      const status = String(note[cfg.note_status_field] || 'Draft');
      if (status === 'Cancelled') {
        throw this._invNoteErr('Cancelled note cannot be posted', 409);
      }
      if (status !== 'Posted') {
        await this._invNoteApplyInvoiceImpact(client, cfg, note, 1);
      }

      const updatedNote = await this.repository.updateWithClient(cfg.note_entity, noteId, {
        [cfg.note_status_field]: 'Posted',
        [cfg.note_posted_at_field]: note[cfg.note_posted_at_field] || new Date().toISOString(),
        post_reference: payload.post_reference || payload.postReference || null,
      }, client);
      return {
        note: updatedNote,
      };
    });
  }

  async cancelInvoiceNote(noteId, payload = {}) {
    const cfg = this._invNoteCfg();
    if (this.slug !== cfg.note_entity) {
      throw this._invNoteErr(
        `Invoice note cancel can only run on '${cfg.note_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    return this.repository.withTransaction(async (client) => {
      const note = await this.repository.findByIdForUpdate(cfg.note_entity, noteId, client);
      if (!note) throw this._invNoteErr('Invoice note not found', 404);
      const status = String(note[cfg.note_status_field] || 'Draft');
      if (status === 'Cancelled') {
        throw this._invNoteErr('Invoice note is already cancelled', 409);
      }

      if (status === 'Posted') {
        await this._invNoteApplyInvoiceImpact(client, cfg, note, -1);
      }

      const updatedNote = await this.repository.updateWithClient(cfg.note_entity, noteId, {
        [cfg.note_status_field]: 'Cancelled',
        cancelled_at: new Date().toISOString(),
        cancel_reason: payload.reason || payload.cancel_reason || payload.cancelReason || null,
      }, client);
      return {
        note: updatedNote,
      };
    });
  }
    
    
  _invTxnCfg() {
    const cfg =
      this.mixinConfig?.invoice_transaction_safety ||
      this.mixinConfig?.invoiceTransactionSafety ||
      this.mixinConfig?.invoice_transactions ||
      this.mixinConfig?.invoiceTransactions ||
      {};
    const lifecycle =
      this.mixinConfig?.invoice_lifecycle ||
      this.mixinConfig?.invoiceLifecycle ||
      {};
    return {
      invoice_entity: cfg.invoice_entity || cfg.invoiceEntity || 'invoices',
      invoice_number_field: cfg.invoice_number_field || cfg.invoiceNumberField || 'invoice_number',
      status_field: cfg.status_field || cfg.statusField || lifecycle.status_field || lifecycle.statusField || 'status',
      grand_total_field: cfg.grand_total_field || cfg.grandTotalField || 'grand_total',
      paid_total_field: cfg.paid_total_field || cfg.paidTotalField || 'paid_total',
      outstanding_field: cfg.outstanding_field || cfg.outstandingField || 'outstanding_balance',
      idempotency_field: cfg.idempotency_field || cfg.idempotencyField || 'idempotency_key',
      posted_at_field: cfg.posted_at_field || cfg.postedAtField || 'posted_at',
      cancelled_at_field: cfg.cancelled_at_field || cfg.cancelledAtField || 'cancelled_at',
      number_prefix: cfg.number_prefix || cfg.numberPrefix || 'INV-',
      number_padding: Number(cfg.number_padding || cfg.numberPadding || 6) || 6,
      issue_status: cfg.issue_status || cfg.issueStatus || 'Sent',
      cancelled_status: cfg.cancelled_status || cfg.cancelledStatus || 'Cancelled',
      transitions:
        lifecycle.transitions && typeof lifecycle.transitions === 'object'
          ? lifecycle.transitions
          : {
              Draft: ['Sent', 'Cancelled'],
              Sent: ['Paid', 'Overdue', 'Cancelled'],
              Overdue: ['Paid', 'Cancelled'],
              Paid: [],
              Cancelled: [],
            },
      enforce_transitions:
        lifecycle.enforce_transitions !== false &&
        lifecycle.enforceTransitions !== false,
    };
  }

  _invTxnErr(message, statusCode = 400, details = null) {
    const err = new Error(message);
    err.statusCode = statusCode;
    if (details) err.details = details;
    return err;
  }

  _invTxnNowIso() {
    return new Date().toISOString();
  }

  _invTxnRound(rawValue) {
    const num = Number(rawValue);
    if (!Number.isFinite(num)) return 0;
    return Number(num.toFixed(2));
  }

  _invTxnAssertTransition(currentStatus, nextStatus, cfg) {
    if (!cfg.enforce_transitions) return;
    if (!currentStatus || !nextStatus || String(currentStatus) === String(nextStatus)) return;
    const map = cfg.transitions && typeof cfg.transitions === 'object' ? cfg.transitions : {};
    const allowed = Array.isArray(map[currentStatus]) ? map[currentStatus] : [];
    if (!allowed.includes(nextStatus)) {
      throw this._invTxnErr(`Invalid status transition: ${currentStatus} -> ${nextStatus}`, 409);
    }
  }

  async _invTxnAllocateNumber(cfg, client, invoice) {
    const current = invoice ? String(invoice[cfg.invoice_number_field] || '') : '';
    if (current && !current.startsWith('DRAFT-')) {
      return current;
    }

    if (this.repository && typeof this.repository.allocatePrefixedNumber === 'function') {
      return this.repository.allocatePrefixedNumber(
        cfg.invoice_entity,
        cfg.invoice_number_field,
        cfg.number_prefix,
        { padding: cfg.number_padding },
        client
      );
    }

    const rows = await this.repository.findAllWithClient(cfg.invoice_entity, {}, client);
    let max = 0;
    for (const row of rows || []) {
      const raw = String(row && row[cfg.invoice_number_field] ? row[cfg.invoice_number_field] : '');
      if (!raw.startsWith(cfg.number_prefix)) continue;
      const suffix = raw.slice(cfg.number_prefix.length);
      const parsed = parseInt(suffix, 10);
      if (!Number.isNaN(parsed)) {
        max = Math.max(max, parsed);
      }
    }
    const next = max + 1;
    return cfg.number_prefix + String(next).padStart(cfg.number_padding, '0');
  }

  async issueInvoice(invoiceId, payload = {}) {
    const cfg = this._invTxnCfg();
    if (this.slug !== cfg.invoice_entity) {
      throw this._invTxnErr(
        `Invoice issue workflow can only run on '${cfg.invoice_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    return this.repository.withTransaction(async (client) => {
      const invoice = await this.repository.findByIdForUpdate(this.slug, invoiceId, client);
      if (!invoice) throw this._invTxnErr('Invoice not found', 404);

      const currentStatus = String(invoice[cfg.status_field] || 'Draft');
      const nextStatus = String(payload.status || cfg.issue_status || 'Sent');
      this._invTxnAssertTransition(currentStatus, nextStatus, cfg);

      const invoiceNumber = await this._invTxnAllocateNumber(cfg, client, invoice);
      const grandTotal = this._invTxnRound(invoice[cfg.grand_total_field] || 0);
      const paidTotal = this._invTxnRound(invoice[cfg.paid_total_field] || 0);
      const outstanding = this._invTxnRound(Math.max(grandTotal - paidTotal, 0));

      const patch = {
        [cfg.invoice_number_field]: invoiceNumber,
        [cfg.status_field]: nextStatus,
        [cfg.posted_at_field]: this._invTxnNowIso(),
        [cfg.outstanding_field]: outstanding,
        [cfg.paid_total_field]: paidTotal,
      };
      if (cfg.idempotency_field && payload.idempotency_key) {
        patch[cfg.idempotency_field] = String(payload.idempotency_key);
      }

      const updated = await this.repository.updateWithClient(this.slug, invoiceId, patch, client);
      return {
        invoice: updated,
        operation: 'issue',
      };
    });
  }

  async cancelInvoice(invoiceId, payload = {}) {
    const cfg = this._invTxnCfg();
    if (this.slug !== cfg.invoice_entity) {
      throw this._invTxnErr(
        `Invoice cancel workflow can only run on '${cfg.invoice_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    return this.repository.withTransaction(async (client) => {
      const invoice = await this.repository.findByIdForUpdate(this.slug, invoiceId, client);
      if (!invoice) throw this._invTxnErr('Invoice not found', 404);

      const currentStatus = String(invoice[cfg.status_field] || 'Draft');
      const nextStatus = String(payload.status || cfg.cancelled_status || 'Cancelled');
      this._invTxnAssertTransition(currentStatus, nextStatus, cfg);

      const patch = {
        [cfg.status_field]: nextStatus,
        [cfg.cancelled_at_field]: this._invTxnNowIso(),
      };
      const updated = await this.repository.updateWithClient(this.slug, invoiceId, patch, client);
      return {
        invoice: updated,
        operation: 'cancel',
      };
    });
  }
    
}

module.exports = Invoice_notesService;
