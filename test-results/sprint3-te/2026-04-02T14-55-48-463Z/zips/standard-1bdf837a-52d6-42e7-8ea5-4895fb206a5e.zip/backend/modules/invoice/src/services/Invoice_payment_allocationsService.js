// brick-library/backend-bricks/core/BaseService.js.hbs
class Invoice_payment_allocationsService {
  constructor(repository, mixinConfig = {}) {
    this.repository = repository;
    this.slug = 'invoice_payment_allocations';
    this.mixinConfig = mixinConfig && typeof mixinConfig === 'object' ? mixinConfig : {};
  }

  async create(data) {
    // @HOOK: BEFORE_CREATE_VALIDATION
    
      // Schema-driven validation (generated)
      const fieldErrors = {};
      const isMissing = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
      const isMissingNonString = (v) => v === undefined || v === null;

      const __refIdSets = {};
      const getRefIdSet = async (slug) => {
        if (__refIdSets[slug]) return __refIdSets[slug];
        const all = await this.repository.findAll(slug);
        __refIdSets[slug] = new Set(all.map((x) => x.id));
        return __refIdSets[slug];
      };

      if (isMissing(data['payment_id'])) fieldErrors['payment_id'] = 'Payment Id is required';

      if (!isMissing(data['payment_id'])) {
        const ids = await getRefIdSet('invoice_payments');
        if (!ids.has(String(data['payment_id']))) fieldErrors['payment_id'] = 'Payment Id has an invalid reference';
      }

      if (isMissing(data['invoice_id'])) fieldErrors['invoice_id'] = 'Invoice Id is required';

      if (!isMissing(data['invoice_id'])) {
        const ids = await getRefIdSet('invoices');
        if (!ids.has(String(data['invoice_id']))) fieldErrors['invoice_id'] = 'Invoice Id has an invalid reference';
      }

      if (isMissing(data['amount'])) fieldErrors['amount'] = 'Amount is required';

      if (!isMissing(data['amount'])) {
        const num = typeof data['amount'] === 'number' ? data['amount'] : Number(data['amount']);
        if (Number.isNaN(num)) {
          fieldErrors['amount'] = 'Amount must be a number';
        } else {

        }
      }

      if (Object.keys(fieldErrors).length) {
        const err = new Error('Validation failed');
        err.statusCode = 400;
        err.fieldErrors = fieldErrors;
        throw err;
      }

    
    // @HOOK: BEFORE_CREATE_TRANSFORMATION
    
    const result = await this.repository.create(this.slug, data);
    
    // @HOOK: AFTER_CREATE_LOGGING
    
    return result;
  }

  async update(id, data) {
    // @HOOK: BEFORE_UPDATE_VALIDATION
    
      // Schema-driven validation (generated)
      const existing = await this.repository.findById(this.slug, id);
      if (!existing) return null;
      const merged = { ...existing, ...data };

      const fieldErrors = {};
      const isMissing = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
      const isMissingNonString = (v) => v === undefined || v === null;

      const __refIdSets = {};
      const getRefIdSet = async (slug) => {
        if (__refIdSets[slug]) return __refIdSets[slug];
        const all = await this.repository.findAll(slug);
        __refIdSets[slug] = new Set(all.map((x) => x.id));
        return __refIdSets[slug];
      };

      if (isMissing(merged['payment_id'])) fieldErrors['payment_id'] = 'Payment Id is required';

      if (!isMissing(merged['payment_id'])) {
        const ids = await getRefIdSet('invoice_payments');
        if (!ids.has(String(merged['payment_id']))) fieldErrors['payment_id'] = 'Payment Id has an invalid reference';
      }

      if (isMissing(merged['invoice_id'])) fieldErrors['invoice_id'] = 'Invoice Id is required';

      if (!isMissing(merged['invoice_id'])) {
        const ids = await getRefIdSet('invoices');
        if (!ids.has(String(merged['invoice_id']))) fieldErrors['invoice_id'] = 'Invoice Id has an invalid reference';
      }

      if (isMissing(merged['amount'])) fieldErrors['amount'] = 'Amount is required';

      if (!isMissing(merged['amount'])) {
        const num = typeof merged['amount'] === 'number' ? merged['amount'] : Number(merged['amount']);
        if (Number.isNaN(num)) {
          fieldErrors['amount'] = 'Amount must be a number';
        } else {

        }
      }

      if (Object.keys(fieldErrors).length) {
        const err = new Error('Validation failed');
        err.statusCode = 400;
        err.fieldErrors = fieldErrors;
        throw err;
      }

    
    const result = await this.repository.update(this.slug, id, data);
    
    // @HOOK: AFTER_UPDATE_LOGGING

    return result;
  }

  async delete(id) {
    // @HOOK: BEFORE_DELETE_VALIDATION

    const result = await this.repository.delete(this.slug, id);
    
    // @HOOK: AFTER_DELETE_LOGGING

    return result;
  }

  async findById(id) {
    return this.repository.findById(this.slug, id);
  }

  async findAll(filter = {}) {
    return this.repository.findAll(this.slug, filter);
  }

  // @HOOK: ADDITIONAL_METHODS
}

module.exports = Invoice_payment_allocationsService;
