// brick-library/backend-bricks/core/BaseService.js.hbs
class Invoice_paymentsService {
  constructor(repository, mixinConfig = {}) {
    this.repository = repository;
    this.slug = 'invoice_payments';
    this.mixinConfig = mixinConfig && typeof mixinConfig === 'object' ? mixinConfig : {};
  }

  async create(data) {
    // @HOOK: BEFORE_CREATE_VALIDATION
    
      // Schema-driven validation (generated)
      const fieldErrors = {};
      const isMissing = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
      const isMissingNonString = (v) => v === undefined || v === null;

      const existingItems = await this.repository.findAll(this.slug);

      const __refIdSets = {};
      const getRefIdSet = async (slug) => {
        if (__refIdSets[slug]) return __refIdSets[slug];
        const all = await this.repository.findAll(slug);
        __refIdSets[slug] = new Set(all.map((x) => x.id));
        return __refIdSets[slug];
      };

      if (!isMissing(data['payment_number']) && existingItems.some((it) => String(it['payment_number']) === String(data['payment_number']))) {
        fieldErrors['payment_number'] = 'Payment Number must be unique';
      }

      if (isMissing(data['invoice_id'])) fieldErrors['invoice_id'] = 'Invoice Id is required';

      if (!isMissing(data['invoice_id'])) {
        const ids = await getRefIdSet('invoices');
        if (!ids.has(String(data['invoice_id']))) fieldErrors['invoice_id'] = 'Invoice Id has an invalid reference';
      }

      if (isMissing(data['amount'])) fieldErrors['amount'] = 'Amount is required';

      if (!isMissing(data['amount'])) {
        const num = typeof data['amount'] === 'number' ? data['amount'] : Number(data['amount']);
        if (Number.isNaN(num)) {
          fieldErrors['amount'] = 'Amount must be a number';
        } else {

        }
      }

      if (isMissing(data['payment_date'])) fieldErrors['payment_date'] = 'Payment Date is required';

      const __allowed_status = ['Draft', 'Posted', 'Cancelled'];
      if (!isMissing(data['status']) && !__allowed_status.includes(String(data['status']))) fieldErrors['status'] = 'Status must be one of: Draft, Posted, Cancelled';

      if (!isMissing(data['customer_id'])) {
        const ids = await getRefIdSet('customers');
        if (!ids.has(String(data['customer_id']))) fieldErrors['customer_id'] = 'Customer has an invalid reference';
      }

      if (!isMissing(data['unallocated_amount'])) {
        const num = typeof data['unallocated_amount'] === 'number' ? data['unallocated_amount'] : Number(data['unallocated_amount']);
        if (Number.isNaN(num)) {
          fieldErrors['unallocated_amount'] = 'Unallocated Amount must be a number';
        } else {

          if (num < 0) fieldErrors['unallocated_amount'] = 'Unallocated Amount must be ≥ 0';

        }
      }

      if (Object.keys(fieldErrors).length) {
        const err = new Error('Validation failed');
        err.statusCode = 400;
        err.fieldErrors = fieldErrors;
        throw err;
      }

    
    // @HOOK: BEFORE_CREATE_TRANSFORMATION
    
      {
      const __cfg = this._invTxnCfg();
            if (this.slug === __cfg.invoice_entity) {
              if (data[__cfg.status_field] === undefined || data[__cfg.status_field] === null || data[__cfg.status_field] === '') {
                data[__cfg.status_field] = 'Draft';
              }
              const __grand = Number(data[__cfg.grand_total_field] || 0);
              const __paid = Number(data[__cfg.paid_total_field] || 0);
              if (!Number.isFinite(__paid) || __paid < 0) {
                data[__cfg.paid_total_field] = 0;
              }
              const __safeGrand = Number.isFinite(__grand) ? __grand : 0;
              const __safePaid = Number(data[__cfg.paid_total_field] || 0);
              if (data[__cfg.outstanding_field] === undefined || data[__cfg.outstanding_field] === null || data[__cfg.outstanding_field] === '') {
                data[__cfg.outstanding_field] = Number(Math.max(__safeGrand - __safePaid, 0).toFixed(2));
              }
              if (!data[__cfg.invoice_number_field]) {
                data[__cfg.invoice_number_field] = 'DRAFT-' + Date.now() + '-' + Math.floor(Math.random() * 100000);
              }
              if (__cfg.idempotency_field && !data[__cfg.idempotency_field]) {
                data[__cfg.idempotency_field] = 'inv-' + Date.now() + '-' + Math.floor(Math.random() * 100000);
              }
            }
      }

    
    const result = await this.repository.create(this.slug, data);
    
    // @HOOK: AFTER_CREATE_LOGGING
    
    return result;
  }

  async update(id, data) {
    // @HOOK: BEFORE_UPDATE_VALIDATION
    
      // Schema-driven validation (generated)
      const existing = await this.repository.findById(this.slug, id);
      if (!existing) return null;
      const merged = { ...existing, ...data };

      const fieldErrors = {};
      const isMissing = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
      const isMissingNonString = (v) => v === undefined || v === null;

      const existingItems = await this.repository.findAll(this.slug);

      const __refIdSets = {};
      const getRefIdSet = async (slug) => {
        if (__refIdSets[slug]) return __refIdSets[slug];
        const all = await this.repository.findAll(slug);
        __refIdSets[slug] = new Set(all.map((x) => x.id));
        return __refIdSets[slug];
      };

      if (!isMissing(merged['payment_number']) && existingItems.some((it) => it.id !== id && String(it['payment_number']) === String(merged['payment_number']))) {
        fieldErrors['payment_number'] = 'Payment Number must be unique';
      }

      if (isMissing(merged['invoice_id'])) fieldErrors['invoice_id'] = 'Invoice Id is required';

      if (!isMissing(merged['invoice_id'])) {
        const ids = await getRefIdSet('invoices');
        if (!ids.has(String(merged['invoice_id']))) fieldErrors['invoice_id'] = 'Invoice Id has an invalid reference';
      }

      if (isMissing(merged['amount'])) fieldErrors['amount'] = 'Amount is required';

      if (!isMissing(merged['amount'])) {
        const num = typeof merged['amount'] === 'number' ? merged['amount'] : Number(merged['amount']);
        if (Number.isNaN(num)) {
          fieldErrors['amount'] = 'Amount must be a number';
        } else {

        }
      }

      if (isMissing(merged['payment_date'])) fieldErrors['payment_date'] = 'Payment Date is required';

      const __allowed_status = ['Draft', 'Posted', 'Cancelled'];
      if (!isMissing(merged['status']) && !__allowed_status.includes(String(merged['status']))) fieldErrors['status'] = 'Status must be one of: Draft, Posted, Cancelled';

      if (!isMissing(merged['customer_id'])) {
        const ids = await getRefIdSet('customers');
        if (!ids.has(String(merged['customer_id']))) fieldErrors['customer_id'] = 'Customer has an invalid reference';
      }

      if (!isMissing(merged['unallocated_amount'])) {
        const num = typeof merged['unallocated_amount'] === 'number' ? merged['unallocated_amount'] : Number(merged['unallocated_amount']);
        if (Number.isNaN(num)) {
          fieldErrors['unallocated_amount'] = 'Unallocated Amount must be a number';
        } else {

          if (num < 0) fieldErrors['unallocated_amount'] = 'Unallocated Amount must be ≥ 0';

        }
      }

      if (Object.keys(fieldErrors).length) {
        const err = new Error('Validation failed');
        err.statusCode = 400;
        err.fieldErrors = fieldErrors;
        throw err;
      }

    
      {
      const __cfg = this._invTxnCfg();
            if (this.slug === __cfg.invoice_entity) {
              const __existing = await this.repository.findById(this.slug, id);
              if (__existing) {
                const __status = String(__existing[__cfg.status_field] || 'Draft');
                const __lockedStatuses = ['Paid', 'Cancelled'];
                if (__lockedStatuses.includes(__status)) {
                  const __forbidden = [
                    __cfg.grand_total_field,
                    __cfg.paid_total_field,
                    __cfg.outstanding_field,
                  ];
                  const __hasForbiddenPatch = __forbidden.some((k) => Object.prototype.hasOwnProperty.call(data, k));
                  if (__hasForbiddenPatch) {
                    throw new Error('Paid or cancelled invoices cannot be financially modified');
                  }
                }
              }
            }
      }

    
    const result = await this.repository.update(this.slug, id, data);
    
    // @HOOK: AFTER_UPDATE_LOGGING

    return result;
  }

  async delete(id) {
    // @HOOK: BEFORE_DELETE_VALIDATION
    
      // Delete protection (generated): prevent deleting a record that is referenced by others
      const dependents = [];

      {
        const rows = await this.repository.findAll('invoice_payment_allocations');
        const matches = rows.filter((row) => String(row['payment_id'] ?? '') === String(id));
        if (matches.length) {
          dependents.push({
            entity: 'invoice_payment_allocations',
            via: ['payment_id'],
            count: matches.length,
            preview: matches.slice(0, 10).map((r) => ({ id: r.id, display: r['payment_id'] || r.id })),
          });
        }
      }

      if (dependents.length) {
        const err = new Error('Cannot delete: this record is referenced by other records');
        err.statusCode = 409;
        err.dependents = dependents;
        throw err;
      }


    const result = await this.repository.delete(this.slug, id);
    
    // @HOOK: AFTER_DELETE_LOGGING

    return result;
  }

  async findById(id) {
    return this.repository.findById(this.slug, id);
  }

  async findAll(filter = {}) {
    return this.repository.findAll(this.slug, filter);
  }

  // @HOOK: ADDITIONAL_METHODS
    
  _invPayCfg() {
    const cfg =
      this.mixinConfig?.invoice_payment_workflow ||
      this.mixinConfig?.invoicePaymentWorkflow ||
      this.mixinConfig?.invoice_payments ||
      this.mixinConfig?.invoicePayments ||
      {};
    const invoiceTxn =
      this.mixinConfig?.invoice_transaction_safety ||
      this.mixinConfig?.invoiceTransactionSafety ||
      {};
    return {
      invoice_entity: cfg.invoice_entity || cfg.invoiceEntity || invoiceTxn.invoice_entity || invoiceTxn.invoiceEntity || 'invoices',
      payment_entity: cfg.payment_entity || cfg.paymentEntity || 'invoice_payments',
      allocation_entity: cfg.allocation_entity || cfg.allocationEntity || 'invoice_payment_allocations',
      invoice_status_field: cfg.invoice_status_field || cfg.invoiceStatusField || 'status',
      invoice_grand_total_field: cfg.invoice_grand_total_field || cfg.invoiceGrandTotalField || 'grand_total',
      invoice_paid_total_field: cfg.invoice_paid_total_field || cfg.invoicePaidTotalField || 'paid_total',
      invoice_outstanding_field: cfg.invoice_outstanding_field || cfg.invoiceOutstandingField || 'outstanding_balance',
      payment_number_field: cfg.payment_number_field || cfg.paymentNumberField || 'payment_number',
      payment_customer_field: cfg.payment_customer_field || cfg.paymentCustomerField || 'customer_id',
      payment_date_field: cfg.payment_date_field || cfg.paymentDateField || 'payment_date',
      payment_method_field: cfg.payment_method_field || cfg.paymentMethodField || 'payment_method',
      payment_amount_field: cfg.payment_amount_field || cfg.paymentAmountField || 'amount',
      payment_unallocated_field: cfg.payment_unallocated_field || cfg.paymentUnallocatedField || 'unallocated_amount',
      payment_status_field: cfg.payment_status_field || cfg.paymentStatusField || 'status',
      allocation_payment_field: cfg.allocation_payment_field || cfg.allocationPaymentField || 'payment_id',
      allocation_invoice_field: cfg.allocation_invoice_field || cfg.allocationInvoiceField || 'invoice_id',
      allocation_amount_field: cfg.allocation_amount_field || cfg.allocationAmountField || 'amount',
      allocation_date_field: cfg.allocation_date_field || cfg.allocationDateField || 'allocated_at',
      payment_number_prefix: cfg.payment_number_prefix || cfg.paymentNumberPrefix || 'PAY-',
      payment_number_padding: Number(cfg.payment_number_padding || cfg.paymentNumberPadding || 6) || 6,
    };
  }

  _invPayErr(message, statusCode = 400, details = null) {
    const err = new Error(message);
    err.statusCode = statusCode;
    if (details) err.details = details;
    return err;
  }

  _invPayRound(rawValue) {
    const num = Number(rawValue);
    if (!Number.isFinite(num)) return 0;
    return Number(num.toFixed(2));
  }

  _invPayPositive(rawValue, fieldName = 'amount') {
    const value = this._invPayRound(rawValue);
    if (!Number.isFinite(value) || value <= 0) {
      throw this._invPayErr(`${fieldName} must be greater than zero`, 400);
    }
    return value;
  }

  async _invPayApplyInvoiceDelta(client, cfg, invoiceId, paidDelta) {
    if (this.repository && typeof this.repository.atomicAdjustInvoiceFinancials === 'function') {
      return this.repository.atomicAdjustInvoiceFinancials(
        cfg.invoice_entity,
        invoiceId,
        {
          grandTotalField: cfg.invoice_grand_total_field,
          paidField: cfg.invoice_paid_total_field,
          outstandingField: cfg.invoice_outstanding_field,
          statusField: cfg.invoice_status_field,
          paidDelta,
          grandDelta: 0,
          autoStatus: true,
        },
        client
      );
    }

    const invoice = await this.repository.findByIdForUpdate(cfg.invoice_entity, invoiceId, client);
    if (!invoice) throw this._invPayErr('Invoice not found for allocation', 404);

    const grandTotal = this._invPayRound(invoice[cfg.invoice_grand_total_field] || 0);
    const currentPaid = this._invPayRound(invoice[cfg.invoice_paid_total_field] || 0);
    const nextPaid = this._invPayRound(currentPaid + paidDelta);
    if (nextPaid < 0) {
      throw this._invPayErr('Invoice paid total cannot go negative', 409, {
        invoice_id: invoiceId,
        current_paid: currentPaid,
        delta: paidDelta,
      });
    }
    if (nextPaid - grandTotal > 0.0001) {
      throw this._invPayErr('Payment allocation exceeds invoice grand total', 409, {
        invoice_id: invoiceId,
        grand_total: grandTotal,
        next_paid: nextPaid,
      });
    }

    const outstanding = this._invPayRound(Math.max(grandTotal - nextPaid, 0));
    let status = String(invoice[cfg.invoice_status_field] || 'Draft');
    if (status !== 'Cancelled') {
      if (outstanding <= 0) status = 'Paid';
      else if (status === 'Paid') status = 'Sent';
      else if (status === 'Draft') status = 'Sent';
    }

    return this.repository.updateWithClient(cfg.invoice_entity, invoiceId, {
      [cfg.invoice_paid_total_field]: nextPaid,
      [cfg.invoice_outstanding_field]: outstanding,
      [cfg.invoice_status_field]: status,
    }, client);
  }

  async _invPayAllocateNumber(client, cfg) {
    if (this.repository && typeof this.repository.allocatePrefixedNumber === 'function') {
      return this.repository.allocatePrefixedNumber(
        cfg.payment_entity,
        cfg.payment_number_field,
        cfg.payment_number_prefix,
        { padding: cfg.payment_number_padding },
        client
      );
    }
    const rows = await this.repository.findAllWithClient(cfg.payment_entity, {}, client);
    let max = 0;
    for (const row of rows || []) {
      const raw = String(row && row[cfg.payment_number_field] ? row[cfg.payment_number_field] : '');
      if (!raw.startsWith(cfg.payment_number_prefix)) continue;
      const parsed = parseInt(raw.slice(cfg.payment_number_prefix.length), 10);
      if (!Number.isNaN(parsed)) max = Math.max(max, parsed);
    }
    return cfg.payment_number_prefix + String(max + 1).padStart(cfg.payment_number_padding, '0');
  }

  async listInvoicePayments(invoiceId, filter = {}) {
    const cfg = this._invPayCfg();
    if (this.slug !== cfg.invoice_entity) {
      throw this._invPayErr(
        `Invoice payment listing can only run on '${cfg.invoice_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    const allocations = await this.repository.findAll(cfg.allocation_entity, {
      [cfg.allocation_invoice_field]: invoiceId,
    });
    const paymentIds = Array.from(new Set((allocations || []).map((row) => row && row[cfg.allocation_payment_field]).filter(Boolean)));
    const payments = paymentIds.length
      ? await this.repository.findAll(cfg.payment_entity, { id: paymentIds })
      : [];
    const byPaymentId = new Map((payments || []).map((row) => [String(row.id), row]));

    const withFilter = Array.isArray(allocations) ? allocations.filter((row) => {
      if (!filter || typeof filter !== 'object') return true;
      if (Object.prototype.hasOwnProperty.call(filter, 'status')) {
        const payment = byPaymentId.get(String(row[cfg.allocation_payment_field]));
        const status = String((payment && payment[cfg.payment_status_field]) || '');
        return status.toLowerCase() === String(filter.status || '').toLowerCase();
      }
      return true;
    }) : [];

    return withFilter.map((row) => ({
      allocation: row,
      payment: byPaymentId.get(String(row[cfg.allocation_payment_field])) || null,
    }));
  }

  async recordInvoicePayment(invoiceId, payload = {}) {
    const cfg = this._invPayCfg();
    if (this.slug !== cfg.invoice_entity) {
      throw this._invPayErr(
        `Invoice payment record can only run on '${cfg.invoice_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    const amount = this._invPayPositive(
      payload.amount ?? payload[cfg.payment_amount_field],
      cfg.payment_amount_field
    );

    return this.repository.withTransaction(async (client) => {
      const invoice = await this.repository.findByIdForUpdate(cfg.invoice_entity, invoiceId, client);
      if (!invoice) throw this._invPayErr('Invoice not found', 404);

      const outstanding = this._invPayRound(invoice[cfg.invoice_outstanding_field] || 0);
      const allocAmount = this._invPayRound(Math.min(amount, outstanding));
      const unallocated = this._invPayRound(Math.max(amount - allocAmount, 0));

      const paymentNumber = payload[cfg.payment_number_field] || payload.payment_number || payload.paymentNumber || await this._invPayAllocateNumber(client, cfg);
      const paymentPayload = {
        [cfg.payment_number_field]: paymentNumber,
        [cfg.payment_customer_field]:
          payload[cfg.payment_customer_field] ||
          payload.customer_id ||
          payload.customerId ||
          invoice.customer_id ||
          null,
        [cfg.payment_date_field]:
          payload[cfg.payment_date_field] ||
          payload.payment_date ||
          payload.paymentDate ||
          new Date().toISOString().slice(0, 10),
        [cfg.payment_method_field]:
          payload[cfg.payment_method_field] ||
          payload.payment_method ||
          payload.paymentMethod ||
          null,
        [cfg.payment_amount_field]: amount,
        [cfg.payment_unallocated_field]: unallocated,
        [cfg.payment_status_field]: 'Posted',
        posted_at: new Date().toISOString(),
      };
      if (payload.reference_number) paymentPayload.reference_number = payload.reference_number;
      if (payload.note) paymentPayload.note = payload.note;

      const payment = await this.repository.createWithClient(cfg.payment_entity, paymentPayload, client);
      let allocation = null;
      let updatedInvoice = invoice;

      if (allocAmount > 0) {
        allocation = await this.repository.createWithClient(
          cfg.allocation_entity,
          {
            [cfg.allocation_payment_field]: payment.id,
            [cfg.allocation_invoice_field]: invoiceId,
            [cfg.allocation_amount_field]: allocAmount,
            [cfg.allocation_date_field]: new Date().toISOString(),
          },
          client
        );
        updatedInvoice = await this._invPayApplyInvoiceDelta(client, cfg, invoiceId, allocAmount);
      }

      return {
        payment,
        allocation,
        invoice: updatedInvoice,
      };
    });
  }

  async postPayment(paymentId, payload = {}) {
    const cfg = this._invPayCfg();
    if (this.slug !== cfg.payment_entity) {
      throw this._invPayErr(
        `Payment posting can only run on '${cfg.payment_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    return this.repository.withTransaction(async (client) => {
      const payment = await this.repository.findByIdForUpdate(cfg.payment_entity, paymentId, client);
      if (!payment) throw this._invPayErr('Payment not found', 404);
      const currentStatus = String(payment[cfg.payment_status_field] || 'Draft');
      if (currentStatus === 'Cancelled') {
        throw this._invPayErr('Cancelled payment cannot be posted', 409);
      }

      const allocations = await this.repository.findAllWithClient(cfg.allocation_entity, {
        [cfg.allocation_payment_field]: paymentId,
      }, client);
      if (!Array.isArray(allocations) || allocations.length === 0) {
        const invoiceId = payload.invoice_id || payload.invoiceId || payload[cfg.allocation_invoice_field];
        const requestedAmount = payload.amount ?? payload[cfg.allocation_amount_field];
        if (invoiceId && requestedAmount) {
          const allocAmount = this._invPayPositive(requestedAmount, cfg.allocation_amount_field);
          const created = await this.repository.createWithClient(
            cfg.allocation_entity,
            {
              [cfg.allocation_payment_field]: paymentId,
              [cfg.allocation_invoice_field]: invoiceId,
              [cfg.allocation_amount_field]: allocAmount,
              [cfg.allocation_date_field]: new Date().toISOString(),
            },
            client
          );
          allocations.push(created);
        }
      }

      let totalAllocated = 0;
      if (currentStatus !== 'Posted') {
        for (const allocation of allocations) {
          const invoiceId = allocation[cfg.allocation_invoice_field];
          const allocAmount = this._invPayRound(allocation[cfg.allocation_amount_field] || 0);
          if (allocAmount <= 0) continue;
          totalAllocated += allocAmount;
          await this._invPayApplyInvoiceDelta(client, cfg, invoiceId, allocAmount);
        }
      } else {
        totalAllocated = allocations.reduce((sum, row) => sum + this._invPayRound(row[cfg.allocation_amount_field] || 0), 0);
      }

      const paymentAmount = this._invPayRound(payment[cfg.payment_amount_field] || 0);
      const nextUnallocated = this._invPayRound(Math.max(paymentAmount - totalAllocated, 0));
      const updated = await this.repository.updateWithClient(cfg.payment_entity, paymentId, {
        [cfg.payment_status_field]: 'Posted',
        [cfg.payment_unallocated_field]: nextUnallocated,
        posted_at: payment.posted_at || new Date().toISOString(),
      }, client);

      return {
        payment: updated,
        allocations,
      };
    });
  }

  async cancelPayment(paymentId, payload = {}) {
    const cfg = this._invPayCfg();
    if (this.slug !== cfg.payment_entity) {
      throw this._invPayErr(
        `Payment cancel can only run on '${cfg.payment_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    return this.repository.withTransaction(async (client) => {
      const payment = await this.repository.findByIdForUpdate(cfg.payment_entity, paymentId, client);
      if (!payment) throw this._invPayErr('Payment not found', 404);

      const currentStatus = String(payment[cfg.payment_status_field] || 'Draft');
      if (currentStatus === 'Cancelled') {
        throw this._invPayErr('Payment is already cancelled', 409);
      }

      const allocations = await this.repository.findAllWithClient(cfg.allocation_entity, {
        [cfg.allocation_payment_field]: paymentId,
      }, client);
      if (currentStatus === 'Posted') {
        for (const allocation of allocations || []) {
          const invoiceId = allocation[cfg.allocation_invoice_field];
          const allocAmount = this._invPayRound(allocation[cfg.allocation_amount_field] || 0);
          if (allocAmount <= 0) continue;
          await this._invPayApplyInvoiceDelta(client, cfg, invoiceId, -allocAmount);
        }
      }

      const updated = await this.repository.updateWithClient(cfg.payment_entity, paymentId, {
        [cfg.payment_status_field]: 'Cancelled',
        cancelled_at: new Date().toISOString(),
        cancel_reason: payload.reason || payload.cancel_reason || payload.cancelReason || null,
      }, client);
      return {
        payment: updated,
        allocations: allocations || [],
      };
    });
  }
    
    
  _invTxnCfg() {
    const cfg =
      this.mixinConfig?.invoice_transaction_safety ||
      this.mixinConfig?.invoiceTransactionSafety ||
      this.mixinConfig?.invoice_transactions ||
      this.mixinConfig?.invoiceTransactions ||
      {};
    const lifecycle =
      this.mixinConfig?.invoice_lifecycle ||
      this.mixinConfig?.invoiceLifecycle ||
      {};
    return {
      invoice_entity: cfg.invoice_entity || cfg.invoiceEntity || 'invoices',
      invoice_number_field: cfg.invoice_number_field || cfg.invoiceNumberField || 'invoice_number',
      status_field: cfg.status_field || cfg.statusField || lifecycle.status_field || lifecycle.statusField || 'status',
      grand_total_field: cfg.grand_total_field || cfg.grandTotalField || 'grand_total',
      paid_total_field: cfg.paid_total_field || cfg.paidTotalField || 'paid_total',
      outstanding_field: cfg.outstanding_field || cfg.outstandingField || 'outstanding_balance',
      idempotency_field: cfg.idempotency_field || cfg.idempotencyField || 'idempotency_key',
      posted_at_field: cfg.posted_at_field || cfg.postedAtField || 'posted_at',
      cancelled_at_field: cfg.cancelled_at_field || cfg.cancelledAtField || 'cancelled_at',
      number_prefix: cfg.number_prefix || cfg.numberPrefix || 'INV-',
      number_padding: Number(cfg.number_padding || cfg.numberPadding || 6) || 6,
      issue_status: cfg.issue_status || cfg.issueStatus || 'Sent',
      cancelled_status: cfg.cancelled_status || cfg.cancelledStatus || 'Cancelled',
      transitions:
        lifecycle.transitions && typeof lifecycle.transitions === 'object'
          ? lifecycle.transitions
          : {
              Draft: ['Sent', 'Cancelled'],
              Sent: ['Paid', 'Overdue', 'Cancelled'],
              Overdue: ['Paid', 'Cancelled'],
              Paid: [],
              Cancelled: [],
            },
      enforce_transitions:
        lifecycle.enforce_transitions !== false &&
        lifecycle.enforceTransitions !== false,
    };
  }

  _invTxnErr(message, statusCode = 400, details = null) {
    const err = new Error(message);
    err.statusCode = statusCode;
    if (details) err.details = details;
    return err;
  }

  _invTxnNowIso() {
    return new Date().toISOString();
  }

  _invTxnRound(rawValue) {
    const num = Number(rawValue);
    if (!Number.isFinite(num)) return 0;
    return Number(num.toFixed(2));
  }

  _invTxnAssertTransition(currentStatus, nextStatus, cfg) {
    if (!cfg.enforce_transitions) return;
    if (!currentStatus || !nextStatus || String(currentStatus) === String(nextStatus)) return;
    const map = cfg.transitions && typeof cfg.transitions === 'object' ? cfg.transitions : {};
    const allowed = Array.isArray(map[currentStatus]) ? map[currentStatus] : [];
    if (!allowed.includes(nextStatus)) {
      throw this._invTxnErr(`Invalid status transition: ${currentStatus} -> ${nextStatus}`, 409);
    }
  }

  async _invTxnAllocateNumber(cfg, client, invoice) {
    const current = invoice ? String(invoice[cfg.invoice_number_field] || '') : '';
    if (current && !current.startsWith('DRAFT-')) {
      return current;
    }

    if (this.repository && typeof this.repository.allocatePrefixedNumber === 'function') {
      return this.repository.allocatePrefixedNumber(
        cfg.invoice_entity,
        cfg.invoice_number_field,
        cfg.number_prefix,
        { padding: cfg.number_padding },
        client
      );
    }

    const rows = await this.repository.findAllWithClient(cfg.invoice_entity, {}, client);
    let max = 0;
    for (const row of rows || []) {
      const raw = String(row && row[cfg.invoice_number_field] ? row[cfg.invoice_number_field] : '');
      if (!raw.startsWith(cfg.number_prefix)) continue;
      const suffix = raw.slice(cfg.number_prefix.length);
      const parsed = parseInt(suffix, 10);
      if (!Number.isNaN(parsed)) {
        max = Math.max(max, parsed);
      }
    }
    const next = max + 1;
    return cfg.number_prefix + String(next).padStart(cfg.number_padding, '0');
  }

  async issueInvoice(invoiceId, payload = {}) {
    const cfg = this._invTxnCfg();
    if (this.slug !== cfg.invoice_entity) {
      throw this._invTxnErr(
        `Invoice issue workflow can only run on '${cfg.invoice_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    return this.repository.withTransaction(async (client) => {
      const invoice = await this.repository.findByIdForUpdate(this.slug, invoiceId, client);
      if (!invoice) throw this._invTxnErr('Invoice not found', 404);

      const currentStatus = String(invoice[cfg.status_field] || 'Draft');
      const nextStatus = String(payload.status || cfg.issue_status || 'Sent');
      this._invTxnAssertTransition(currentStatus, nextStatus, cfg);

      const invoiceNumber = await this._invTxnAllocateNumber(cfg, client, invoice);
      const grandTotal = this._invTxnRound(invoice[cfg.grand_total_field] || 0);
      const paidTotal = this._invTxnRound(invoice[cfg.paid_total_field] || 0);
      const outstanding = this._invTxnRound(Math.max(grandTotal - paidTotal, 0));

      const patch = {
        [cfg.invoice_number_field]: invoiceNumber,
        [cfg.status_field]: nextStatus,
        [cfg.posted_at_field]: this._invTxnNowIso(),
        [cfg.outstanding_field]: outstanding,
        [cfg.paid_total_field]: paidTotal,
      };
      if (cfg.idempotency_field && payload.idempotency_key) {
        patch[cfg.idempotency_field] = String(payload.idempotency_key);
      }

      const updated = await this.repository.updateWithClient(this.slug, invoiceId, patch, client);
      return {
        invoice: updated,
        operation: 'issue',
      };
    });
  }

  async cancelInvoice(invoiceId, payload = {}) {
    const cfg = this._invTxnCfg();
    if (this.slug !== cfg.invoice_entity) {
      throw this._invTxnErr(
        `Invoice cancel workflow can only run on '${cfg.invoice_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    return this.repository.withTransaction(async (client) => {
      const invoice = await this.repository.findByIdForUpdate(this.slug, invoiceId, client);
      if (!invoice) throw this._invTxnErr('Invoice not found', 404);

      const currentStatus = String(invoice[cfg.status_field] || 'Draft');
      const nextStatus = String(payload.status || cfg.cancelled_status || 'Cancelled');
      this._invTxnAssertTransition(currentStatus, nextStatus, cfg);

      const patch = {
        [cfg.status_field]: nextStatus,
        [cfg.cancelled_at_field]: this._invTxnNowIso(),
      };
      const updated = await this.repository.updateWithClient(this.slug, invoiceId, patch, client);
      return {
        invoice: updated,
        operation: 'cancel',
      };
    });
  }
    
}

module.exports = Invoice_paymentsService;
