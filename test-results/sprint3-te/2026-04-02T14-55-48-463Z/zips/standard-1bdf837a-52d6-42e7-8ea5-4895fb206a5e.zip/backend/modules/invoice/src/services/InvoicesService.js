// brick-library/backend-bricks/core/BaseService.js.hbs
class InvoicesService {
  constructor(repository, mixinConfig = {}) {
    this.repository = repository;
    this.slug = 'invoices';
    this.mixinConfig = mixinConfig && typeof mixinConfig === 'object' ? mixinConfig : {};
  }

  async create(data) {
    // @HOOK: BEFORE_CREATE_VALIDATION
    
      // Schema-driven validation (generated)
      const fieldErrors = {};
      const isMissing = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
      const isMissingNonString = (v) => v === undefined || v === null;

      const existingItems = await this.repository.findAll(this.slug);

      const __refIdSets = {};
      const getRefIdSet = async (slug) => {
        if (__refIdSets[slug]) return __refIdSets[slug];
        const all = await this.repository.findAll(slug);
        __refIdSets[slug] = new Set(all.map((x) => x.id));
        return __refIdSets[slug];
      };

      if (isMissing(data['invoice_number'])) fieldErrors['invoice_number'] = 'Invoice Number is required';

      if (!isMissing(data['invoice_number']) && existingItems.some((it) => String(it['invoice_number']) === String(data['invoice_number']))) {
        fieldErrors['invoice_number'] = 'Invoice Number must be unique';
      }

      if (isMissing(data['customer_id'])) fieldErrors['customer_id'] = 'Customer Id is required';

      if (!isMissing(data['customer_id'])) {
        const ids = await getRefIdSet('customers');
        if (!ids.has(String(data['customer_id']))) fieldErrors['customer_id'] = 'Customer Id has an invalid reference';
      }

      if (isMissing(data['issue_date'])) fieldErrors['issue_date'] = 'Issue Date is required';

      if (isMissing(data['due_date'])) fieldErrors['due_date'] = 'Due Date is required';

      if (isMissing(data['status'])) fieldErrors['status'] = 'Status is required';

      const __allowed_status = ['Draft', 'Sent', 'Paid', 'Overdue', 'Cancelled'];
      if (!isMissing(data['status']) && !__allowed_status.includes(String(data['status']))) fieldErrors['status'] = 'Status must be one of: Draft, Sent, Paid, Overdue, Cancelled';

      if (!isMissing(data['subtotal'])) {
        const num = typeof data['subtotal'] === 'number' ? data['subtotal'] : Number(data['subtotal']);
        if (Number.isNaN(num)) {
          fieldErrors['subtotal'] = 'Subtotal must be a number';
        } else {

        }
      }

      if (!isMissing(data['tax_total'])) {
        const num = typeof data['tax_total'] === 'number' ? data['tax_total'] : Number(data['tax_total']);
        if (Number.isNaN(num)) {
          fieldErrors['tax_total'] = 'Tax Total must be a number';
        } else {

        }
      }

      if (!isMissing(data['grand_total'])) {
        const num = typeof data['grand_total'] === 'number' ? data['grand_total'] : Number(data['grand_total']);
        if (Number.isNaN(num)) {
          fieldErrors['grand_total'] = 'Grand Total must be a number';
        } else {

        }
      }

      if (!isMissing(data['paid_total'])) {
        const num = typeof data['paid_total'] === 'number' ? data['paid_total'] : Number(data['paid_total']);
        if (Number.isNaN(num)) {
          fieldErrors['paid_total'] = 'Paid Total must be a number';
        } else {

        }
      }

      if (!isMissing(data['outstanding_balance'])) {
        const num = typeof data['outstanding_balance'] === 'number' ? data['outstanding_balance'] : Number(data['outstanding_balance']);
        if (Number.isNaN(num)) {
          fieldErrors['outstanding_balance'] = 'Outstanding Balance must be a number';
        } else {

        }
      }

      if (!isMissing(data['discount_total'])) {
        const num = typeof data['discount_total'] === 'number' ? data['discount_total'] : Number(data['discount_total']);
        if (Number.isNaN(num)) {
          fieldErrors['discount_total'] = 'Discount Total must be a number';
        } else {

        }
      }

      if (!isMissing(data['additional_charges_total'])) {
        const num = typeof data['additional_charges_total'] === 'number' ? data['additional_charges_total'] : Number(data['additional_charges_total']);
        if (Number.isNaN(num)) {
          fieldErrors['additional_charges_total'] = 'Additional Charges Total must be a number';
        } else {

        }
      }

      if (Object.keys(fieldErrors).length) {
        const err = new Error('Validation failed');
        err.statusCode = 400;
        err.fieldErrors = fieldErrors;
        throw err;
      }

    
    // @HOOK: BEFORE_CREATE_TRANSFORMATION
    
      {
      const INVOICE_CFG = {"prefix":"INV-","tax_rate":0,"payment_terms":30,"statuses":["Draft","Sent","Paid","Overdue","Cancelled"],"invoice_number_field":"invoice_number","status_field":"status","subtotal_field":"subtotal","tax_total_field":"tax_total","grand_total_field":"grand_total","discount_total_field":"discount_total","additional_charges_field":"additional_charges_total","paid_total_field":"paid_total","outstanding_field":"outstanding_balance","auto_number_mode":"workflow","use_calculation_engine":true};
            const allowedStatuses = Array.isArray(INVOICE_CFG.statuses) ? INVOICE_CFG.statuses : ['Draft', 'Sent', 'Paid', 'Overdue', 'Cancelled'];
            const statusField = INVOICE_CFG.status_field || 'status';
            const numberField = INVOICE_CFG.invoice_number_field || 'invoice_number';
            const subtotalField = INVOICE_CFG.subtotal_field || 'subtotal';
            const taxTotalField = INVOICE_CFG.tax_total_field || 'tax_total';
            const grandTotalField = INVOICE_CFG.grand_total_field || 'grand_total';
            const discountTotalField = INVOICE_CFG.discount_total_field || 'discount_total';
            const chargesField = INVOICE_CFG.additional_charges_field || 'additional_charges_total';
            const paidField = INVOICE_CFG.paid_total_field || 'paid_total';
            const outstandingField = INVOICE_CFG.outstanding_field || 'outstanding_balance';
            const useCalcEngine = INVOICE_CFG.use_calculation_engine === true;
            const autoNumberMode = String(INVOICE_CFG.auto_number_mode || 'create').toLowerCase();
            const round2 = (raw) => {
              const num = Number(raw);
              if (!Number.isFinite(num)) return 0;
              return Number(num.toFixed(2));
            };
      
            if (!data[statusField]) {
              data[statusField] = allowedStatuses[0] || 'Draft';
            }
            if (!allowedStatuses.includes(data[statusField])) {
              throw new Error('Invalid invoice status');
            }
      
            const prefix = String(INVOICE_CFG.prefix || 'INV-');
            if (!data[numberField]) {
              if (autoNumberMode === 'workflow') {
                data[numberField] = 'DRAFT-' + Date.now() + '-' + Math.floor(Math.random() * 100000);
              } else {
                const existing = await this.repository.findAll(this.slug, {});
                let max = 0;
                for (const row of existing) {
                  const raw = String(row?.[numberField] || '');
                  if (!raw.startsWith(prefix)) continue;
                  const suffix = raw.slice(prefix.length);
                  const num = parseInt(suffix, 10);
                  if (!isNaN(num)) max = Math.max(max, num);
                }
                const next = max + 1;
                data[numberField] = prefix + String(next).padStart(6, '0');
              }
            } else {
              const existing = await this.repository.findAll(this.slug, {});
              const duplicate = existing.find((row) => String(row?.[numberField] || '') === String(data[numberField] || ''));
              if (duplicate) {
                throw new Error('Invoice number must be unique');
              }
            }
      
            if (!data.issue_date) {
              data.issue_date = new Date().toISOString().slice(0, 10);
            }
            if (!data.due_date) {
              const base = new Date(data.issue_date);
              const offset = Number(INVOICE_CFG.payment_terms ?? 30) || 30;
              if (!isNaN(base.getTime())) {
                base.setDate(base.getDate() + offset);
                data.due_date = base.toISOString().slice(0, 10);
              }
            }
      
            if (!useCalcEngine) {
              const subtotal = Number(data[subtotalField] ?? 0) || 0;
              const taxRate = Number(INVOICE_CFG.tax_rate ?? 0) || 0;
              const taxTotal = Number(((subtotal * taxRate) / 100).toFixed(2));
              const grandTotal = Number((subtotal + taxTotal).toFixed(2));
              data[subtotalField] = subtotal;
              data[taxTotalField] = taxTotal;
              data[grandTotalField] = grandTotal;
            } else {
              data[subtotalField] = round2(data[subtotalField] ?? 0);
              data[discountTotalField] = round2(data[discountTotalField] ?? 0);
              data[chargesField] = round2(data[chargesField] ?? 0);
              data[taxTotalField] = round2(data[taxTotalField] ?? 0);
              data[grandTotalField] = round2(data[grandTotalField] ?? 0);
            }
      
            data[paidField] = round2(data[paidField] ?? 0);
            const outstanding = round2(Math.max((data[grandTotalField] || 0) - (data[paidField] || 0), 0));
            if (data[outstandingField] === undefined || data[outstandingField] === null || data[outstandingField] === '') {
              data[outstandingField] = outstanding;
            } else {
              data[outstandingField] = round2(data[outstandingField]);
            }
      }

    
      {
      const __cfg = this._invTxnCfg();
            if (this.slug === __cfg.invoice_entity) {
              if (data[__cfg.status_field] === undefined || data[__cfg.status_field] === null || data[__cfg.status_field] === '') {
                data[__cfg.status_field] = 'Draft';
              }
              const __grand = Number(data[__cfg.grand_total_field] || 0);
              const __paid = Number(data[__cfg.paid_total_field] || 0);
              if (!Number.isFinite(__paid) || __paid < 0) {
                data[__cfg.paid_total_field] = 0;
              }
              const __safeGrand = Number.isFinite(__grand) ? __grand : 0;
              const __safePaid = Number(data[__cfg.paid_total_field] || 0);
              if (data[__cfg.outstanding_field] === undefined || data[__cfg.outstanding_field] === null || data[__cfg.outstanding_field] === '') {
                data[__cfg.outstanding_field] = Number(Math.max(__safeGrand - __safePaid, 0).toFixed(2));
              }
              if (!data[__cfg.invoice_number_field]) {
                data[__cfg.invoice_number_field] = 'DRAFT-' + Date.now() + '-' + Math.floor(Math.random() * 100000);
              }
              if (__cfg.idempotency_field && !data[__cfg.idempotency_field]) {
                data[__cfg.idempotency_field] = 'inv-' + Date.now() + '-' + Math.floor(Math.random() * 100000);
              }
            }
      }

    
    const result = await this.repository.create(this.slug, data);
    
    // @HOOK: AFTER_CREATE_LOGGING
    
    return result;
  }

  async update(id, data) {
    // @HOOK: BEFORE_UPDATE_VALIDATION
    
      // Schema-driven validation (generated)
      const existing = await this.repository.findById(this.slug, id);
      if (!existing) return null;
      const merged = { ...existing, ...data };

      const fieldErrors = {};
      const isMissing = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
      const isMissingNonString = (v) => v === undefined || v === null;

      const existingItems = await this.repository.findAll(this.slug);

      const __refIdSets = {};
      const getRefIdSet = async (slug) => {
        if (__refIdSets[slug]) return __refIdSets[slug];
        const all = await this.repository.findAll(slug);
        __refIdSets[slug] = new Set(all.map((x) => x.id));
        return __refIdSets[slug];
      };

      if (isMissing(merged['invoice_number'])) fieldErrors['invoice_number'] = 'Invoice Number is required';

      if (!isMissing(merged['invoice_number']) && existingItems.some((it) => it.id !== id && String(it['invoice_number']) === String(merged['invoice_number']))) {
        fieldErrors['invoice_number'] = 'Invoice Number must be unique';
      }

      if (isMissing(merged['customer_id'])) fieldErrors['customer_id'] = 'Customer Id is required';

      if (!isMissing(merged['customer_id'])) {
        const ids = await getRefIdSet('customers');
        if (!ids.has(String(merged['customer_id']))) fieldErrors['customer_id'] = 'Customer Id has an invalid reference';
      }

      if (isMissing(merged['issue_date'])) fieldErrors['issue_date'] = 'Issue Date is required';

      if (isMissing(merged['due_date'])) fieldErrors['due_date'] = 'Due Date is required';

      if (isMissing(merged['status'])) fieldErrors['status'] = 'Status is required';

      const __allowed_status = ['Draft', 'Sent', 'Paid', 'Overdue', 'Cancelled'];
      if (!isMissing(merged['status']) && !__allowed_status.includes(String(merged['status']))) fieldErrors['status'] = 'Status must be one of: Draft, Sent, Paid, Overdue, Cancelled';

      if (!isMissing(merged['subtotal'])) {
        const num = typeof merged['subtotal'] === 'number' ? merged['subtotal'] : Number(merged['subtotal']);
        if (Number.isNaN(num)) {
          fieldErrors['subtotal'] = 'Subtotal must be a number';
        } else {

        }
      }

      if (!isMissing(merged['tax_total'])) {
        const num = typeof merged['tax_total'] === 'number' ? merged['tax_total'] : Number(merged['tax_total']);
        if (Number.isNaN(num)) {
          fieldErrors['tax_total'] = 'Tax Total must be a number';
        } else {

        }
      }

      if (!isMissing(merged['grand_total'])) {
        const num = typeof merged['grand_total'] === 'number' ? merged['grand_total'] : Number(merged['grand_total']);
        if (Number.isNaN(num)) {
          fieldErrors['grand_total'] = 'Grand Total must be a number';
        } else {

        }
      }

      if (!isMissing(merged['paid_total'])) {
        const num = typeof merged['paid_total'] === 'number' ? merged['paid_total'] : Number(merged['paid_total']);
        if (Number.isNaN(num)) {
          fieldErrors['paid_total'] = 'Paid Total must be a number';
        } else {

        }
      }

      if (!isMissing(merged['outstanding_balance'])) {
        const num = typeof merged['outstanding_balance'] === 'number' ? merged['outstanding_balance'] : Number(merged['outstanding_balance']);
        if (Number.isNaN(num)) {
          fieldErrors['outstanding_balance'] = 'Outstanding Balance must be a number';
        } else {

        }
      }

      if (!isMissing(merged['discount_total'])) {
        const num = typeof merged['discount_total'] === 'number' ? merged['discount_total'] : Number(merged['discount_total']);
        if (Number.isNaN(num)) {
          fieldErrors['discount_total'] = 'Discount Total must be a number';
        } else {

        }
      }

      if (!isMissing(merged['additional_charges_total'])) {
        const num = typeof merged['additional_charges_total'] === 'number' ? merged['additional_charges_total'] : Number(merged['additional_charges_total']);
        if (Number.isNaN(num)) {
          fieldErrors['additional_charges_total'] = 'Additional Charges Total must be a number';
        } else {

        }
      }

      if (Object.keys(fieldErrors).length) {
        const err = new Error('Validation failed');
        err.statusCode = 400;
        err.fieldErrors = fieldErrors;
        throw err;
      }

    
      {
      const __cfg = this.mixinConfig?.invoice_lifecycle || this.mixinConfig?.invoiceLifecycle || {};
            const __statusField = __cfg.status_field || __cfg.statusField || 'status';
            const __enforceTransitions = __cfg.enforce_transitions === true || __cfg.enforceTransitions === true;
            const __statusList = Array.isArray(__cfg.statuses) && __cfg.statuses.length
              ? __cfg.statuses
              : ['Draft', 'Sent', 'Paid', 'Overdue', 'Cancelled'];
            const __customTransitions = __cfg.transitions && typeof __cfg.transitions === 'object' ? __cfg.transitions : null;
            const __defaultTransitions = {
              Draft: ['Sent', 'Cancelled'],
              Sent: ['Paid', 'Overdue', 'Cancelled'],
              Overdue: ['Paid', 'Cancelled'],
              Paid: [],
              Cancelled: [],
            };
            const __transitions = __customTransitions || __defaultTransitions;
      
            if (data && data[__statusField] !== undefined) {
              const __nextStatus = data[__statusField];
              if (__statusList && !__statusList.includes(__nextStatus)) {
                throw new Error(`${__statusField} must be one of: ${__statusList.join(', ')}`);
              }
      
              if (__enforceTransitions) {
                const __existing = await this.repository.findById(this.slug, id);
                const __currentStatus = __existing ? __existing[__statusField] : null;
      
                if (__currentStatus && __currentStatus !== __nextStatus) {
                  const __allowed = Array.isArray(__transitions[__currentStatus]) ? __transitions[__currentStatus] : [];
                  if (!__allowed.includes(__nextStatus)) {
                    throw new Error(`Invalid status transition: ${__currentStatus} -> ${__nextStatus}`);
                  }
                }
              }
            }
      }

    
      {
      const INVOICE_CFG = {"prefix":"INV-","tax_rate":0,"payment_terms":30,"statuses":["Draft","Sent","Paid","Overdue","Cancelled"],"invoice_number_field":"invoice_number","status_field":"status","subtotal_field":"subtotal","tax_total_field":"tax_total","grand_total_field":"grand_total","discount_total_field":"discount_total","additional_charges_field":"additional_charges_total","paid_total_field":"paid_total","outstanding_field":"outstanding_balance","auto_number_mode":"workflow","use_calculation_engine":true};
            const allowedStatuses = Array.isArray(INVOICE_CFG.statuses) ? INVOICE_CFG.statuses : ['Draft', 'Sent', 'Paid', 'Overdue', 'Cancelled'];
            const statusField = INVOICE_CFG.status_field || 'status';
            const numberField = INVOICE_CFG.invoice_number_field || 'invoice_number';
            const subtotalField = INVOICE_CFG.subtotal_field || 'subtotal';
            const taxTotalField = INVOICE_CFG.tax_total_field || 'tax_total';
            const grandTotalField = INVOICE_CFG.grand_total_field || 'grand_total';
            const discountTotalField = INVOICE_CFG.discount_total_field || 'discount_total';
            const chargesField = INVOICE_CFG.additional_charges_field || 'additional_charges_total';
            const paidField = INVOICE_CFG.paid_total_field || 'paid_total';
            const outstandingField = INVOICE_CFG.outstanding_field || 'outstanding_balance';
            const useCalcEngine = INVOICE_CFG.use_calculation_engine === true;
            const round2 = (raw) => {
              const num = Number(raw);
              if (!Number.isFinite(num)) return 0;
              return Number(num.toFixed(2));
            };
      
            if (data[statusField] && !allowedStatuses.includes(data[statusField])) {
              throw new Error('Invalid invoice status');
            }
      
            if (data[numberField]) {
              const existing = await this.repository.findAll(this.slug, {});
              const duplicate = existing.find((row) =>
                String(row?.[numberField] || '') === String(data[numberField] || '') && String(row?.id || '') !== String(id || '')
              );
              if (duplicate) {
                throw new Error('Invoice number must be unique');
              }
            }
      
            if (!useCalcEngine && (data[subtotalField] !== undefined || data[taxTotalField] !== undefined || data[grandTotalField] !== undefined)) {
              const existingInvoice = await this.repository.findById(this.slug, id);
              const subtotal = round2(data[subtotalField] !== undefined ? data[subtotalField] : existingInvoice?.[subtotalField]);
              const taxRate = Number(INVOICE_CFG.tax_rate ?? 0) || 0;
              const taxTotal = round2((subtotal * taxRate) / 100);
              const grandTotal = round2(subtotal + taxTotal);
      
              data[subtotalField] = subtotal;
              data[taxTotalField] = taxTotal;
              data[grandTotalField] = grandTotal;
            }
      
            if (useCalcEngine) {
              if (data[discountTotalField] !== undefined) data[discountTotalField] = round2(data[discountTotalField]);
              if (data[chargesField] !== undefined) data[chargesField] = round2(data[chargesField]);
            }
      
            if (data[paidField] !== undefined || data[grandTotalField] !== undefined || data[outstandingField] !== undefined) {
              const existingInvoice = data.__invExisting || await this.repository.findById(this.slug, id);
              const grand = round2(data[grandTotalField] !== undefined ? data[grandTotalField] : existingInvoice?.[grandTotalField]);
              const paid = round2(data[paidField] !== undefined ? data[paidField] : existingInvoice?.[paidField]);
              if (paid < 0) {
                throw new Error('Paid total cannot be negative');
              }
              if (paid > grand + 0.0001) {
                throw new Error('Paid total cannot exceed grand total');
              }
              data[paidField] = paid;
              data[outstandingField] = round2(Math.max(grand - paid, 0));
              delete data.__invExisting;
            }
      }

    
      {
      const __cfg = this._invTxnCfg();
            if (this.slug === __cfg.invoice_entity) {
              const __existing = await this.repository.findById(this.slug, id);
              if (__existing) {
                const __status = String(__existing[__cfg.status_field] || 'Draft');
                const __lockedStatuses = ['Paid', 'Cancelled'];
                if (__lockedStatuses.includes(__status)) {
                  const __forbidden = [
                    __cfg.grand_total_field,
                    __cfg.paid_total_field,
                    __cfg.outstanding_field,
                  ];
                  const __hasForbiddenPatch = __forbidden.some((k) => Object.prototype.hasOwnProperty.call(data, k));
                  if (__hasForbiddenPatch) {
                    throw new Error('Paid or cancelled invoices cannot be financially modified');
                  }
                }
              }
            }
      }

    
    const result = await this.repository.update(this.slug, id, data);
    
    // @HOOK: AFTER_UPDATE_LOGGING

    return result;
  }

  async delete(id) {
    // @HOOK: BEFORE_DELETE_VALIDATION
    
      // Delete protection (generated): prevent deleting a record that is referenced by others
      const dependents = [];

      {
        const rows = await this.repository.findAll('invoice_items');
        const matches = rows.filter((row) => String(row['invoice_id'] ?? '') === String(id));
        if (matches.length) {
          dependents.push({
            entity: 'invoice_items',
            via: ['invoice_id'],
            count: matches.length,
            preview: matches.slice(0, 10).map((r) => ({ id: r.id, display: r['description'] || r.id })),
          });
        }
      }

      {
        const rows = await this.repository.findAll('invoice_payments');
        const matches = rows.filter((row) => String(row['invoice_id'] ?? '') === String(id));
        if (matches.length) {
          dependents.push({
            entity: 'invoice_payments',
            via: ['invoice_id'],
            count: matches.length,
            preview: matches.slice(0, 10).map((r) => ({ id: r.id, display: r['payment_number'] || r.id })),
          });
        }
      }

      {
        const rows = await this.repository.findAll('invoice_payment_allocations');
        const matches = rows.filter((row) => String(row['invoice_id'] ?? '') === String(id));
        if (matches.length) {
          dependents.push({
            entity: 'invoice_payment_allocations',
            via: ['invoice_id'],
            count: matches.length,
            preview: matches.slice(0, 10).map((r) => ({ id: r.id, display: r['payment_id'] || r.id })),
          });
        }
      }

      {
        const rows = await this.repository.findAll('invoice_notes');
        const matches = rows.filter((row) => String(row['source_invoice_id'] ?? '') === String(id));
        if (matches.length) {
          dependents.push({
            entity: 'invoice_notes',
            via: ['source_invoice_id'],
            count: matches.length,
            preview: matches.slice(0, 10).map((r) => ({ id: r.id, display: r['note_number'] || r.id })),
          });
        }
      }

      {
        const rows = await this.repository.findAll('recurring_invoice_schedules');
        const matches = rows.filter((row) => String(row['template_invoice_id'] ?? '') === String(id));
        if (matches.length) {
          dependents.push({
            entity: 'recurring_invoice_schedules',
            via: ['template_invoice_id'],
            count: matches.length,
            preview: matches.slice(0, 10).map((r) => ({ id: r.id, display: r['customer_id'] || r.id })),
          });
        }
      }

      if (dependents.length) {
        const err = new Error('Cannot delete: this record is referenced by other records');
        err.statusCode = 409;
        err.dependents = dependents;
        throw err;
      }


    const result = await this.repository.delete(this.slug, id);
    
    // @HOOK: AFTER_DELETE_LOGGING

    return result;
  }

  async findById(id) {
    return this.repository.findById(this.slug, id);
  }

  async findAll(filter = {}) {
    return this.repository.findAll(this.slug, filter);
  }

  // @HOOK: ADDITIONAL_METHODS
    
  _invNoteCfg() {
    const cfg =
      this.mixinConfig?.invoice_note_workflow ||
      this.mixinConfig?.invoiceNoteWorkflow ||
      this.mixinConfig?.invoice_notes ||
      this.mixinConfig?.invoiceNotes ||
      {};
    return {
      invoice_entity: cfg.invoice_entity || cfg.invoiceEntity || 'invoices',
      note_entity: cfg.note_entity || cfg.noteEntity || 'invoice_notes',
      invoice_status_field: cfg.invoice_status_field || cfg.invoiceStatusField || 'status',
      invoice_grand_total_field: cfg.invoice_grand_total_field || cfg.invoiceGrandTotalField || 'grand_total',
      invoice_paid_total_field: cfg.invoice_paid_total_field || cfg.invoicePaidTotalField || 'paid_total',
      invoice_outstanding_field: cfg.invoice_outstanding_field || cfg.invoiceOutstandingField || 'outstanding_balance',
      note_number_field: cfg.note_number_field || cfg.noteNumberField || 'note_number',
      note_invoice_field: cfg.note_invoice_field || cfg.noteInvoiceField || 'source_invoice_id',
      note_type_field: cfg.note_type_field || cfg.noteTypeField || 'note_type',
      note_status_field: cfg.note_status_field || cfg.noteStatusField || 'status',
      note_amount_field: cfg.note_amount_field || cfg.noteAmountField || 'amount',
      note_tax_total_field: cfg.note_tax_total_field || cfg.noteTaxTotalField || 'tax_total',
      note_grand_total_field: cfg.note_grand_total_field || cfg.noteGrandTotalField || 'grand_total',
      note_posted_at_field: cfg.note_posted_at_field || cfg.notePostedAtField || 'posted_at',
      note_number_credit_prefix: cfg.note_number_credit_prefix || cfg.noteNumberCreditPrefix || 'CN-',
      note_number_debit_prefix: cfg.note_number_debit_prefix || cfg.noteNumberDebitPrefix || 'DN-',
      note_number_padding: Number(cfg.note_number_padding || cfg.noteNumberPadding || 6) || 6,
    };
  }

  _invNoteErr(message, statusCode = 400, details = null) {
    const err = new Error(message);
    err.statusCode = statusCode;
    if (details) err.details = details;
    return err;
  }

  _invNoteRound(rawValue) {
    const num = Number(rawValue);
    if (!Number.isFinite(num)) return 0;
    return Number(num.toFixed(2));
  }

  _invNoteType(rawType) {
    const type = String(rawType || '').toLowerCase();
    if (type === 'credit') return 'Credit';
    if (type === 'debit') return 'Debit';
    throw this._invNoteErr('note_type must be Credit or Debit', 400);
  }

  async _invNoteAllocateNumber(client, cfg, noteType) {
    const prefix = noteType === 'Credit' ? cfg.note_number_credit_prefix : cfg.note_number_debit_prefix;
    if (this.repository && typeof this.repository.allocatePrefixedNumber === 'function') {
      return this.repository.allocatePrefixedNumber(
        cfg.note_entity,
        cfg.note_number_field,
        prefix,
        { padding: cfg.note_number_padding },
        client
      );
    }
    const rows = await this.repository.findAllWithClient(cfg.note_entity, {}, client);
    let max = 0;
    for (const row of rows || []) {
      const raw = String(row && row[cfg.note_number_field] ? row[cfg.note_number_field] : '');
      if (!raw.startsWith(prefix)) continue;
      const parsed = parseInt(raw.slice(prefix.length), 10);
      if (!Number.isNaN(parsed)) max = Math.max(max, parsed);
    }
    return prefix + String(max + 1).padStart(cfg.note_number_padding, '0');
  }

  async _invNoteApplyInvoiceImpact(client, cfg, note, direction) {
    const invoiceId = note[cfg.note_invoice_field];
    const invoice = await this.repository.findByIdForUpdate(cfg.invoice_entity, invoiceId, client);
    if (!invoice) throw this._invNoteErr('Source invoice not found', 404);

    const type = this._invNoteType(note[cfg.note_type_field]);
    const noteGrand = this._invNoteRound(
      note[cfg.note_grand_total_field] !== undefined
        ? note[cfg.note_grand_total_field]
        : (this._invNoteRound(note[cfg.note_amount_field]) + this._invNoteRound(note[cfg.note_tax_total_field]))
    );
    if (noteGrand <= 0) {
      throw this._invNoteErr('Note grand total must be greater than zero', 400);
    }

    const signByType = type === 'Credit' ? -1 : 1;
    const signedDelta = noteGrand * signByType * direction;

    const currentGrand = this._invNoteRound(invoice[cfg.invoice_grand_total_field] || 0);
    const currentPaid = this._invNoteRound(invoice[cfg.invoice_paid_total_field] || 0);
    let nextGrand = this._invNoteRound(currentGrand + signedDelta);
    if (nextGrand < 0) {
      throw this._invNoteErr('Credit note exceeds invoice grand total', 409, {
        invoice_id: invoiceId,
        current_grand_total: currentGrand,
        note_impact: signedDelta,
      });
    }
    if (currentPaid > nextGrand + 0.0001) {
      throw this._invNoteErr('Invoice paid total cannot exceed adjusted grand total', 409, {
        invoice_id: invoiceId,
        paid_total: currentPaid,
        adjusted_grand_total: nextGrand,
      });
    }

    const outstanding = this._invNoteRound(Math.max(nextGrand - currentPaid, 0));
    let status = String(invoice[cfg.invoice_status_field] || 'Draft');
    if (status !== 'Cancelled') {
      if (outstanding <= 0) status = 'Paid';
      else if (status === 'Paid') status = 'Sent';
      else if (status === 'Draft') status = 'Sent';
    }

    return this.repository.updateWithClient(cfg.invoice_entity, invoiceId, {
      [cfg.invoice_grand_total_field]: nextGrand,
      [cfg.invoice_outstanding_field]: outstanding,
      [cfg.invoice_status_field]: status,
    }, client);
  }

  async listInvoiceNotes(invoiceId, filter = {}) {
    const cfg = this._invNoteCfg();
    if (this.slug !== cfg.invoice_entity) {
      throw this._invNoteErr(
        `Invoice note listing can only run on '${cfg.invoice_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }
    const where = {
      [cfg.note_invoice_field]: invoiceId,
    };
    if (filter && Object.prototype.hasOwnProperty.call(filter, cfg.note_status_field)) {
      where[cfg.note_status_field] = filter[cfg.note_status_field];
    } else if (filter && Object.prototype.hasOwnProperty.call(filter, 'status')) {
      where[cfg.note_status_field] = filter.status;
    }
    return this.repository.findAll(cfg.note_entity, where);
  }

  async createInvoiceNote(invoiceId, payload = {}) {
    const cfg = this._invNoteCfg();
    if (this.slug !== cfg.invoice_entity) {
      throw this._invNoteErr(
        `Invoice note create can only run on '${cfg.invoice_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    const amount = this._invNoteRound(payload[cfg.note_amount_field] ?? payload.amount);
    if (!Number.isFinite(amount) || amount <= 0) {
      throw this._invNoteErr(`${cfg.note_amount_field} must be greater than zero`, 400);
    }
    const taxTotal = this._invNoteRound(payload[cfg.note_tax_total_field] ?? payload.tax_total ?? 0);
    if (taxTotal < 0) {
      throw this._invNoteErr(`${cfg.note_tax_total_field} cannot be negative`, 400);
    }
    const type = this._invNoteType(payload[cfg.note_type_field] ?? payload.note_type);
    const grandTotal = this._invNoteRound(
      payload[cfg.note_grand_total_field] !== undefined
        ? payload[cfg.note_grand_total_field]
        : amount + taxTotal
    );

    return this.repository.withTransaction(async (client) => {
      const sourceInvoice = await this.repository.findByIdForUpdate(cfg.invoice_entity, invoiceId, client);
      if (!sourceInvoice) throw this._invNoteErr('Source invoice not found', 404);

      const noteNumber =
        payload[cfg.note_number_field] ||
        payload.note_number ||
        payload.noteNumber ||
        await this._invNoteAllocateNumber(client, cfg, type);

      const record = {
        [cfg.note_number_field]: noteNumber,
        [cfg.note_invoice_field]: invoiceId,
        [cfg.note_type_field]: type,
        [cfg.note_status_field]: 'Draft',
        issue_date: payload.issue_date || payload.issueDate || new Date().toISOString().slice(0, 10),
        [cfg.note_amount_field]: amount,
        [cfg.note_tax_total_field]: taxTotal,
        [cfg.note_grand_total_field]: grandTotal,
      };
      if (payload.reason) record.reason = payload.reason;
      if (payload.note) record.note = payload.note;

      const note = await this.repository.createWithClient(cfg.note_entity, record, client);
      return {
        note,
        invoice: sourceInvoice,
      };
    });
  }

  async postInvoiceNote(noteId, payload = {}) {
    const cfg = this._invNoteCfg();
    if (this.slug !== cfg.note_entity) {
      throw this._invNoteErr(
        `Invoice note post can only run on '${cfg.note_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    return this.repository.withTransaction(async (client) => {
      const note = await this.repository.findByIdForUpdate(cfg.note_entity, noteId, client);
      if (!note) throw this._invNoteErr('Invoice note not found', 404);
      const status = String(note[cfg.note_status_field] || 'Draft');
      if (status === 'Cancelled') {
        throw this._invNoteErr('Cancelled note cannot be posted', 409);
      }
      if (status !== 'Posted') {
        await this._invNoteApplyInvoiceImpact(client, cfg, note, 1);
      }

      const updatedNote = await this.repository.updateWithClient(cfg.note_entity, noteId, {
        [cfg.note_status_field]: 'Posted',
        [cfg.note_posted_at_field]: note[cfg.note_posted_at_field] || new Date().toISOString(),
        post_reference: payload.post_reference || payload.postReference || null,
      }, client);
      return {
        note: updatedNote,
      };
    });
  }

  async cancelInvoiceNote(noteId, payload = {}) {
    const cfg = this._invNoteCfg();
    if (this.slug !== cfg.note_entity) {
      throw this._invNoteErr(
        `Invoice note cancel can only run on '${cfg.note_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    return this.repository.withTransaction(async (client) => {
      const note = await this.repository.findByIdForUpdate(cfg.note_entity, noteId, client);
      if (!note) throw this._invNoteErr('Invoice note not found', 404);
      const status = String(note[cfg.note_status_field] || 'Draft');
      if (status === 'Cancelled') {
        throw this._invNoteErr('Invoice note is already cancelled', 409);
      }

      if (status === 'Posted') {
        await this._invNoteApplyInvoiceImpact(client, cfg, note, -1);
      }

      const updatedNote = await this.repository.updateWithClient(cfg.note_entity, noteId, {
        [cfg.note_status_field]: 'Cancelled',
        cancelled_at: new Date().toISOString(),
        cancel_reason: payload.reason || payload.cancel_reason || payload.cancelReason || null,
      }, client);
      return {
        note: updatedNote,
      };
    });
  }
    
    
  _invPayCfg() {
    const cfg =
      this.mixinConfig?.invoice_payment_workflow ||
      this.mixinConfig?.invoicePaymentWorkflow ||
      this.mixinConfig?.invoice_payments ||
      this.mixinConfig?.invoicePayments ||
      {};
    const invoiceTxn =
      this.mixinConfig?.invoice_transaction_safety ||
      this.mixinConfig?.invoiceTransactionSafety ||
      {};
    return {
      invoice_entity: cfg.invoice_entity || cfg.invoiceEntity || invoiceTxn.invoice_entity || invoiceTxn.invoiceEntity || 'invoices',
      payment_entity: cfg.payment_entity || cfg.paymentEntity || 'invoice_payments',
      allocation_entity: cfg.allocation_entity || cfg.allocationEntity || 'invoice_payment_allocations',
      invoice_status_field: cfg.invoice_status_field || cfg.invoiceStatusField || 'status',
      invoice_grand_total_field: cfg.invoice_grand_total_field || cfg.invoiceGrandTotalField || 'grand_total',
      invoice_paid_total_field: cfg.invoice_paid_total_field || cfg.invoicePaidTotalField || 'paid_total',
      invoice_outstanding_field: cfg.invoice_outstanding_field || cfg.invoiceOutstandingField || 'outstanding_balance',
      payment_number_field: cfg.payment_number_field || cfg.paymentNumberField || 'payment_number',
      payment_customer_field: cfg.payment_customer_field || cfg.paymentCustomerField || 'customer_id',
      payment_date_field: cfg.payment_date_field || cfg.paymentDateField || 'payment_date',
      payment_method_field: cfg.payment_method_field || cfg.paymentMethodField || 'payment_method',
      payment_amount_field: cfg.payment_amount_field || cfg.paymentAmountField || 'amount',
      payment_unallocated_field: cfg.payment_unallocated_field || cfg.paymentUnallocatedField || 'unallocated_amount',
      payment_status_field: cfg.payment_status_field || cfg.paymentStatusField || 'status',
      allocation_payment_field: cfg.allocation_payment_field || cfg.allocationPaymentField || 'payment_id',
      allocation_invoice_field: cfg.allocation_invoice_field || cfg.allocationInvoiceField || 'invoice_id',
      allocation_amount_field: cfg.allocation_amount_field || cfg.allocationAmountField || 'amount',
      allocation_date_field: cfg.allocation_date_field || cfg.allocationDateField || 'allocated_at',
      payment_number_prefix: cfg.payment_number_prefix || cfg.paymentNumberPrefix || 'PAY-',
      payment_number_padding: Number(cfg.payment_number_padding || cfg.paymentNumberPadding || 6) || 6,
    };
  }

  _invPayErr(message, statusCode = 400, details = null) {
    const err = new Error(message);
    err.statusCode = statusCode;
    if (details) err.details = details;
    return err;
  }

  _invPayRound(rawValue) {
    const num = Number(rawValue);
    if (!Number.isFinite(num)) return 0;
    return Number(num.toFixed(2));
  }

  _invPayPositive(rawValue, fieldName = 'amount') {
    const value = this._invPayRound(rawValue);
    if (!Number.isFinite(value) || value <= 0) {
      throw this._invPayErr(`${fieldName} must be greater than zero`, 400);
    }
    return value;
  }

  async _invPayApplyInvoiceDelta(client, cfg, invoiceId, paidDelta) {
    if (this.repository && typeof this.repository.atomicAdjustInvoiceFinancials === 'function') {
      return this.repository.atomicAdjustInvoiceFinancials(
        cfg.invoice_entity,
        invoiceId,
        {
          grandTotalField: cfg.invoice_grand_total_field,
          paidField: cfg.invoice_paid_total_field,
          outstandingField: cfg.invoice_outstanding_field,
          statusField: cfg.invoice_status_field,
          paidDelta,
          grandDelta: 0,
          autoStatus: true,
        },
        client
      );
    }

    const invoice = await this.repository.findByIdForUpdate(cfg.invoice_entity, invoiceId, client);
    if (!invoice) throw this._invPayErr('Invoice not found for allocation', 404);

    const grandTotal = this._invPayRound(invoice[cfg.invoice_grand_total_field] || 0);
    const currentPaid = this._invPayRound(invoice[cfg.invoice_paid_total_field] || 0);
    const nextPaid = this._invPayRound(currentPaid + paidDelta);
    if (nextPaid < 0) {
      throw this._invPayErr('Invoice paid total cannot go negative', 409, {
        invoice_id: invoiceId,
        current_paid: currentPaid,
        delta: paidDelta,
      });
    }
    if (nextPaid - grandTotal > 0.0001) {
      throw this._invPayErr('Payment allocation exceeds invoice grand total', 409, {
        invoice_id: invoiceId,
        grand_total: grandTotal,
        next_paid: nextPaid,
      });
    }

    const outstanding = this._invPayRound(Math.max(grandTotal - nextPaid, 0));
    let status = String(invoice[cfg.invoice_status_field] || 'Draft');
    if (status !== 'Cancelled') {
      if (outstanding <= 0) status = 'Paid';
      else if (status === 'Paid') status = 'Sent';
      else if (status === 'Draft') status = 'Sent';
    }

    return this.repository.updateWithClient(cfg.invoice_entity, invoiceId, {
      [cfg.invoice_paid_total_field]: nextPaid,
      [cfg.invoice_outstanding_field]: outstanding,
      [cfg.invoice_status_field]: status,
    }, client);
  }

  async _invPayAllocateNumber(client, cfg) {
    if (this.repository && typeof this.repository.allocatePrefixedNumber === 'function') {
      return this.repository.allocatePrefixedNumber(
        cfg.payment_entity,
        cfg.payment_number_field,
        cfg.payment_number_prefix,
        { padding: cfg.payment_number_padding },
        client
      );
    }
    const rows = await this.repository.findAllWithClient(cfg.payment_entity, {}, client);
    let max = 0;
    for (const row of rows || []) {
      const raw = String(row && row[cfg.payment_number_field] ? row[cfg.payment_number_field] : '');
      if (!raw.startsWith(cfg.payment_number_prefix)) continue;
      const parsed = parseInt(raw.slice(cfg.payment_number_prefix.length), 10);
      if (!Number.isNaN(parsed)) max = Math.max(max, parsed);
    }
    return cfg.payment_number_prefix + String(max + 1).padStart(cfg.payment_number_padding, '0');
  }

  async listInvoicePayments(invoiceId, filter = {}) {
    const cfg = this._invPayCfg();
    if (this.slug !== cfg.invoice_entity) {
      throw this._invPayErr(
        `Invoice payment listing can only run on '${cfg.invoice_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    const allocations = await this.repository.findAll(cfg.allocation_entity, {
      [cfg.allocation_invoice_field]: invoiceId,
    });
    const paymentIds = Array.from(new Set((allocations || []).map((row) => row && row[cfg.allocation_payment_field]).filter(Boolean)));
    const payments = paymentIds.length
      ? await this.repository.findAll(cfg.payment_entity, { id: paymentIds })
      : [];
    const byPaymentId = new Map((payments || []).map((row) => [String(row.id), row]));

    const withFilter = Array.isArray(allocations) ? allocations.filter((row) => {
      if (!filter || typeof filter !== 'object') return true;
      if (Object.prototype.hasOwnProperty.call(filter, 'status')) {
        const payment = byPaymentId.get(String(row[cfg.allocation_payment_field]));
        const status = String((payment && payment[cfg.payment_status_field]) || '');
        return status.toLowerCase() === String(filter.status || '').toLowerCase();
      }
      return true;
    }) : [];

    return withFilter.map((row) => ({
      allocation: row,
      payment: byPaymentId.get(String(row[cfg.allocation_payment_field])) || null,
    }));
  }

  async recordInvoicePayment(invoiceId, payload = {}) {
    const cfg = this._invPayCfg();
    if (this.slug !== cfg.invoice_entity) {
      throw this._invPayErr(
        `Invoice payment record can only run on '${cfg.invoice_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    const amount = this._invPayPositive(
      payload.amount ?? payload[cfg.payment_amount_field],
      cfg.payment_amount_field
    );

    return this.repository.withTransaction(async (client) => {
      const invoice = await this.repository.findByIdForUpdate(cfg.invoice_entity, invoiceId, client);
      if (!invoice) throw this._invPayErr('Invoice not found', 404);

      const outstanding = this._invPayRound(invoice[cfg.invoice_outstanding_field] || 0);
      const allocAmount = this._invPayRound(Math.min(amount, outstanding));
      const unallocated = this._invPayRound(Math.max(amount - allocAmount, 0));

      const paymentNumber = payload[cfg.payment_number_field] || payload.payment_number || payload.paymentNumber || await this._invPayAllocateNumber(client, cfg);
      const paymentPayload = {
        [cfg.payment_number_field]: paymentNumber,
        [cfg.payment_customer_field]:
          payload[cfg.payment_customer_field] ||
          payload.customer_id ||
          payload.customerId ||
          invoice.customer_id ||
          null,
        [cfg.payment_date_field]:
          payload[cfg.payment_date_field] ||
          payload.payment_date ||
          payload.paymentDate ||
          new Date().toISOString().slice(0, 10),
        [cfg.payment_method_field]:
          payload[cfg.payment_method_field] ||
          payload.payment_method ||
          payload.paymentMethod ||
          null,
        [cfg.payment_amount_field]: amount,
        [cfg.payment_unallocated_field]: unallocated,
        [cfg.payment_status_field]: 'Posted',
        posted_at: new Date().toISOString(),
      };
      if (payload.reference_number) paymentPayload.reference_number = payload.reference_number;
      if (payload.note) paymentPayload.note = payload.note;

      const payment = await this.repository.createWithClient(cfg.payment_entity, paymentPayload, client);
      let allocation = null;
      let updatedInvoice = invoice;

      if (allocAmount > 0) {
        allocation = await this.repository.createWithClient(
          cfg.allocation_entity,
          {
            [cfg.allocation_payment_field]: payment.id,
            [cfg.allocation_invoice_field]: invoiceId,
            [cfg.allocation_amount_field]: allocAmount,
            [cfg.allocation_date_field]: new Date().toISOString(),
          },
          client
        );
        updatedInvoice = await this._invPayApplyInvoiceDelta(client, cfg, invoiceId, allocAmount);
      }

      return {
        payment,
        allocation,
        invoice: updatedInvoice,
      };
    });
  }

  async postPayment(paymentId, payload = {}) {
    const cfg = this._invPayCfg();
    if (this.slug !== cfg.payment_entity) {
      throw this._invPayErr(
        `Payment posting can only run on '${cfg.payment_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    return this.repository.withTransaction(async (client) => {
      const payment = await this.repository.findByIdForUpdate(cfg.payment_entity, paymentId, client);
      if (!payment) throw this._invPayErr('Payment not found', 404);
      const currentStatus = String(payment[cfg.payment_status_field] || 'Draft');
      if (currentStatus === 'Cancelled') {
        throw this._invPayErr('Cancelled payment cannot be posted', 409);
      }

      const allocations = await this.repository.findAllWithClient(cfg.allocation_entity, {
        [cfg.allocation_payment_field]: paymentId,
      }, client);
      if (!Array.isArray(allocations) || allocations.length === 0) {
        const invoiceId = payload.invoice_id || payload.invoiceId || payload[cfg.allocation_invoice_field];
        const requestedAmount = payload.amount ?? payload[cfg.allocation_amount_field];
        if (invoiceId && requestedAmount) {
          const allocAmount = this._invPayPositive(requestedAmount, cfg.allocation_amount_field);
          const created = await this.repository.createWithClient(
            cfg.allocation_entity,
            {
              [cfg.allocation_payment_field]: paymentId,
              [cfg.allocation_invoice_field]: invoiceId,
              [cfg.allocation_amount_field]: allocAmount,
              [cfg.allocation_date_field]: new Date().toISOString(),
            },
            client
          );
          allocations.push(created);
        }
      }

      let totalAllocated = 0;
      if (currentStatus !== 'Posted') {
        for (const allocation of allocations) {
          const invoiceId = allocation[cfg.allocation_invoice_field];
          const allocAmount = this._invPayRound(allocation[cfg.allocation_amount_field] || 0);
          if (allocAmount <= 0) continue;
          totalAllocated += allocAmount;
          await this._invPayApplyInvoiceDelta(client, cfg, invoiceId, allocAmount);
        }
      } else {
        totalAllocated = allocations.reduce((sum, row) => sum + this._invPayRound(row[cfg.allocation_amount_field] || 0), 0);
      }

      const paymentAmount = this._invPayRound(payment[cfg.payment_amount_field] || 0);
      const nextUnallocated = this._invPayRound(Math.max(paymentAmount - totalAllocated, 0));
      const updated = await this.repository.updateWithClient(cfg.payment_entity, paymentId, {
        [cfg.payment_status_field]: 'Posted',
        [cfg.payment_unallocated_field]: nextUnallocated,
        posted_at: payment.posted_at || new Date().toISOString(),
      }, client);

      return {
        payment: updated,
        allocations,
      };
    });
  }

  async cancelPayment(paymentId, payload = {}) {
    const cfg = this._invPayCfg();
    if (this.slug !== cfg.payment_entity) {
      throw this._invPayErr(
        `Payment cancel can only run on '${cfg.payment_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    return this.repository.withTransaction(async (client) => {
      const payment = await this.repository.findByIdForUpdate(cfg.payment_entity, paymentId, client);
      if (!payment) throw this._invPayErr('Payment not found', 404);

      const currentStatus = String(payment[cfg.payment_status_field] || 'Draft');
      if (currentStatus === 'Cancelled') {
        throw this._invPayErr('Payment is already cancelled', 409);
      }

      const allocations = await this.repository.findAllWithClient(cfg.allocation_entity, {
        [cfg.allocation_payment_field]: paymentId,
      }, client);
      if (currentStatus === 'Posted') {
        for (const allocation of allocations || []) {
          const invoiceId = allocation[cfg.allocation_invoice_field];
          const allocAmount = this._invPayRound(allocation[cfg.allocation_amount_field] || 0);
          if (allocAmount <= 0) continue;
          await this._invPayApplyInvoiceDelta(client, cfg, invoiceId, -allocAmount);
        }
      }

      const updated = await this.repository.updateWithClient(cfg.payment_entity, paymentId, {
        [cfg.payment_status_field]: 'Cancelled',
        cancelled_at: new Date().toISOString(),
        cancel_reason: payload.reason || payload.cancel_reason || payload.cancelReason || null,
      }, client);
      return {
        payment: updated,
        allocations: allocations || [],
      };
    });
  }
    
    
  _invTxnCfg() {
    const cfg =
      this.mixinConfig?.invoice_transaction_safety ||
      this.mixinConfig?.invoiceTransactionSafety ||
      this.mixinConfig?.invoice_transactions ||
      this.mixinConfig?.invoiceTransactions ||
      {};
    const lifecycle =
      this.mixinConfig?.invoice_lifecycle ||
      this.mixinConfig?.invoiceLifecycle ||
      {};
    return {
      invoice_entity: cfg.invoice_entity || cfg.invoiceEntity || 'invoices',
      invoice_number_field: cfg.invoice_number_field || cfg.invoiceNumberField || 'invoice_number',
      status_field: cfg.status_field || cfg.statusField || lifecycle.status_field || lifecycle.statusField || 'status',
      grand_total_field: cfg.grand_total_field || cfg.grandTotalField || 'grand_total',
      paid_total_field: cfg.paid_total_field || cfg.paidTotalField || 'paid_total',
      outstanding_field: cfg.outstanding_field || cfg.outstandingField || 'outstanding_balance',
      idempotency_field: cfg.idempotency_field || cfg.idempotencyField || 'idempotency_key',
      posted_at_field: cfg.posted_at_field || cfg.postedAtField || 'posted_at',
      cancelled_at_field: cfg.cancelled_at_field || cfg.cancelledAtField || 'cancelled_at',
      number_prefix: cfg.number_prefix || cfg.numberPrefix || 'INV-',
      number_padding: Number(cfg.number_padding || cfg.numberPadding || 6) || 6,
      issue_status: cfg.issue_status || cfg.issueStatus || 'Sent',
      cancelled_status: cfg.cancelled_status || cfg.cancelledStatus || 'Cancelled',
      transitions:
        lifecycle.transitions && typeof lifecycle.transitions === 'object'
          ? lifecycle.transitions
          : {
              Draft: ['Sent', 'Cancelled'],
              Sent: ['Paid', 'Overdue', 'Cancelled'],
              Overdue: ['Paid', 'Cancelled'],
              Paid: [],
              Cancelled: [],
            },
      enforce_transitions:
        lifecycle.enforce_transitions !== false &&
        lifecycle.enforceTransitions !== false,
    };
  }

  _invTxnErr(message, statusCode = 400, details = null) {
    const err = new Error(message);
    err.statusCode = statusCode;
    if (details) err.details = details;
    return err;
  }

  _invTxnNowIso() {
    return new Date().toISOString();
  }

  _invTxnRound(rawValue) {
    const num = Number(rawValue);
    if (!Number.isFinite(num)) return 0;
    return Number(num.toFixed(2));
  }

  _invTxnAssertTransition(currentStatus, nextStatus, cfg) {
    if (!cfg.enforce_transitions) return;
    if (!currentStatus || !nextStatus || String(currentStatus) === String(nextStatus)) return;
    const map = cfg.transitions && typeof cfg.transitions === 'object' ? cfg.transitions : {};
    const allowed = Array.isArray(map[currentStatus]) ? map[currentStatus] : [];
    if (!allowed.includes(nextStatus)) {
      throw this._invTxnErr(`Invalid status transition: ${currentStatus} -> ${nextStatus}`, 409);
    }
  }

  async _invTxnAllocateNumber(cfg, client, invoice) {
    const current = invoice ? String(invoice[cfg.invoice_number_field] || '') : '';
    if (current && !current.startsWith('DRAFT-')) {
      return current;
    }

    if (this.repository && typeof this.repository.allocatePrefixedNumber === 'function') {
      return this.repository.allocatePrefixedNumber(
        cfg.invoice_entity,
        cfg.invoice_number_field,
        cfg.number_prefix,
        { padding: cfg.number_padding },
        client
      );
    }

    const rows = await this.repository.findAllWithClient(cfg.invoice_entity, {}, client);
    let max = 0;
    for (const row of rows || []) {
      const raw = String(row && row[cfg.invoice_number_field] ? row[cfg.invoice_number_field] : '');
      if (!raw.startsWith(cfg.number_prefix)) continue;
      const suffix = raw.slice(cfg.number_prefix.length);
      const parsed = parseInt(suffix, 10);
      if (!Number.isNaN(parsed)) {
        max = Math.max(max, parsed);
      }
    }
    const next = max + 1;
    return cfg.number_prefix + String(next).padStart(cfg.number_padding, '0');
  }

  async issueInvoice(invoiceId, payload = {}) {
    const cfg = this._invTxnCfg();
    if (this.slug !== cfg.invoice_entity) {
      throw this._invTxnErr(
        `Invoice issue workflow can only run on '${cfg.invoice_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    return this.repository.withTransaction(async (client) => {
      const invoice = await this.repository.findByIdForUpdate(this.slug, invoiceId, client);
      if (!invoice) throw this._invTxnErr('Invoice not found', 404);

      const currentStatus = String(invoice[cfg.status_field] || 'Draft');
      const nextStatus = String(payload.status || cfg.issue_status || 'Sent');
      this._invTxnAssertTransition(currentStatus, nextStatus, cfg);

      const invoiceNumber = await this._invTxnAllocateNumber(cfg, client, invoice);
      const grandTotal = this._invTxnRound(invoice[cfg.grand_total_field] || 0);
      const paidTotal = this._invTxnRound(invoice[cfg.paid_total_field] || 0);
      const outstanding = this._invTxnRound(Math.max(grandTotal - paidTotal, 0));

      const patch = {
        [cfg.invoice_number_field]: invoiceNumber,
        [cfg.status_field]: nextStatus,
        [cfg.posted_at_field]: this._invTxnNowIso(),
        [cfg.outstanding_field]: outstanding,
        [cfg.paid_total_field]: paidTotal,
      };
      if (cfg.idempotency_field && payload.idempotency_key) {
        patch[cfg.idempotency_field] = String(payload.idempotency_key);
      }

      const updated = await this.repository.updateWithClient(this.slug, invoiceId, patch, client);
      return {
        invoice: updated,
        operation: 'issue',
      };
    });
  }

  async cancelInvoice(invoiceId, payload = {}) {
    const cfg = this._invTxnCfg();
    if (this.slug !== cfg.invoice_entity) {
      throw this._invTxnErr(
        `Invoice cancel workflow can only run on '${cfg.invoice_entity}' service. Current entity: '${this.slug}'.`,
        400
      );
    }

    return this.repository.withTransaction(async (client) => {
      const invoice = await this.repository.findByIdForUpdate(this.slug, invoiceId, client);
      if (!invoice) throw this._invTxnErr('Invoice not found', 404);

      const currentStatus = String(invoice[cfg.status_field] || 'Draft');
      const nextStatus = String(payload.status || cfg.cancelled_status || 'Cancelled');
      this._invTxnAssertTransition(currentStatus, nextStatus, cfg);

      const patch = {
        [cfg.status_field]: nextStatus,
        [cfg.cancelled_at_field]: this._invTxnNowIso(),
      };
      const updated = await this.repository.updateWithClient(this.slug, invoiceId, patch, client);
      return {
        invoice: updated,
        operation: 'cancel',
      };
    });
  }
    
}

module.exports = InvoicesService;
