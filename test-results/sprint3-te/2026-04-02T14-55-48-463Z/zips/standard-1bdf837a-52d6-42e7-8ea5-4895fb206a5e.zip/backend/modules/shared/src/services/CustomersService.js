// brick-library/backend-bricks/core/BaseService.js.hbs
class CustomersService {
  constructor(repository, mixinConfig = {}) {
    this.repository = repository;
    this.slug = 'customers';
    this.mixinConfig = mixinConfig && typeof mixinConfig === 'object' ? mixinConfig : {};
  }

  async create(data) {
    // @HOOK: BEFORE_CREATE_VALIDATION
    
      // Schema-driven validation (generated)
      const fieldErrors = {};
      const isMissing = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
      const isMissingNonString = (v) => v === undefined || v === null;

      if (isMissing(data['name'])) fieldErrors['name'] = 'Name is required';

      if (isMissing(data['email'])) fieldErrors['email'] = 'Email is required';

      if (Object.keys(fieldErrors).length) {
        const err = new Error('Validation failed');
        err.statusCode = 400;
        err.fieldErrors = fieldErrors;
        throw err;
      }

    
    // @HOOK: BEFORE_CREATE_TRANSFORMATION
    
    const result = await this.repository.create(this.slug, data);
    
    // @HOOK: AFTER_CREATE_LOGGING
    
    return result;
  }

  async update(id, data) {
    // @HOOK: BEFORE_UPDATE_VALIDATION
    
      // Schema-driven validation (generated)
      const existing = await this.repository.findById(this.slug, id);
      if (!existing) return null;
      const merged = { ...existing, ...data };

      const fieldErrors = {};
      const isMissing = (v) => v === undefined || v === null || (typeof v === 'string' && v.trim() === '');
      const isMissingNonString = (v) => v === undefined || v === null;

      if (isMissing(merged['name'])) fieldErrors['name'] = 'Name is required';

      if (isMissing(merged['email'])) fieldErrors['email'] = 'Email is required';

      if (Object.keys(fieldErrors).length) {
        const err = new Error('Validation failed');
        err.statusCode = 400;
        err.fieldErrors = fieldErrors;
        throw err;
      }

    
    const result = await this.repository.update(this.slug, id, data);
    
    // @HOOK: AFTER_UPDATE_LOGGING

    return result;
  }

  async delete(id) {
    // @HOOK: BEFORE_DELETE_VALIDATION
    
      // Delete protection (generated): prevent deleting a record that is referenced by others
      const dependents = [];

      {
        const rows = await this.repository.findAll('invoices');
        const matches = rows.filter((row) => String(row['customer_id'] ?? '') === String(id));
        if (matches.length) {
          dependents.push({
            entity: 'invoices',
            via: ['customer_id'],
            count: matches.length,
            preview: matches.slice(0, 10).map((r) => ({ id: r.id, display: r['invoice_number'] || r.id })),
          });
        }
      }

      {
        const rows = await this.repository.findAll('invoice_payments');
        const matches = rows.filter((row) => String(row['customer_id'] ?? '') === String(id));
        if (matches.length) {
          dependents.push({
            entity: 'invoice_payments',
            via: ['customer_id'],
            count: matches.length,
            preview: matches.slice(0, 10).map((r) => ({ id: r.id, display: r['payment_number'] || r.id })),
          });
        }
      }

      {
        const rows = await this.repository.findAll('recurring_invoice_schedules');
        const matches = rows.filter((row) => String(row['customer_id'] ?? '') === String(id));
        if (matches.length) {
          dependents.push({
            entity: 'recurring_invoice_schedules',
            via: ['customer_id'],
            count: matches.length,
            preview: matches.slice(0, 10).map((r) => ({ id: r.id, display: r['customer_id'] || r.id })),
          });
        }
      }

      if (dependents.length) {
        const err = new Error('Cannot delete: this record is referenced by other records');
        err.statusCode = 409;
        err.dependents = dependents;
        throw err;
      }


    const result = await this.repository.delete(this.slug, id);
    
    // @HOOK: AFTER_DELETE_LOGGING

    return result;
  }

  async findById(id) {
    return this.repository.findById(this.slug, id);
  }

  async findAll(filter = {}) {
    return this.repository.findAll(this.slug, filter);
  }

  // @HOOK: ADDITIONAL_METHODS
}

module.exports = CustomersService;
