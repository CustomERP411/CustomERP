
const express = require('express');
const router = express.Router();

const productsRouter = require('../../modules/inventory/src/routes/productsRoutes');
const locationsRouter = require('../../modules/inventory/src/routes/locationsRoutes');
const stock_movementsRouter = require('../../modules/inventory/src/routes/stock_movementsRoutes');
const stock_reservationsRouter = require('../../modules/inventory/src/routes/stock_reservationsRoutes');
const purchase_ordersRouter = require('../../modules/inventory/src/routes/purchase_ordersRoutes');
const purchase_order_itemsRouter = require('../../modules/inventory/src/routes/purchase_order_itemsRoutes');
const goods_receiptsRouter = require('../../modules/inventory/src/routes/goods_receiptsRoutes');
const goods_receipt_itemsRouter = require('../../modules/inventory/src/routes/goods_receipt_itemsRoutes');
const cycle_count_sessionsRouter = require('../../modules/inventory/src/routes/cycle_count_sessionsRoutes');
const cycle_count_linesRouter = require('../../modules/inventory/src/routes/cycle_count_linesRoutes');
const customersRouter = require('../../modules/shared/src/routes/customersRoutes');
const invoicesRouter = require('../../modules/invoice/src/routes/invoicesRoutes');
const invoice_itemsRouter = require('../../modules/invoice/src/routes/invoice_itemsRoutes');
const invoice_paymentsRouter = require('../../modules/invoice/src/routes/invoice_paymentsRoutes');
const invoice_payment_allocationsRouter = require('../../modules/invoice/src/routes/invoice_payment_allocationsRoutes');
const invoice_notesRouter = require('../../modules/invoice/src/routes/invoice_notesRoutes');
const recurring_invoice_schedulesRouter = require('../../modules/invoice/src/routes/recurring_invoice_schedulesRoutes');
const departmentsRouter = require('../../modules/hr/src/routes/departmentsRoutes');
const employeesRouter = require('../../modules/hr/src/routes/employeesRoutes');
const leavesRouter = require('../../modules/hr/src/routes/leavesRoutes');
const leave_balancesRouter = require('../../modules/hr/src/routes/leave_balancesRoutes');
const attendance_entriesRouter = require('../../modules/hr/src/routes/attendance_entriesRoutes');
const shift_assignmentsRouter = require('../../modules/hr/src/routes/shift_assignmentsRoutes');
const timesheet_entriesRouter = require('../../modules/hr/src/routes/timesheet_entriesRoutes');
const compensation_ledgerRouter = require('../../modules/hr/src/routes/compensation_ledgerRoutes');
const compensation_snapshotsRouter = require('../../modules/hr/src/routes/compensation_snapshotsRoutes');


router.use('/products', productsRouter);
router.use('/locations', locationsRouter);
router.use('/stock_movements', stock_movementsRouter);
router.use('/stock_reservations', stock_reservationsRouter);
router.use('/purchase_orders', purchase_ordersRouter);
router.use('/purchase_order_items', purchase_order_itemsRouter);
router.use('/goods_receipts', goods_receiptsRouter);
router.use('/goods_receipt_items', goods_receipt_itemsRouter);
router.use('/cycle_count_sessions', cycle_count_sessionsRouter);
router.use('/cycle_count_lines', cycle_count_linesRouter);
router.use('/customers', customersRouter);
router.use('/invoices', invoicesRouter);
router.use('/invoice_items', invoice_itemsRouter);
router.use('/invoice_payments', invoice_paymentsRouter);
router.use('/invoice_payment_allocations', invoice_payment_allocationsRouter);
router.use('/invoice_notes', invoice_notesRouter);
router.use('/recurring_invoice_schedules', recurring_invoice_schedulesRouter);
router.use('/departments', departmentsRouter);
router.use('/employees', employeesRouter);
router.use('/leaves', leavesRouter);
router.use('/leave_balances', leave_balancesRouter);
router.use('/attendance_entries', attendance_entriesRouter);
router.use('/shift_assignments', shift_assignmentsRouter);
router.use('/timesheet_entries', timesheet_entriesRouter);
router.use('/compensation_ledger', compensation_ledgerRouter);
router.use('/compensation_snapshots', compensation_snapshotsRouter);


module.exports = router;
