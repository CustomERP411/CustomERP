module.exports = {
  "modules": {
    "inventory_priority_a": {
      "stock_entity": "products",
      "reservations": {
        "enabled": true,
        "reservation_entity": "stock_reservations",
        "item_field": "item_id",
        "quantity_field": "quantity",
        "status_field": "status"
      },
      "transactions": {
        "enabled": true,
        "quantity_field": "quantity"
      },
      "inbound": {
        "enabled": true,
        "purchase_order_entity": "purchase_orders",
        "purchase_order_item_entity": "purchase_order_items",
        "grn_entity": "goods_receipts",
        "grn_item_entity": "goods_receipt_items"
      },
      "cycle_counting": {
        "enabled": true,
        "session_entity": "cycle_count_sessions",
        "line_entity": "cycle_count_lines"
      }
    },
    "invoice_priority_a": {
      "invoice_entity": "invoices",
      "invoice_item_entity": "invoice_items",
      "transactions": {
        "enabled": true,
        "invoice_number_field": "invoice_number",
        "idempotency_field": "idempotency_key"
      },
      "payments": {
        "enabled": true,
        "payment_entity": "invoice_payments",
        "allocation_entity": "invoice_payment_allocations"
      },
      "notes": {
        "enabled": true,
        "note_entity": "invoice_notes"
      },
      "lifecycle": {
        "enabled": true,
        "status_field": "status",
        "statuses": [
          "Draft",
          "Sent",
          "Paid",
          "Overdue",
          "Cancelled"
        ]
      },
      "calculation_engine": {
        "enabled": true,
        "line_total_field": "line_total"
      }
    },
    "hr_priority_a": {
      "employee_entity": "employees",
      "leave_entity": "leaves",
      "leave_engine": {
        "enabled": true,
        "balance_entity": "leave_balances",
        "employee_field": "employee_id",
        "leave_type_field": "leave_type",
        "available_field": "available_days",
        "fiscal_year_field": "year"
      },
      "leave_approvals": {
        "enabled": true,
        "status_field": "status",
        "approver_field": "approver_id",
        "statuses": [
          "Pending",
          "Approved",
          "Rejected",
          "Cancelled"
        ]
      },
      "attendance_time": {
        "enabled": true,
        "attendance_entity": "attendance_entries",
        "shift_entity": "shift_assignments",
        "timesheet_entity": "timesheet_entries",
        "work_days": [
          "Mon"
        ],
        "daily_hours": 6
      },
      "compensation_ledger": {
        "enabled": true,
        "ledger_entity": "compensation_ledger",
        "snapshot_entity": "compensation_snapshots"
      }
    },
    "scheduled_reports": {
      "enabled": false,
      "cron": "0 0 * * *",
      "target_slug": "__reports",
      "report_type": "daily_summary",
      "entities": [],
      "low_stock": null,
      "expiry": null,
      "inventory_value": null,
      "movements": null,
      "entity_snapshots": []
    }
  }
};
