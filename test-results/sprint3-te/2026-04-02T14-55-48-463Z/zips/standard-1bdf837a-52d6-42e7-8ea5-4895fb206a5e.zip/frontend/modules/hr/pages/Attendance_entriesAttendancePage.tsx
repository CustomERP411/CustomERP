import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../../../src/services/api';
import { useToast } from '../../../src/components/ui/toast';

const ENTITY_SLUG = 'attendance_entries' as const;
const CFG = {
  "attendance_entity": "attendance_entries",
  "shift_entity": "shift_assignments",
  "timesheet_entity": "timesheet_entries",
  "attendance_employee_field": "employee_id",
  "attendance_date_field": "work_date",
  "check_in_field": "check_in_at",
  "check_out_field": "check_out_at",
  "worked_hours_field": "worked_hours",
  "attendance_status_field": "status",
  "enabled": true,
  "work_days": [
    "Mon"
  ],
  "daily_hours": 6,
  "employee_entity": "employees"
} as const;

const EMPLOYEE_ENTITY = CFG.employee_entity || 'employees';
const EMPLOYEE_FIELD = CFG.attendance_employee_field || 'employee_id';
const DATE_FIELD = CFG.attendance_date_field || 'work_date';
const CHECKIN_FIELD = CFG.check_in_field || 'check_in_at';
const CHECKOUT_FIELD = CFG.check_out_field || 'check_out_at';
const HOURS_FIELD = CFG.worked_hours_field || 'worked_hours';
const STATUS_FIELD = CFG.attendance_status_field || 'status';

export default function Attendance_entriesAttendancePage() {
  const { toast } = useToast();
  const [employees, setEmployees] = useState<any[]>([]);
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [workingId, setWorkingId] = useState('');
  const [form, setForm] = useState({
    employeeId: '',
    workDate: new Date().toISOString().slice(0, 10),
    checkInAt: '',
    checkOutAt: '',
    status: 'Present',
    note: '',
  });

  const fetchAll = async () => {
    const [empRes, attendanceRes] = await Promise.all([
      api.get('/' + EMPLOYEE_ENTITY),
      api.get('/' + ENTITY_SLUG),
    ]);
    const empRows = Array.isArray(empRes.data) ? empRes.data : [];
    const attendanceRows = Array.isArray(attendanceRes.data) ? attendanceRes.data : [];
    setEmployees(empRows);
    setRows(attendanceRows);
    if (!form.employeeId && empRows.length) {
      setForm((prev) => ({ ...prev, employeeId: String(empRows[0].id) }));
    }
  };

  useEffect(() => {
    (async () => {
      try {
        await fetchAll();
      } catch (error: any) {
        toast({ title: 'Failed to load attendance context', description: error?.response?.data?.error || error?.message || 'Unknown error', variant: 'error' });
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  const recordAttendance = async () => {
    if (!form.employeeId) {
      toast({ title: 'Select employee first', variant: 'warning' });
      return;
    }
    setWorkingId('record');
    try {
      await api.post('/' + ENTITY_SLUG + '/record', {
        [EMPLOYEE_FIELD]: form.employeeId,
        [DATE_FIELD]: form.workDate,
        [CHECKIN_FIELD]: form.checkInAt || undefined,
        [CHECKOUT_FIELD]: form.checkOutAt || undefined,
        [STATUS_FIELD]: form.status || undefined,
        note: form.note || undefined,
      });
      toast({ title: 'Attendance recorded', variant: 'success' });
      setForm((prev) => ({ ...prev, checkInAt: '', checkOutAt: '', note: '' }));
      await fetchAll();
    } catch (error: any) {
      toast({ title: 'Attendance record failed', description: error?.response?.data?.error || error?.message || 'Unknown error', variant: 'error' });
    } finally {
      setWorkingId('');
    }
  };

  const recalculate = async (id: string) => {
    if (!id) return;
    setWorkingId(id);
    try {
      await api.post('/' + ENTITY_SLUG + '/' + id + '/recalculate', {});
      toast({ title: 'Attendance recomputed', variant: 'success' });
      await fetchAll();
    } catch (error: any) {
      toast({ title: 'Recompute failed', description: error?.response?.data?.error || error?.message || 'Unknown error', variant: 'error' });
    } finally {
      setWorkingId('');
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Attendance Entries</h1>
          <p className="text-sm text-slate-600">Capture attendance and keep timesheets synced from worked hours.</p>
        </div>
        <Link to={'/' + ENTITY_SLUG} className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50">
          Back to Attendance_entries
        </Link>
      </div>

      <div className="rounded-lg border bg-white p-4 space-y-3">
        <h2 className="text-sm font-semibold text-slate-900">Record Attendance</h2>
        <div className="grid gap-3 md:grid-cols-3">
          <select value={form.employeeId} onChange={(e) => setForm((prev) => ({ ...prev, employeeId: e.target.value }))} className="rounded border px-3 py-2 text-sm">
            {!employees.length && <option value="">No employees</option>}
            {employees.map((emp) => (
              <option key={String(emp.id)} value={String(emp.id)}>
                {String(emp.first_name || '')} {String(emp.last_name || '')}
              </option>
            ))}
          </select>
          <input type="date" value={form.workDate} onChange={(e) => setForm((prev) => ({ ...prev, workDate: e.target.value }))} className="rounded border px-3 py-2 text-sm" />
          <select value={form.status} onChange={(e) => setForm((prev) => ({ ...prev, status: e.target.value }))} className="rounded border px-3 py-2 text-sm">
            <option value="Present">Present</option>
            <option value="Absent">Absent</option>
            <option value="Half Day">Half Day</option>
            <option value="On Leave">On Leave</option>
          </select>
          <input type="datetime-local" value={form.checkInAt} onChange={(e) => setForm((prev) => ({ ...prev, checkInAt: e.target.value }))} className="rounded border px-3 py-2 text-sm" />
          <input type="datetime-local" value={form.checkOutAt} onChange={(e) => setForm((prev) => ({ ...prev, checkOutAt: e.target.value }))} className="rounded border px-3 py-2 text-sm" />
          <input value={form.note} onChange={(e) => setForm((prev) => ({ ...prev, note: e.target.value }))} placeholder="Note (optional)" className="rounded border px-3 py-2 text-sm" />
        </div>
        <div className="flex justify-end">
          <button type="button" onClick={recordAttendance} disabled={workingId === 'record'} className="rounded-md bg-blue-600 px-3 py-2 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-50">
            Record
          </button>
        </div>
      </div>

      <div className="rounded-lg border bg-white p-4">
        <h2 className="mb-3 text-sm font-semibold text-slate-900">Recent Entries</h2>
        {loading ? (
          <div className="text-sm text-slate-500">Loading…</div>
        ) : rows.length === 0 ? (
          <div className="text-sm text-slate-500">No attendance entries found.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-slate-100 text-slate-700">
                <tr>
                  <th className="px-3 py-2 text-left">Employee</th>
                  <th className="px-3 py-2 text-left">Date</th>
                  <th className="px-3 py-2 text-left">Check In</th>
                  <th className="px-3 py-2 text-left">Check Out</th>
                  <th className="px-3 py-2 text-left">Worked Hours</th>
                  <th className="px-3 py-2 text-left">Status</th>
                  <th className="px-3 py-2 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {rows.map((row) => {
                  const id = String(row?.id || '');
                  return (
                    <tr key={id}>
                      <td className="px-3 py-2">{String(row?.[EMPLOYEE_FIELD] || '—')}</td>
                      <td className="px-3 py-2">{String(row?.[DATE_FIELD] || '—')}</td>
                      <td className="px-3 py-2">{String(row?.[CHECKIN_FIELD] || '—')}</td>
                      <td className="px-3 py-2">{String(row?.[CHECKOUT_FIELD] || '—')}</td>
                      <td className="px-3 py-2">{String(row?.[HOURS_FIELD] ?? 0)}</td>
                      <td className="px-3 py-2">{String(row?.[STATUS_FIELD] || '—')}</td>
                      <td className="px-3 py-2 text-right">
                        <button type="button" onClick={() => recalculate(id)} disabled={workingId === id} className="text-blue-600 hover:underline disabled:opacity-50">
                          Recalculate
                        </button>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
