import { Link, useNavigate } from 'react-router-dom';
import ImportCsvTool from '../../../src/components/tools/ImportCsvTool';

const fieldDefinitions = [
  { name: 'employee_id', label: 'Employee Id', type: 'reference', widget: 'EntitySelect', required: true, referenceEntity: 'employees' },
  { name: 'work_date', label: 'Work Date', type: 'date', widget: 'DatePicker', required: true },
  { name: 'check_in_at', label: 'Check In At', type: 'datetime', widget: 'DatePicker', required: false },
  { name: 'check_out_at', label: 'Check Out At', type: 'datetime', widget: 'DatePicker', required: false },
  { name: 'worked_hours', label: 'Worked Hours', type: 'decimal', widget: 'NumberInput', required: false },
  { name: 'status', label: 'Status', type: 'string', widget: 'RadioGroup', required: false, options: ['Present', 'Absent', 'Half Day', 'On Leave'] },
  { name: 'note', label: 'Note', type: 'text', widget: 'TextArea', required: false },
  { name: 'idempotency_key', label: 'Idempotency Key', type: 'string', widget: 'Input', required: false, unique: true },
];

export default function Attendance_entriesImportPage() {
  const navigate = useNavigate();
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Import CSV — Attendance Entries</h1>
          <p className="text-sm text-slate-600">Use the template and follow the rules.</p>
        </div>
        <Link to="/attendance_entries" className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50 no-print">
          Back
        </Link>
      </div>

      <div className="rounded-lg bg-white p-6 shadow">
        <ImportCsvTool
          entitySlug="attendance_entries"
          fields={fieldDefinitions as any}
          onCancel={() => navigate('/attendance_entries')}
          onDone={() => navigate('/attendance_entries')}
        />
      </div>
    </div>
  );
}
