import { Link, useNavigate } from 'react-router-dom';
import ImportCsvTool from '../../../src/components/tools/ImportCsvTool';

const fieldDefinitions = [
  { name: 'employee_id', label: 'Employee Id', type: 'reference', widget: 'EntitySelect', required: true, referenceEntity: 'employees' },
  { name: 'pay_period', label: 'Pay Period', type: 'string', widget: 'Input', required: true },
  { name: 'component', label: 'Component', type: 'string', widget: 'Input', required: true },
  { name: 'component_type', label: 'Component Type', type: 'string', widget: 'RadioGroup', required: true, options: ['Earning', 'Deduction'] },
  { name: 'amount', label: 'Amount', type: 'decimal', widget: 'NumberInput', required: true },
  { name: 'status', label: 'Status', type: 'string', widget: 'RadioGroup', required: false, options: ['Draft', 'Posted', 'Cancelled'] },
  { name: 'posted_at', label: 'Posted At', type: 'datetime', widget: 'DatePicker', required: false },
  { name: 'post_reference', label: 'Post Reference', type: 'string', widget: 'Input', required: false },
  { name: 'note', label: 'Note', type: 'text', widget: 'TextArea', required: false },
];

export default function Compensation_ledgerImportPage() {
  const navigate = useNavigate();
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Import CSV — Compensation Ledger</h1>
          <p className="text-sm text-slate-600">Use the template and follow the rules.</p>
        </div>
        <Link to="/compensation_ledger" className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50 no-print">
          Back
        </Link>
      </div>

      <div className="rounded-lg bg-white p-6 shadow">
        <ImportCsvTool
          entitySlug="compensation_ledger"
          fields={fieldDefinitions as any}
          onCancel={() => navigate('/compensation_ledger')}
          onDone={() => navigate('/compensation_ledger')}
        />
      </div>
    </div>
  );
}
