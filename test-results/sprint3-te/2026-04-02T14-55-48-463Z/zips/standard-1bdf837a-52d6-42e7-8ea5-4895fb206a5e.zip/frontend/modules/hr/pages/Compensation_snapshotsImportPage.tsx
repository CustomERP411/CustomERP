import { Link, useNavigate } from 'react-router-dom';
import ImportCsvTool from '../../../src/components/tools/ImportCsvTool';

const fieldDefinitions = [
  { name: 'employee_id', label: 'Employee Id', type: 'reference', widget: 'EntitySelect', required: true, referenceEntity: 'employees' },
  { name: 'pay_period', label: 'Pay Period', type: 'string', widget: 'Input', required: true },
  { name: 'gross_amount', label: 'Gross Amount', type: 'decimal', widget: 'NumberInput', required: false },
  { name: 'deduction_amount', label: 'Deduction Amount', type: 'decimal', widget: 'NumberInput', required: false },
  { name: 'net_amount', label: 'Net Amount', type: 'decimal', widget: 'NumberInput', required: false },
  { name: 'status', label: 'Status', type: 'string', widget: 'RadioGroup', required: false, options: ['Draft', 'Posted'] },
  { name: 'posted_at', label: 'Posted At', type: 'datetime', widget: 'DatePicker', required: false },
  { name: 'note', label: 'Note', type: 'text', widget: 'TextArea', required: false },
];

export default function Compensation_snapshotsImportPage() {
  const navigate = useNavigate();
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Import CSV — Compensation Snapshots</h1>
          <p className="text-sm text-slate-600">Use the template and follow the rules.</p>
        </div>
        <Link to="/compensation_snapshots" className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50 no-print">
          Back
        </Link>
      </div>

      <div className="rounded-lg bg-white p-6 shadow">
        <ImportCsvTool
          entitySlug="compensation_snapshots"
          fields={fieldDefinitions as any}
          onCancel={() => navigate('/compensation_snapshots')}
          onDone={() => navigate('/compensation_snapshots')}
        />
      </div>
    </div>
  );
}
