import { Link, useNavigate } from 'react-router-dom';
import ImportCsvTool from '../../../src/components/tools/ImportCsvTool';

const fieldDefinitions = [
  { name: 'name', label: 'Name', type: 'string', widget: 'Input', required: true, unique: true },
  { name: 'location', label: 'Location', type: 'string', widget: 'Input', required: false },
  { name: 'manager_id', label: 'Manager', type: 'reference', widget: 'EntitySelect', required: false, referenceEntity: 'employees' },
];

export default function DepartmentsImportPage() {
  const navigate = useNavigate();
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Import CSV — Departments</h1>
          <p className="text-sm text-slate-600">Use the template and follow the rules.</p>
        </div>
        <Link to="/departments" className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50 no-print">
          Back
        </Link>
      </div>

      <div className="rounded-lg bg-white p-6 shadow">
        <ImportCsvTool
          entitySlug="departments"
          fields={fieldDefinitions as any}
          onCancel={() => navigate('/departments')}
          onDone={() => navigate('/departments')}
        />
      </div>
    </div>
  );
}
