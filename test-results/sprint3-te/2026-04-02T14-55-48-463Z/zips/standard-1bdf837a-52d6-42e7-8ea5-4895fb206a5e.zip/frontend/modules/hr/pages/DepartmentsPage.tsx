import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../../../src/services/api';
import { useToast } from '../../../src/components/ui/toast';
import DepartmentCard from '../../../src/components/modules/hr/DepartmentCard';

export default function DepartmentsPage() {
  const { toast } = useToast();
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    let cancelled = false;
    const run = async () => {
      try {
        setLoading(true);
        const res = await api.get('/departments');
        if (!cancelled) {
          setItems(Array.isArray(res.data) ? res.data : []);
        }
      } catch (e) {
        if (!cancelled) toast({ title: 'Failed to load departments', variant: 'error' });
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    run();
    return () => { cancelled = true; };
  }, []);

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Departments</h1>
          <p className="text-sm text-slate-600">Manage organizational departments.</p>
        </div>
        <Link to="/departments/new" className="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-700">
          New Department
        </Link>
      </div>

      {loading ? (
        <div className="p-4">Loading…</div>
      ) : items.length === 0 ? (
        <div className="rounded-lg border border-dashed bg-white p-10 text-center text-sm text-slate-500">
          No departments yet. Create your first department to get started.
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {items.map((dept) => (
            <DepartmentCard
              key={String(dept.id)}
              department={dept}
              to={'/departments/' + dept.id + '/edit'}
            />
          ))}
        </div>
      )}
    </div>
  );
}
