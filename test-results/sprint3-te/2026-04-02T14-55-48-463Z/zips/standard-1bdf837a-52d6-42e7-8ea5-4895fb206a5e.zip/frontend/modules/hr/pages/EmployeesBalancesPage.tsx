import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../../../src/services/api';
import { useToast } from '../../../src/components/ui/toast';

const EMPLOYEE_SLUG = 'employees' as const;
const CFG = {
  "leave_entity": "leaves",
  "balance_entity": "leave_balances",
  "employee_field": "employee_id",
  "leave_type_field": "leave_type",
  "start_date_field": "start_date",
  "end_date_field": "end_date",
  "days_field": "leave_days",
  "status_field": "status",
  "available_field": "available_days",
  "fiscal_year_field": "year",
  "enabled": true,
  "work_days": [
    "Mon"
  ],
  "daily_hours": 6,
  "consume_on_approval": true
} as const;

const LEAVE_TYPE_FIELD = CFG.leave_type_field || 'leave_type';
const YEAR_FIELD = CFG.fiscal_year_field || 'year';
const AVAILABLE_FIELD = CFG.available_field || 'available_days';
const ACCRUED_FIELD = CFG.accrued_field || 'accrued_days';
const CONSUMED_FIELD = CFG.consumed_field || 'consumed_days';

export default function EmployeesBalancesPage() {
  const { toast } = useToast();
  const [employees, setEmployees] = useState<any[]>([]);
  const [selectedId, setSelectedId] = useState('');
  const [balances, setBalances] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [working, setWorking] = useState(false);
  const [form, setForm] = useState({
    leaveType: 'Annual',
    year: String(new Date().getFullYear()),
    amount: '',
    note: '',
  });

  const selectedEmployee = useMemo(
    () => employees.find((x) => String(x.id) === String(selectedId)) || null,
    [employees, selectedId]
  );

  const fetchEmployees = async () => {
    const res = await api.get('/' + EMPLOYEE_SLUG);
    const rows = Array.isArray(res.data) ? res.data : [];
    setEmployees(rows);
    if (!selectedId && rows.length) setSelectedId(String(rows[0].id));
  };

  const fetchBalances = async (employeeId: string) => {
    if (!employeeId) {
      setBalances([]);
      return;
    }
    const res = await api.get('/' + EMPLOYEE_SLUG + '/' + employeeId + '/leave-balance');
    const rows = Array.isArray(res.data) ? res.data : [];
    setBalances(rows);
  };

  useEffect(() => {
    (async () => {
      try {
        await fetchEmployees();
      } catch (error: any) {
        toast({ title: 'Failed to load employees', description: error?.response?.data?.error || error?.message || 'Unknown error', variant: 'error' });
      } finally {
        setLoading(false);
      }
    })();
  }, []);

  useEffect(() => {
    fetchBalances(selectedId).catch((error: any) => {
      toast({ title: 'Failed to load leave balances', description: error?.response?.data?.error || error?.message || 'Unknown error', variant: 'error' });
    });
  }, [selectedId]);

  const runBalanceAction = async (action: 'accrue' | 'adjust') => {
    if (!selectedId) return;
    const amount = Number(form.amount);
    if (!Number.isFinite(amount) || amount === 0) {
      toast({ title: 'Amount must be non-zero', variant: 'warning' });
      return;
    }
    setWorking(true);
    try {
      await api.post('/' + EMPLOYEE_SLUG + '/' + selectedId + '/leave-balance/' + action, {
        leave_type: form.leaveType,
        year: form.year,
        amount,
        note: form.note || undefined,
      });
      toast({ title: action === 'accrue' ? 'Balance accrued' : 'Balance adjusted', variant: 'success' });
      setForm((prev) => ({ ...prev, amount: '', note: '' }));
      await fetchBalances(selectedId);
    } catch (error: any) {
      toast({ title: action === 'accrue' ? 'Accrual failed' : 'Adjustment failed', description: error?.response?.data?.error || error?.message || 'Unknown error', variant: 'error' });
    } finally {
      setWorking(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Leave Balances</h1>
          <p className="text-sm text-slate-600">Manage accrual and manual adjustments for employee leave balances.</p>
        </div>
        <Link to={'/' + EMPLOYEE_SLUG} className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50">
          Back to Employees
        </Link>
      </div>

      <div className="rounded-lg border bg-white p-4 space-y-3">
        <label className="block text-sm font-medium text-slate-700">Employee</label>
        <select value={selectedId} onChange={(e) => setSelectedId(e.target.value)} className="w-full rounded border px-3 py-2">
          {!employees.length && <option value="">No employees</option>}
          {employees.map((emp) => (
            <option key={String(emp.id)} value={String(emp.id)}>
              {String(emp.first_name || '')} {String(emp.last_name || '')} ({String(emp.id)})
            </option>
          ))}
        </select>
        {selectedEmployee ? (
          <div className="rounded bg-slate-50 px-3 py-2 text-sm text-slate-700">
            Selected: {String(selectedEmployee.first_name || '')} {String(selectedEmployee.last_name || '')}
          </div>
        ) : null}
      </div>

      <div className="rounded-lg border bg-white p-4 space-y-3">
        <h2 className="text-sm font-semibold text-slate-900">Accrue / Adjust</h2>
        <div className="grid gap-3 md:grid-cols-4">
          <input
            value={form.leaveType}
            onChange={(e) => setForm((prev) => ({ ...prev, leaveType: e.target.value }))}
            placeholder="Leave type"
            className="rounded border px-3 py-2 text-sm"
          />
          <input
            value={form.year}
            onChange={(e) => setForm((prev) => ({ ...prev, year: e.target.value }))}
            placeholder="Year"
            className="rounded border px-3 py-2 text-sm"
          />
          <input
            value={form.amount}
            onChange={(e) => setForm((prev) => ({ ...prev, amount: e.target.value }))}
            placeholder="Amount (+/-)"
            className="rounded border px-3 py-2 text-sm"
          />
          <input
            value={form.note}
            onChange={(e) => setForm((prev) => ({ ...prev, note: e.target.value }))}
            placeholder="Note"
            className="rounded border px-3 py-2 text-sm"
          />
        </div>
        <div className="flex flex-wrap justify-end gap-2">
          <button type="button" onClick={() => runBalanceAction('accrue')} disabled={!selectedId || working} className="rounded-md bg-emerald-600 px-3 py-2 text-sm font-semibold text-white hover:bg-emerald-700 disabled:opacity-50">
            Accrue
          </button>
          <button type="button" onClick={() => runBalanceAction('adjust')} disabled={!selectedId || working} className="rounded-md bg-blue-600 px-3 py-2 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-50">
            Adjust
          </button>
        </div>
      </div>

      <div className="rounded-lg border bg-white p-4">
        <h2 className="mb-3 text-sm font-semibold text-slate-900">Current Balances</h2>
        {loading ? (
          <div className="text-sm text-slate-500">Loading…</div>
        ) : balances.length === 0 ? (
          <div className="text-sm text-slate-500">No balances found for selected employee.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-slate-100 text-slate-700">
                <tr>
                  <th className="px-3 py-2 text-left">Type</th>
                  <th className="px-3 py-2 text-left">Year</th>
                  <th className="px-3 py-2 text-left">Accrued</th>
                  <th className="px-3 py-2 text-left">Consumed</th>
                  <th className="px-3 py-2 text-left">Available</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {balances.map((row) => (
                  <tr key={String(row.id)}>
                    <td className="px-3 py-2">{String(row?.[LEAVE_TYPE_FIELD] || '—')}</td>
                    <td className="px-3 py-2">{String(row?.[YEAR_FIELD] || '—')}</td>
                    <td className="px-3 py-2">{String(row?.[ACCRUED_FIELD] ?? 0)}</td>
                    <td className="px-3 py-2">{String(row?.[CONSUMED_FIELD] ?? 0)}</td>
                    <td className="px-3 py-2 font-semibold text-emerald-700">{String(row?.[AVAILABLE_FIELD] ?? 0)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
