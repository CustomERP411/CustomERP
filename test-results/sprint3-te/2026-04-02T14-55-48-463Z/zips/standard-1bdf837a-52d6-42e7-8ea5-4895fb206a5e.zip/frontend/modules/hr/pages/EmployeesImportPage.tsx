import { Link, useNavigate } from 'react-router-dom';
import ImportCsvTool from '../../../src/components/tools/ImportCsvTool';

const fieldDefinitions = [
  { name: 'first_name', label: 'First Name', type: 'string', widget: 'Input', required: true },
  { name: 'last_name', label: 'Last Name', type: 'string', widget: 'Input', required: true },
  { name: 'email', label: 'Email', type: 'string', widget: 'Input', required: true, unique: true },
  { name: 'job_title', label: 'Job Title', type: 'string', widget: 'Input', required: true },
  { name: 'hire_date', label: 'Hire Date', type: 'date', widget: 'DatePicker', required: true },
  { name: 'status', label: 'Status', type: 'string', widget: 'RadioGroup', required: true, options: ['Active', 'On Leave', 'Terminated'] },
  { name: 'department_id', label: 'Department Id', type: 'reference', widget: 'EntitySelect', required: true, referenceEntity: 'departments' },
  { name: 'manager_id', label: 'Manager Id', type: 'reference', widget: 'EntitySelect', required: false, referenceEntity: 'employees' },
  { name: 'salary', label: 'Salary', type: 'decimal', widget: 'NumberInput', required: false },
];

export default function EmployeesImportPage() {
  const navigate = useNavigate();
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Import CSV — Employees</h1>
          <p className="text-sm text-slate-600">Use the template and follow the rules.</p>
        </div>
        <Link to="/employees" className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50 no-print">
          Back
        </Link>
      </div>

      <div className="rounded-lg bg-white p-6 shadow">
        <ImportCsvTool
          entitySlug="employees"
          fields={fieldDefinitions as any}
          onCancel={() => navigate('/employees')}
          onDone={() => navigate('/employees')}
        />
      </div>
    </div>
  );
}
