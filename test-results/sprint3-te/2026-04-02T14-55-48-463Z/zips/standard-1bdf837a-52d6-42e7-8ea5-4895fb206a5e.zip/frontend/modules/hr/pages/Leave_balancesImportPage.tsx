import { Link, useNavigate } from 'react-router-dom';
import ImportCsvTool from '../../../src/components/tools/ImportCsvTool';

const fieldDefinitions = [
  { name: 'employee_id', label: 'Employee Id', type: 'reference', widget: 'EntitySelect', required: true, referenceEntity: 'employees' },
  { name: 'leave_type', label: 'Leave Type', type: 'string', widget: 'Input', required: true },
  { name: 'year', label: 'Year', type: 'string', widget: 'Input', required: true },
  { name: 'annual_entitlement', label: 'Annual Entitlement', type: 'decimal', widget: 'NumberInput', required: false },
  { name: 'accrued_days', label: 'Accrued Days', type: 'decimal', widget: 'NumberInput', required: false },
  { name: 'consumed_days', label: 'Consumed Days', type: 'decimal', widget: 'NumberInput', required: false },
  { name: 'carry_forward_days', label: 'Carry Forward Days', type: 'decimal', widget: 'NumberInput', required: false },
  { name: 'available_days', label: 'Available Days', type: 'decimal', widget: 'NumberInput', required: false },
  { name: 'last_accrual_at', label: 'Last Accrual At', type: 'datetime', widget: 'DatePicker', required: false },
  { name: 'note', label: 'Note', type: 'text', widget: 'TextArea', required: false },
];

export default function Leave_balancesImportPage() {
  const navigate = useNavigate();
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Import CSV — Leave Balances</h1>
          <p className="text-sm text-slate-600">Use the template and follow the rules.</p>
        </div>
        <Link to="/leave_balances" className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50 no-print">
          Back
        </Link>
      </div>

      <div className="rounded-lg bg-white p-6 shadow">
        <ImportCsvTool
          entitySlug="leave_balances"
          fields={fieldDefinitions as any}
          onCancel={() => navigate('/leave_balances')}
          onDone={() => navigate('/leave_balances')}
        />
      </div>
    </div>
  );
}
