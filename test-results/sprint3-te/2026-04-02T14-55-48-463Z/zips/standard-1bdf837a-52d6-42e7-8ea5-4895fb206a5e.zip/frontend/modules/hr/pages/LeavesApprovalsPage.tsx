import { useEffect, useMemo, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../../../src/services/api';
import { useToast } from '../../../src/components/ui/toast';

const ENTITY_SLUG = 'leaves' as const;
const LEAVE_CFG = {
  "leave_entity": "leaves",
  "balance_entity": "leave_balances",
  "employee_field": "employee_id",
  "leave_type_field": "leave_type",
  "start_date_field": "start_date",
  "end_date_field": "end_date",
  "days_field": "leave_days",
  "status_field": "status",
  "available_field": "available_days",
  "fiscal_year_field": "year",
  "enabled": true,
  "work_days": [
    "Mon"
  ],
  "daily_hours": 6,
  "consume_on_approval": true
} as const;
const APPROVAL_CFG = {
  "leave_entity": "leaves",
  "status_field": "status",
  "approver_field": "approver_id",
  "approved_at_field": "approved_at",
  "rejected_at_field": "rejected_at",
  "rejection_reason_field": "rejection_reason",
  "statuses": [
    "Pending",
    "Approved",
    "Rejected",
    "Cancelled"
  ],
  "enabled": true,
  "work_days": [
    "Mon"
  ],
  "daily_hours": 6,
  "balance_entity": "leave_balances",
  "enforce_transitions": true
} as const;

const STATUS_FIELD = APPROVAL_CFG.status_field || LEAVE_CFG.status_field || 'status';
const EMPLOYEE_FIELD = LEAVE_CFG.employee_field || 'employee_id';
const TYPE_FIELD = LEAVE_CFG.leave_type_field || 'leave_type';
const START_FIELD = LEAVE_CFG.start_date_field || 'start_date';
const END_FIELD = LEAVE_CFG.end_date_field || 'end_date';
const DAYS_FIELD = LEAVE_CFG.days_field || 'leave_days';
const APPROVER_FIELD = APPROVAL_CFG.approver_field || 'approver_id';

export default function LeavesApprovalsPage() {
  const { toast } = useToast();
  const [rows, setRows] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [workingId, setWorkingId] = useState('');
  const [showAll, setShowAll] = useState(false);

  const fetchRows = async () => {
    try {
      const params = showAll ? {} : { [STATUS_FIELD]: 'Pending' };
      const res = await api.get('/' + ENTITY_SLUG, { params });
      setRows(Array.isArray(res.data) ? res.data : []);
    } catch (error: any) {
      toast({ title: 'Failed to load requests', description: error?.response?.data?.error || error?.message || 'Unknown error', variant: 'error' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchRows();
  }, [showAll]);

  const pendingCount = useMemo(
    () => rows.filter((x) => String(x?.[STATUS_FIELD] || '').toLowerCase() === 'pending').length,
    [rows]
  );

  const runDecision = async (id: string, action: 'approve' | 'reject' | 'cancel') => {
    if (!id) return;
    const label = action.charAt(0).toUpperCase() + action.slice(1);
    const reason =
      action === 'reject'
        ? (window.prompt('Optional rejection reason:') || '').trim()
        : '';
    if (!confirm(label + ' selected leave request?')) return;

    setWorkingId(id);
    try {
      await api.post('/' + ENTITY_SLUG + '/' + id + '/' + action, {
        [APPROVER_FIELD]: 'manager',
        reason: reason || undefined,
        decision_key: action + '-' + id,
      });
      toast({ title: 'Leave request ' + label.toLowerCase() + 'd', variant: 'success' });
      await fetchRows();
    } catch (error: any) {
      toast({ title: label + ' failed', description: error?.response?.data?.error || error?.message || 'Unknown error', variant: 'error' });
    } finally {
      setWorkingId('');
    }
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-3">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Leave Approvals</h1>
          <p className="text-sm text-slate-600">Review requests, approve/reject, and keep approval audit fields consistent.</p>
          <p className="mt-1 text-sm font-semibold text-amber-700">Pending: {pendingCount}</p>
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={() => setShowAll((v) => !v)}
            className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50"
          >
            {showAll ? 'Show Pending Only' : 'Show All Statuses'}
          </button>
          <Link to={'/' + ENTITY_SLUG} className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50">
            Back to Leaves
          </Link>
        </div>
      </div>

      <div className="rounded-lg border bg-white p-4">
        {loading ? (
          <div className="text-sm text-slate-500">Loading…</div>
        ) : rows.length === 0 ? (
          <div className="text-sm text-slate-500">No leave requests to review.</div>
        ) : (
          <div className="overflow-x-auto">
            <table className="min-w-full text-sm">
              <thead className="bg-slate-100 text-slate-700">
                <tr>
                  <th className="px-3 py-2 text-left">Employee</th>
                  <th className="px-3 py-2 text-left">Type</th>
                  <th className="px-3 py-2 text-left">Start</th>
                  <th className="px-3 py-2 text-left">End</th>
                  <th className="px-3 py-2 text-left">Days</th>
                  <th className="px-3 py-2 text-left">Status</th>
                  <th className="px-3 py-2 text-right">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y">
                {rows.map((row) => {
                  const id = String(row?.id || '');
                  const status = String(row?.[STATUS_FIELD] || 'Pending');
                  const isPending = status.toLowerCase() === 'pending';
                  return (
                    <tr key={id}>
                      <td className="px-3 py-2">{String(row?.[EMPLOYEE_FIELD] || '—')}</td>
                      <td className="px-3 py-2">{String(row?.[TYPE_FIELD] || '—')}</td>
                      <td className="px-3 py-2">{String(row?.[START_FIELD] || '—')}</td>
                      <td className="px-3 py-2">{String(row?.[END_FIELD] || '—')}</td>
                      <td className="px-3 py-2">{String(row?.[DAYS_FIELD] ?? '—')}</td>
                      <td className="px-3 py-2">
                        <span className={status === 'Approved' ? 'rounded bg-emerald-100 px-2 py-1 text-xs font-semibold text-emerald-700' : status === 'Rejected' ? 'rounded bg-rose-100 px-2 py-1 text-xs font-semibold text-rose-700' : 'rounded bg-amber-100 px-2 py-1 text-xs font-semibold text-amber-700'}>
                          {status}
                        </span>
                      </td>
                      <td className="px-3 py-2 text-right">
                        <div className="flex justify-end gap-3">
                          {isPending ? (
                            <>
                              <button type="button" onClick={() => runDecision(id, 'approve')} disabled={workingId === id} className="text-emerald-700 hover:underline disabled:opacity-50">Approve</button>
                              <button type="button" onClick={() => runDecision(id, 'reject')} disabled={workingId === id} className="text-rose-700 hover:underline disabled:opacity-50">Reject</button>
                            </>
                          ) : (
                            <button type="button" onClick={() => runDecision(id, 'cancel')} disabled={workingId === id} className="text-slate-600 hover:underline disabled:opacity-50">Cancel</button>
                          )}
                        </div>
                      </td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        )}
      </div>
    </div>
  );
}
