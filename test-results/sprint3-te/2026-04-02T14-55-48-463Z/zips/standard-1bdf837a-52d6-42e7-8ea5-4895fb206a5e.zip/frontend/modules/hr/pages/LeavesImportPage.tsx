import { Link, useNavigate } from 'react-router-dom';
import ImportCsvTool from '../../../src/components/tools/ImportCsvTool';

const fieldDefinitions = [
  { name: 'employee_id', label: 'Employee Id', type: 'reference', widget: 'EntitySelect', required: true, referenceEntity: 'employees' },
  { name: 'leave_type', label: 'Leave Type', type: 'string', widget: 'RadioGroup', required: true, options: ['Sick'] },
  { name: 'start_date', label: 'Start Date', type: 'date', widget: 'DatePicker', required: true },
  { name: 'end_date', label: 'End Date', type: 'date', widget: 'DatePicker', required: true },
  { name: 'leave_days', label: 'Leave Days', type: 'integer', widget: 'NumberInput', required: false },
  { name: 'status', label: 'Status', type: 'string', widget: 'RadioGroup', required: true, options: ['Pending', 'Approved', 'Rejected', 'Cancelled'] },
  { name: 'approver_id', label: 'Approver Id', type: 'string', widget: 'Input', required: false },
  { name: 'approved_at', label: 'Approved At', type: 'datetime', widget: 'DatePicker', required: false },
  { name: 'rejected_at', label: 'Rejected At', type: 'datetime', widget: 'DatePicker', required: false },
  { name: 'cancelled_at', label: 'Cancelled At', type: 'datetime', widget: 'DatePicker', required: false },
  { name: 'rejection_reason', label: 'Rejection Reason', type: 'text', widget: 'TextArea', required: false },
  { name: 'decision_key', label: 'Decision Key', type: 'string', widget: 'Input', required: false },
  { name: 'reason', label: 'Reason', type: 'text', widget: 'TextArea', required: false },
];

export default function LeavesImportPage() {
  const navigate = useNavigate();
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Import CSV — Leaves</h1>
          <p className="text-sm text-slate-600">Use the template and follow the rules.</p>
        </div>
        <Link to="/leaves" className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50 no-print">
          Back
        </Link>
      </div>

      <div className="rounded-lg bg-white p-6 shadow">
        <ImportCsvTool
          entitySlug="leaves"
          fields={fieldDefinitions as any}
          onCancel={() => navigate('/leaves')}
          onDone={() => navigate('/leaves')}
        />
      </div>
    </div>
  );
}
