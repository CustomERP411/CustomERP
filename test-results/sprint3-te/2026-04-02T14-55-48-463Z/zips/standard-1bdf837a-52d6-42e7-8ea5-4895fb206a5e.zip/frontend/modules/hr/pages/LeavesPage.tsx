import { useEffect, useState } from 'react';
import { Link } from 'react-router-dom';
import api from '../../../src/services/api';
import { useToast } from '../../../src/components/ui/toast';
import LeaveRequestCard from '../../../src/components/modules/hr/LeaveRequestCard';

const STATUS_OPTIONS = ['Pending', 'Approved', 'Rejected'];

export default function LeavesPage() {
  const { toast } = useToast();
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [statusFilter, setStatusFilter] = useState<string>('all');

  useEffect(() => {
    let cancelled = false;
    const run = async () => {
      try {
        setLoading(true);
        const res = await api.get('/leaves');
        if (!cancelled) {
          setItems(Array.isArray(res.data) ? res.data : []);
        }
      } catch (e) {
        if (!cancelled) toast({ title: 'Failed to load leave requests', variant: 'error' });
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    run();
    return () => { cancelled = true; };
  }, []);

  const filteredItems = statusFilter === 'all' 
    ? items 
    : items.filter((leave) => String(leave?.status || 'Pending').toLowerCase() === statusFilter.toLowerCase());

  const pendingCount = items.filter((l) => String(l?.status || 'Pending') === 'Pending').length;

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Leaves</h1>
          <p className="text-sm text-slate-600">Track and manage employee leave requests.</p>
          {pendingCount > 0 ? (
            <p className="mt-1 text-sm font-semibold text-amber-700">{pendingCount} pending approval</p>
          ) : null}
        </div>
        <Link to="/leaves/new" className="rounded-lg bg-emerald-600 px-4 py-2 text-sm font-semibold text-white hover:bg-emerald-700">
          New Leave Request
        </Link>
      </div>

      <div className="flex flex-wrap gap-2">
        <button
          onClick={() => setStatusFilter('all')}
          className={`rounded-lg px-3 py-2 text-sm font-semibold ${statusFilter === 'all' ? 'bg-blue-600 text-white' : 'bg-white text-slate-700 ring-1 ring-slate-200 hover:bg-slate-50'}`}
        >
          All
        </button>
        {STATUS_OPTIONS.map((status) => (
          <button
            key={status}
            onClick={() => setStatusFilter(status)}
            className={`rounded-lg px-3 py-2 text-sm font-semibold ${statusFilter === status ? 'bg-blue-600 text-white' : 'bg-white text-slate-700 ring-1 ring-slate-200 hover:bg-slate-50'}`}
          >
            {status}
          </button>
        ))}
      </div>

      {loading ? (
        <div className="p-4">Loading…</div>
      ) : filteredItems.length === 0 ? (
        <div className="rounded-lg border border-dashed bg-white p-10 text-center text-sm text-slate-500">
          {statusFilter === 'all' 
            ? 'No leave requests yet. Submit your first leave request to get started.' 
            : `No leave requests with status "${statusFilter}".`}
        </div>
      ) : (
        <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
          {filteredItems.map((leave) => (
            <LeaveRequestCard
              key={String(leave.id)}
              leave={leave}
              to={'/leaves/' + leave.id + '/edit'}
            />
          ))}
        </div>
      )}
    </div>
  );
}
