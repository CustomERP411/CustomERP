import { Link, useNavigate } from 'react-router-dom';
import ImportCsvTool from '../../../src/components/tools/ImportCsvTool';

const fieldDefinitions = [
  { name: 'employee_id', label: 'Employee Id', type: 'reference', widget: 'EntitySelect', required: true, referenceEntity: 'employees' },
  { name: 'shift_name', label: 'Shift Name', type: 'string', widget: 'Input', required: true },
  { name: 'start_time', label: 'Start Time', type: 'string', widget: 'Input', required: false },
  { name: 'end_time', label: 'End Time', type: 'string', widget: 'Input', required: false },
  { name: 'work_date', label: 'Work Date', type: 'date', widget: 'DatePicker', required: false },
  { name: 'work_days', label: 'Work Days', type: 'text', widget: 'TextArea', required: false },
  { name: 'status', label: 'Status', type: 'string', widget: 'RadioGroup', required: true, options: ['Active', 'Inactive'] },
  { name: 'effective_from', label: 'Effective From', type: 'date', widget: 'DatePicker', required: false },
  { name: 'effective_to', label: 'Effective To', type: 'date', widget: 'DatePicker', required: false },
];

export default function Shift_assignmentsImportPage() {
  const navigate = useNavigate();
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Import CSV — Shift Assignments</h1>
          <p className="text-sm text-slate-600">Use the template and follow the rules.</p>
        </div>
        <Link to="/shift_assignments" className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50 no-print">
          Back
        </Link>
      </div>

      <div className="rounded-lg bg-white p-6 shadow">
        <ImportCsvTool
          entitySlug="shift_assignments"
          fields={fieldDefinitions as any}
          onCancel={() => navigate('/shift_assignments')}
          onDone={() => navigate('/shift_assignments')}
        />
      </div>
    </div>
  );
}
