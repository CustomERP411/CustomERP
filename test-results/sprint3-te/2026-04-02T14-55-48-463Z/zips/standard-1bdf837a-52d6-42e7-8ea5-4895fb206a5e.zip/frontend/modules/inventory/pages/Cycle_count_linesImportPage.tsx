import { Link, useNavigate } from 'react-router-dom';
import ImportCsvTool from '../../../src/components/tools/ImportCsvTool';

const fieldDefinitions = [
  { name: 'cycle_count_session_id', label: 'Cycle Count Session Id', type: 'reference', widget: 'EntitySelect', required: true, referenceEntity: 'cycle_count_sessions' },
  { name: 'item_id', label: 'Item Id', type: 'reference', widget: 'EntitySelect', required: true, referenceEntity: 'products' },
  { name: 'expected_quantity', label: 'Expected Quantity', type: 'integer', widget: 'NumberInput', required: false },
  { name: 'counted_quantity', label: 'Counted Quantity', type: 'integer', widget: 'NumberInput', required: false },
  { name: 'variance_quantity', label: 'Variance Quantity', type: 'integer', widget: 'NumberInput', required: false },
  { name: 'status', label: 'Status', type: 'string', widget: 'RadioGroup', required: false, options: ['Pending', 'Counted', 'Posted'] },
  { name: 'note', label: 'Note', type: 'text', widget: 'TextArea', required: false },
];

export default function Cycle_count_linesImportPage() {
  const navigate = useNavigate();
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Import CSV — Cycle Count Lines</h1>
          <p className="text-sm text-slate-600">Use the template and follow the rules.</p>
        </div>
        <Link to="/cycle_count_lines" className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50 no-print">
          Back
        </Link>
      </div>

      <div className="rounded-lg bg-white p-6 shadow">
        <ImportCsvTool
          entitySlug="cycle_count_lines"
          fields={fieldDefinitions as any}
          onCancel={() => navigate('/cycle_count_lines')}
          onDone={() => navigate('/cycle_count_lines')}
        />
      </div>
    </div>
  );
}
