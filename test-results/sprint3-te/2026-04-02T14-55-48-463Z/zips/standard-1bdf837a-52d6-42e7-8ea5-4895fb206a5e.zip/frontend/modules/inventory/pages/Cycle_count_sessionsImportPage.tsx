import { Link, useNavigate } from 'react-router-dom';
import ImportCsvTool from '../../../src/components/tools/ImportCsvTool';

const fieldDefinitions = [
  { name: 'session_number', label: 'Session Number', type: 'string', widget: 'Input', required: false, unique: true },
  { name: 'status', label: 'Status', type: 'string', widget: 'Select', required: true, options: ['Draft', 'InProgress', 'PendingApproval', 'Approved', 'Posted'] },
  { name: 'started_at', label: 'Started At', type: 'datetime', widget: 'DatePicker', required: false },
  { name: 'approved_at', label: 'Approved At', type: 'datetime', widget: 'DatePicker', required: false },
  { name: 'approved_by', label: 'Approved By', type: 'string', widget: 'Input', required: false },
  { name: 'posted_at', label: 'Posted At', type: 'datetime', widget: 'DatePicker', required: false },
  { name: 'note', label: 'Note', type: 'text', widget: 'TextArea', required: false },
  { name: 'planned_at', label: 'Planned At', type: 'date', widget: 'DatePicker', required: false },
  { name: 'blind_count', label: 'Blind Count', type: 'boolean', widget: 'Checkbox', required: false },
];

export default function Cycle_count_sessionsImportPage() {
  const navigate = useNavigate();
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Import CSV — Cycle Count Sessions</h1>
          <p className="text-sm text-slate-600">Use the template and follow the rules.</p>
        </div>
        <Link to="/cycle_count_sessions" className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50 no-print">
          Back
        </Link>
      </div>

      <div className="rounded-lg bg-white p-6 shadow">
        <ImportCsvTool
          entitySlug="cycle_count_sessions"
          fields={fieldDefinitions as any}
          onCancel={() => navigate('/cycle_count_sessions')}
          onDone={() => navigate('/cycle_count_sessions')}
        />
      </div>
    </div>
  );
}
