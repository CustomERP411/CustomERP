import { useEffect, useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import api from '../../../src/services/api';
import { useToast } from '../../../src/components/ui/toast';

const ENTITY_SLUG = 'cycle_count_sessions' as const;
const CFG = {
  "session_entity": "cycle_count_sessions",
  "line_entity": "cycle_count_lines",
  "line_session_field": "cycle_count_session_id",
  "line_item_field": "item_id",
  "line_expected_field": "expected_quantity",
  "line_counted_field": "counted_quantity",
  "line_variance_field": "variance_quantity",
  "enabled": true,
  "stock_entity": "products"
} as const;

export default function Cycle_count_sessionsWorkflowPage() {
  const { toast } = useToast();
  const [searchParams] = useSearchParams();

  const [sessions, setSessions] = useState<any[]>([]);
  const [lines, setLines] = useState<any[]>([]);
  const [selectedId, setSelectedId] = useState('');
  const [loading, setLoading] = useState(true);
  const [working, setWorking] = useState(false);
  const [editingLineId, setEditingLineId] = useState('');
  const [editingCountedValue, setEditingCountedValue] = useState<number>(0);

  useEffect(() => {
    const pre = searchParams.get('id');
    if (pre) setSelectedId(String(pre));
  }, [searchParams]);

  const fetchSessions = async () => {
    const res = await api.get('/' + ENTITY_SLUG);
    setSessions(Array.isArray(res.data) ? res.data : []);
  };

  const fetchLines = async (sessionId: string) => {
    if (!sessionId) {
      setLines([]);
      return;
    }
    const res = await api.get('/' + CFG.line_entity, {
      params: { [CFG.line_session_field || 'cycle_count_session_id']: sessionId },
    });
    setLines(Array.isArray(res.data) ? res.data : []);
  };

  useEffect(() => {
    let cancelled = false;
    const run = async () => {
      try {
        await fetchSessions();
      } catch (err) {
        if (!cancelled) toast({ title: 'Load failed', description: 'Could not load cycle sessions', variant: 'error' });
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    run();
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    fetchLines(selectedId).catch((err) => {
      console.error('Failed to load cycle lines:', err);
      toast({ title: 'Load failed', description: 'Could not load cycle lines', variant: 'error' });
    });
  }, [selectedId]);

  const selectedSession = useMemo(
    () => sessions.find((row) => String(row?.id) === String(selectedId)),
    [sessions, selectedId]
  );
  const statusValue = String(selectedSession?.[CFG.session_status_field || 'status'] || '');

  const runAction = async (action: 'start' | 'recalculate' | 'approve' | 'post') => {
    if (!selectedId) {
      toast({ title: 'Select a session first', variant: 'warning' });
      return;
    }
    const labels: Record<string, string> = {
      start: 'Start session',
      recalculate: 'Recalculate variance',
      approve: 'Approve session',
      post: 'Post adjustments',
    };
    if (!confirm(labels[action] + '?')) return;
    setWorking(true);
    try {
      await api.post('/' + ENTITY_SLUG + '/' + selectedId + '/' + action, {});
      await Promise.all([fetchSessions(), fetchLines(selectedId)]);
      toast({ title: labels[action] + ' complete', variant: 'success' });
    } catch (err: any) {
      toast({ title: labels[action] + ' failed', description: err?.response?.data?.error || err?.message || 'Unknown error', variant: 'error' });
    } finally {
      setWorking(false);
    }
  };

  const openCountEditor = (line: any) => {
    setEditingLineId(String(line?.id || ''));
    const current = Number(line?.[CFG.line_counted_field || 'counted_quantity'] ?? 0);
    setEditingCountedValue(Number.isFinite(current) ? current : 0);
  };

  const saveLineCount = async () => {
    if (!editingLineId) return;
    setWorking(true);
    try {
      await api.put('/' + CFG.line_entity + '/' + editingLineId, {
        [CFG.line_counted_field || 'counted_quantity']: editingCountedValue,
      });
      setEditingLineId('');
      await fetchLines(selectedId);
      toast({ title: 'Count updated', variant: 'success' });
    } catch (err: any) {
      toast({ title: 'Update failed', description: err?.response?.data?.error || err?.message || 'Unknown error', variant: 'error' });
    } finally {
      setWorking(false);
    }
  };

  if (loading) return <div className="p-4">Loading...</div>;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Cycle Count Workflow</h1>
          <p className="text-sm text-slate-600">Count inventory, calculate variance, approve, and post adjustments.</p>
        </div>
        <Link to={'/' + ENTITY_SLUG} className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50">
          Back to Cycle_count_sessions
        </Link>
      </div>

      <div className="rounded-lg bg-white p-6 shadow space-y-4">
        <div>
          <label className="mb-1 block text-sm font-medium text-slate-700">Cycle Session</label>
          <select value={selectedId} onChange={(e) => setSelectedId(e.target.value)} className="w-full rounded border px-3 py-2">
            <option value="">Select...</option>
            {sessions.map((row) => (
              <option key={row.id} value={row.id}>
                {String(row.session_number || row.id)} — {String(row?.[CFG.session_status_field || 'status'] || 'Draft')}
              </option>
            ))}
          </select>
        </div>

        {selectedSession ? (
          <div className="rounded border bg-slate-50 p-3 text-sm">
            <span className="font-semibold">Status:</span> {statusValue || 'Draft'}
          </div>
        ) : null}

        <div className="flex flex-wrap justify-end gap-2">
          <button type="button" onClick={() => runAction('start')} disabled={!selectedId || working} className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50 disabled:opacity-50">
            Start
          </button>
          <button type="button" onClick={() => runAction('recalculate')} disabled={!selectedId || working} className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50 disabled:opacity-50">
            Recalculate
          </button>
          <button type="button" onClick={() => runAction('approve')} disabled={!selectedId || working} className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-emerald-700 ring-1 ring-emerald-200 hover:bg-emerald-50 disabled:opacity-50">
            Approve
          </button>
          <button type="button" onClick={() => runAction('post')} disabled={!selectedId || working} className="rounded-md bg-blue-600 px-3 py-2 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-50">
            Post
          </button>
        </div>
      </div>

      <div className="rounded-lg bg-white p-6 shadow">
        <div className="mb-3 text-sm font-semibold text-slate-900">Session Lines</div>
        <div className="overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead className="bg-slate-100 text-slate-700">
              <tr>
                <th className="px-3 py-2 text-left">Item</th>
                <th className="px-3 py-2 text-left">Expected</th>
                <th className="px-3 py-2 text-left">Counted</th>
                <th className="px-3 py-2 text-left">Variance</th>
                <th className="px-3 py-2 text-left">Status</th>
                <th className="px-3 py-2 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {lines.map((row) => (
                <tr key={String(row.id)}>
                  <td className="px-3 py-2">{String(row?.[CFG.line_item_field || 'item_id'] ?? '—')}</td>
                  <td className="px-3 py-2">{String(row?.[CFG.line_expected_field || 'expected_quantity'] ?? 0)}</td>
                  <td className="px-3 py-2">{String(row?.[CFG.line_counted_field || 'counted_quantity'] ?? 0)}</td>
                  <td className="px-3 py-2">{String(row?.[CFG.line_variance_field || 'variance_quantity'] ?? 0)}</td>
                  <td className="px-3 py-2">{String(row?.[CFG.line_status_field || 'status'] ?? 'Pending')}</td>
                  <td className="px-3 py-2 text-right">
                    <button type="button" onClick={() => openCountEditor(row)} className="text-blue-600 hover:underline">
                      Update Count
                    </button>
                  </td>
                </tr>
              ))}
              {lines.length === 0 ? (
                <tr>
                  <td colSpan={6} className="px-3 py-4 text-center text-slate-500">No cycle lines for selected session</td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>

        {editingLineId ? (
          <div className="mt-4 rounded border bg-slate-50 p-4">
            <div className="mb-2 text-sm font-semibold text-slate-900">Update Counted Quantity</div>
            <div className="flex flex-wrap items-center gap-2">
              <input type="number" value={editingCountedValue} onChange={(e) => setEditingCountedValue(e.target.valueAsNumber)} className="w-48 rounded border px-3 py-2 text-sm" />
              <button type="button" onClick={saveLineCount} disabled={working} className="rounded-md bg-blue-600 px-3 py-2 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-50">
                Save
              </button>
              <button type="button" onClick={() => setEditingLineId('')} disabled={working} className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50 disabled:opacity-50">
                Cancel
              </button>
            </div>
          </div>
        ) : null}
      </div>
    </div>
  );
}
