import { Link, useNavigate } from 'react-router-dom';
import ImportCsvTool from '../../../src/components/tools/ImportCsvTool';

const fieldDefinitions = [
  { name: 'goods_receipt_id', label: 'Goods Receipt Id', type: 'reference', widget: 'EntitySelect', required: true, referenceEntity: 'goods_receipts' },
  { name: 'purchase_order_item_id', label: 'Purchase Order Item Id', type: 'reference', widget: 'EntitySelect', required: false, referenceEntity: 'purchase_order_items' },
  { name: 'item_id', label: 'Item Id', type: 'reference', widget: 'EntitySelect', required: true, referenceEntity: 'products' },
  { name: 'received_quantity', label: 'Received Quantity', type: 'integer', widget: 'NumberInput', required: true },
  { name: 'accepted_quantity', label: 'Accepted Quantity', type: 'integer', widget: 'NumberInput', required: false },
  { name: 'rejected_quantity', label: 'Rejected Quantity', type: 'decimal', widget: 'NumberInput', required: false, min: 0 },
  { name: 'discrepancy_reason', label: 'Discrepancy Reason', type: 'text', widget: 'TextArea', required: false },
];

export default function Goods_receipt_itemsImportPage() {
  const navigate = useNavigate();
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Import CSV — Goods Receipt Items</h1>
          <p className="text-sm text-slate-600">Use the template and follow the rules.</p>
        </div>
        <Link to="/goods_receipt_items" className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50 no-print">
          Back
        </Link>
      </div>

      <div className="rounded-lg bg-white p-6 shadow">
        <ImportCsvTool
          entitySlug="goods_receipt_items"
          fields={fieldDefinitions as any}
          onCancel={() => navigate('/goods_receipt_items')}
          onDone={() => navigate('/goods_receipt_items')}
        />
      </div>
    </div>
  );
}
