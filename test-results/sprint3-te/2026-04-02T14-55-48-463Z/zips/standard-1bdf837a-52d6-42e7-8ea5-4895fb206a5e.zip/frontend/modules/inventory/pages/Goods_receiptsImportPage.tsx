import { Link, useNavigate } from 'react-router-dom';
import ImportCsvTool from '../../../src/components/tools/ImportCsvTool';

const fieldDefinitions = [
  { name: 'grn_number', label: 'Grn Number', type: 'string', widget: 'Input', required: false, unique: true },
  { name: 'purchase_order_id', label: 'Purchase Order Id', type: 'reference', widget: 'EntitySelect', required: false, referenceEntity: 'purchase_orders' },
  { name: 'status', label: 'Status', type: 'string', widget: 'RadioGroup', required: true, options: ['Draft', 'Posted', 'Cancelled'] },
  { name: 'received_at', label: 'Received At', type: 'datetime', widget: 'DatePicker', required: false },
  { name: 'posted_at', label: 'Posted At', type: 'datetime', widget: 'DatePicker', required: false },
  { name: 'cancelled_at', label: 'Cancelled At', type: 'datetime', widget: 'DatePicker', required: false },
  { name: 'note', label: 'Note', type: 'text', widget: 'TextArea', required: false },
];

export default function Goods_receiptsImportPage() {
  const navigate = useNavigate();
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Import CSV — Goods Receipts</h1>
          <p className="text-sm text-slate-600">Use the template and follow the rules.</p>
        </div>
        <Link to="/goods_receipts" className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50 no-print">
          Back
        </Link>
      </div>

      <div className="rounded-lg bg-white p-6 shadow">
        <ImportCsvTool
          entitySlug="goods_receipts"
          fields={fieldDefinitions as any}
          onCancel={() => navigate('/goods_receipts')}
          onDone={() => navigate('/goods_receipts')}
        />
      </div>
    </div>
  );
}
