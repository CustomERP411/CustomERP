import { useEffect, useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import api from '../../../src/services/api';
import { ENTITIES } from '../../../src/config/entities';
import { useToast } from '../../../src/components/ui/toast';

const ENTITY_SLUG = 'goods_receipts' as const;
const CFG = {
  "grn_entity": "goods_receipts",
  "grn_item_entity": "goods_receipt_items",
  "grn_item_parent_field": "goods_receipt_id",
  "grn_item_item_field": "item_id",
  "grn_item_received_field": "received_quantity",
  "grn_status_field": "status",
  "enabled": true,
  "stock_entity": "products",
  "purchase_order_entity": "purchase_orders",
  "purchase_order_item_entity": "purchase_order_items"
} as const;

const DISPLAY_FIELD_BY_ENTITY: Record<string, string> = Object.fromEntries(
  ENTITIES.map((e) => [e.slug, e.displayField])
) as Record<string, string>;

const getEntityDisplay = (entitySlug: string, row: any) => {
  const df = DISPLAY_FIELD_BY_ENTITY[entitySlug] || 'name';
  const v = row?.[df] ?? row?.name ?? row?.sku ?? row?.id;
  return String(v ?? '');
};

export default function Goods_receiptsPostingPage() {
  const { toast } = useToast();
  const [searchParams] = useSearchParams();

  const [receipts, setReceipts] = useState<any[]>([]);
  const [lines, setLines] = useState<any[]>([]);
  const [selectedId, setSelectedId] = useState('');
  const [loading, setLoading] = useState(true);
  const [working, setWorking] = useState(false);

  useEffect(() => {
    const pre = searchParams.get('id');
    if (pre) setSelectedId(String(pre));
  }, [searchParams]);

  const fetchReceipts = async () => {
    const res = await api.get('/' + ENTITY_SLUG);
    setReceipts(Array.isArray(res.data) ? res.data : []);
  };

  const fetchLines = async (grnId: string) => {
    if (!grnId) {
      setLines([]);
      return;
    }
    const lineRes = await api.get('/' + CFG.grn_item_entity, {
      params: { [CFG.grn_item_parent_field || 'goods_receipt_id']: grnId },
    });
    setLines(Array.isArray(lineRes.data) ? lineRes.data : []);
  };

  useEffect(() => {
    let cancelled = false;
    const run = async () => {
      try {
        await fetchReceipts();
      } catch (err) {
        if (!cancelled) toast({ title: 'Load failed', description: 'Could not load goods receipts', variant: 'error' });
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    run();
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    fetchLines(selectedId).catch((err) => {
      console.error('Failed to load GRN lines:', err);
      toast({ title: 'Load failed', description: 'Could not load GRN lines', variant: 'error' });
    });
  }, [selectedId]);

  const selectedReceipt = useMemo(
    () => receipts.find((row) => String(row?.id) === String(selectedId)),
    [receipts, selectedId]
  );

  const postReceipt = async () => {
    if (!selectedId) {
      toast({ title: 'Select a goods receipt first', variant: 'warning' });
      return;
    }
    if (!confirm('Post this goods receipt? This updates stock and PO progress.')) return;
    setWorking(true);
    try {
      await api.post('/' + ENTITY_SLUG + '/' + selectedId + '/post', {});
      await Promise.all([fetchReceipts(), fetchLines(selectedId)]);
      toast({ title: 'Goods receipt posted', variant: 'success' });
    } catch (err: any) {
      toast({ title: 'Post failed', description: err?.response?.data?.error || err?.message || 'Unknown error', variant: 'error' });
    } finally {
      setWorking(false);
    }
  };

  const cancelReceipt = async () => {
    if (!selectedId) {
      toast({ title: 'Select a goods receipt first', variant: 'warning' });
      return;
    }
    if (!confirm('Cancel this goods receipt?')) return;
    setWorking(true);
    try {
      await api.post('/' + ENTITY_SLUG + '/' + selectedId + '/cancel', {});
      await Promise.all([fetchReceipts(), fetchLines(selectedId)]);
      toast({ title: 'Goods receipt cancelled', variant: 'success' });
    } catch (err: any) {
      toast({ title: 'Cancel failed', description: err?.response?.data?.error || err?.message || 'Unknown error', variant: 'error' });
    } finally {
      setWorking(false);
    }
  };

  if (loading) return <div className="p-4">Loading...</div>;

  const statusValue = String(selectedReceipt?.[CFG.grn_status_field || 'status'] || '');

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">PO / GRN Posting</h1>
          <p className="text-sm text-slate-600">Review receipt lines and post to update stock atomically.</p>
        </div>
        <Link to={'/' + ENTITY_SLUG} className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50">
          Back to Goods_receipts
        </Link>
      </div>

      <div className="rounded-lg bg-white p-6 shadow space-y-4">
        <div>
          <label className="mb-1 block text-sm font-medium text-slate-700">Goods Receipt</label>
          <select value={selectedId} onChange={(e) => setSelectedId(e.target.value)} className="w-full rounded border px-3 py-2">
            <option value="">Select...</option>
            {receipts.map((row) => (
              <option key={row.id} value={row.id}>
                {String(row.grn_number || row.id)} — {getEntityDisplay(ENTITY_SLUG, row)}
              </option>
            ))}
          </select>
        </div>

        {selectedReceipt ? (
          <div className="rounded border bg-slate-50 p-3 text-sm">
            <div><span className="font-semibold">Status:</span> {statusValue || 'Draft'}</div>
            <div><span className="font-semibold">PO:</span> {String(selectedReceipt?.[CFG.grn_parent_field || 'purchase_order_id'] || '—')}</div>
          </div>
        ) : null}

        <div className="flex flex-wrap justify-end gap-2">
          <button
            type="button"
            onClick={cancelReceipt}
            disabled={!selectedId || working || statusValue === 'Posted' || statusValue === 'Cancelled'}
            className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-rose-700 ring-1 ring-rose-200 hover:bg-rose-50 disabled:opacity-50"
          >
            Cancel GRN
          </button>
          <button
            type="button"
            onClick={postReceipt}
            disabled={!selectedId || working || statusValue === 'Posted' || statusValue === 'Cancelled'}
            className="rounded-md bg-blue-600 px-3 py-2 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-50"
          >
            Post GRN
          </button>
        </div>
      </div>

      <div className="rounded-lg bg-white p-6 shadow">
        <div className="mb-3 text-sm font-semibold text-slate-900">Receipt Lines</div>
        <div className="overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead className="bg-slate-100 text-slate-700">
              <tr>
                <th className="px-3 py-2 text-left">PO Item</th>
                <th className="px-3 py-2 text-left">Item</th>
                <th className="px-3 py-2 text-left">Received</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {lines.map((row) => (
                <tr key={String(row.id)}>
                  <td className="px-3 py-2">{String(row?.[CFG.grn_item_po_item_field || 'purchase_order_item_id'] ?? '—')}</td>
                  <td className="px-3 py-2">{String(row?.[CFG.grn_item_item_field || 'item_id'] ?? '—')}</td>
                  <td className="px-3 py-2">{String(row?.[CFG.grn_item_received_field || 'received_quantity'] ?? 0)}</td>
                </tr>
              ))}
              {lines.length === 0 ? (
                <tr>
                  <td colSpan={3} className="px-3 py-4 text-center text-slate-500">No lines for selected goods receipt</td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
