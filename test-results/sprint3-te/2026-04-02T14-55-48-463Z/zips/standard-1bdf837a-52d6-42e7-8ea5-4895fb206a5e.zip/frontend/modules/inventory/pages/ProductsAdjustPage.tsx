import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate } from 'react-router-dom';
import api from '../../../src/services/api';
import { ENTITIES } from '../../../src/config/entities';
import { useToast } from '../../../src/components/ui/toast';

const INV = {
  "movement_entity": "stock_movements",
  "location_entity": "locations",
  "quantity_field": "quantity",
  "location_ids_field": "location_ids",
  "quantity_mode": "delta",
  "use_workflow_api": true,
  "issue": {
    "allow_negative_stock": true
  },
  "fields": {
    "item_ref": "product_id",
    "qty": "quantity",
    "type": "movement_type",
    "location": "location_id",
    "reason": "reason",
    "reference_number": "reference_number",
    "date": "movement_date",
    "from_location": "from_location_id",
    "to_location": "to_location_id"
  },
  "movement_types": {
    "receive": "IN",
    "issue": "OUT",
    "adjust": "ADJUSTMENT",
    "adjust_in": null,
    "adjust_out": null,
    "transfer_out": "TRANSFER_OUT",
    "transfer_in": "TRANSFER_IN"
  },
  "adjust": {
    "reason_codes": [
      "COUNT",
      "DAMAGED",
      "EXPIRED",
      "RETURN",
      "OTHER"
    ]
  }
} as const;
const ENTITY_SLUG = 'products' as const;

const DISPLAY_FIELD_BY_ENTITY: Record<string, string> = Object.fromEntries(
  ENTITIES.map((e) => [e.slug, e.displayField])
) as Record<string, string>;

const getEntityDisplay = (entitySlug: string, row: any) => {
  const df = DISPLAY_FIELD_BY_ENTITY[entitySlug] || 'name';
  const v = row?.[df] ?? row?.name ?? row?.sku ?? row?.id;
  return String(v ?? '');
};

export default function ProductsAdjustPage() {
  const { toast } = useToast();
  const navigate = useNavigate();

  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const [itemId, setItemId] = useState('');
  const [qtyChange, setQtyChange] = useState<number>(0);
  const [reasonCode, setReasonCode] = useState<string>(INV.adjust.reason_codes?.[0] || 'COUNT');
  const [note, setNote] = useState('');
  const [movementDate, setMovementDate] = useState<string>(() => new Date().toISOString().slice(0, 10));

  useEffect(() => {
    let cancelled = false;
    const run = async () => {
      try {
        const res = await api.get('/' + ENTITY_SLUG);
        if (cancelled) return;
        setItems(Array.isArray(res.data) ? res.data : []);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    run();
    return () => { cancelled = true; };
  }, []);

  const selectedItem = useMemo(() => items.find((it) => String(it.id) === String(itemId)), [items, itemId]);

  const submit = async () => {
    if (!itemId) {
      toast({ title: 'Select an item', variant: 'warning' });
      return;
    }
    if (!Number.isFinite(qtyChange) || qtyChange === 0) {
      toast({ title: 'Quantity change must be non-zero', description: 'Use + for increase, - for decrease', variant: 'warning' });
      return;
    }

    try {
      if ((INV as any).use_workflow_api) {
        await api.post('/' + ENTITY_SLUG + '/' + itemId + '/inventory/adjust', {
          delta: qtyChange,
          movement_date: movementDate || undefined,
          reason: reasonCode,
          note: note || undefined,
        });
        toast({ title: 'Stock adjusted', variant: 'success' });
        navigate('/' + ENTITY_SLUG);
        return;
      }

      const mode = String((INV as any).quantity_mode || 'delta');
      const movement: any = {};
      movement[INV.fields.item_ref] = itemId;
      let movementType = INV.movement_types.adjust;
      let movementQty: number = qtyChange;
      if (mode !== 'delta') {
        movementQty = Math.abs(qtyChange);
        if (qtyChange >= 0) {
          movementType = (INV.movement_types.adjust_in || INV.movement_types.receive);
        } else {
          movementType = (INV.movement_types.adjust_out || INV.movement_types.issue || INV.movement_types.transfer_out || 'OUT');
        }
      }
      movement[INV.fields.type] = movementType;
      movement[INV.fields.qty] = movementQty;
      movement[INV.fields.date] = movementDate;
      movement[INV.fields.reason] = reasonCode + (note ? (': ' + note) : '');

      await api.post('/' + INV.movement_entity, movement);

      const current = Number(selectedItem?.[INV.quantity_field] ?? 0) || 0;
      const patch: any = {};
      patch[INV.quantity_field] = current + qtyChange;
      await api.put('/' + ENTITY_SLUG + '/' + itemId, patch);

      toast({ title: 'Stock adjusted', variant: 'success' });
      navigate('/' + ENTITY_SLUG);
    } catch (err: any) {
      toast({ title: 'Adjust failed', description: err?.response?.data?.error || err?.message || 'Unknown error', variant: 'error' });
    }
  };

  if (loading) return <div className="p-4">Loading...</div>;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Adjust stock</h1>
          <p className="text-sm text-slate-600">Use a quantity change (+/-) and a reason code (for non-sales corrections).</p>
        </div>
        <Link to={'/' + ENTITY_SLUG} className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50 no-print">
          Back
        </Link>
      </div>

      <div className="rounded-lg bg-white p-6 shadow space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Item</label>
          <select value={itemId} onChange={(e) => setItemId(e.target.value)} className="w-full rounded border px-3 py-2">
            <option value="">Select...</option>
            {items.map((it) => (
              <option key={it.id} value={it.id}>{getEntityDisplay(ENTITY_SLUG, it)}</option>
            ))}
          </select>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Quantity change</label>
            <input type="number" value={qtyChange} onChange={(e) => setQtyChange(e.target.valueAsNumber)} className="w-full rounded border px-3 py-2" />
            <div className="mt-1 text-xs text-slate-500">Example: -5 (shrinkage), +10 (found stock)</div>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Movement date</label>
            <input type="date" value={movementDate} onChange={(e) => setMovementDate(e.target.value)} className="w-full rounded border px-3 py-2" />
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Reason code</label>
            <select value={reasonCode} onChange={(e) => setReasonCode(e.target.value)} className="w-full rounded border px-3 py-2">
              {(INV.adjust.reason_codes || []).map((rc) => (
                <option key={rc} value={rc}>{rc}</option>
              ))}
            </select>
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Note (optional)</label>
            <input value={note} onChange={(e) => setNote(e.target.value)} className="w-full rounded border px-3 py-2" />
          </div>
        </div>

        <div className="flex justify-end gap-2 no-print">
          <button type="button" onClick={() => navigate('/' + ENTITY_SLUG)} className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50">
            Cancel
          </button>
          <button type="button" onClick={submit} className="rounded-md bg-blue-600 px-3 py-2 text-sm font-semibold text-white hover:bg-blue-700">
            Apply adjustment
          </button>
        </div>
      </div>
    </div>
  );
}
