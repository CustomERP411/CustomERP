import { Link, useNavigate } from 'react-router-dom';
import ImportCsvTool from '../../../src/components/tools/ImportCsvTool';

const fieldDefinitions = [
  { name: 'name', label: 'Name', type: 'string', widget: 'Input', required: true },
  { name: 'sku', label: 'Sku', type: 'string', widget: 'Input', required: false, unique: true },
  { name: 'quantity', label: 'Quantity', type: 'integer', widget: 'NumberInput', required: true },
  { name: 'reorder_point', label: 'Reorder Point', type: 'integer', widget: 'NumberInput', required: false },
  { name: 'cost_price', label: 'Cost Price', type: 'decimal', widget: 'NumberInput', required: false },
  { name: 'total_value', label: 'Total Value', type: 'decimal', widget: 'NumberInput', required: false },
  { name: 'reserved_quantity', label: 'Reserved Quantity', type: 'integer', widget: 'NumberInput', required: false },
  { name: 'committed_quantity', label: 'Committed Quantity', type: 'integer', widget: 'NumberInput', required: false },
  { name: 'available_quantity', label: 'Available Quantity', type: 'integer', widget: 'NumberInput', required: false },
  { name: 'batch_number', label: 'Batch Number', type: 'string', widget: 'Input', required: false },
  { name: 'serial_number', label: 'Serial Number', type: 'string', widget: 'Input', required: false, unique: true },
  { name: 'expiry_date', label: 'Expiry Date', type: 'date', widget: 'DatePicker', required: false },
  { name: 'location_id', label: 'Location Id', type: 'reference', widget: 'EntitySelect', required: false, referenceEntity: 'locations' },
];

export default function ProductsImportPage() {
  const navigate = useNavigate();
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Import CSV — Products</h1>
          <p className="text-sm text-slate-600">Use the template and follow the rules.</p>
        </div>
        <Link to="/products" className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50 no-print">
          Back
        </Link>
      </div>

      <div className="rounded-lg bg-white p-6 shadow">
        <ImportCsvTool
          entitySlug="products"
          fields={fieldDefinitions as any}
          onCancel={() => navigate('/products')}
          onDone={() => navigate('/products')}
        />
      </div>
    </div>
  );
}
