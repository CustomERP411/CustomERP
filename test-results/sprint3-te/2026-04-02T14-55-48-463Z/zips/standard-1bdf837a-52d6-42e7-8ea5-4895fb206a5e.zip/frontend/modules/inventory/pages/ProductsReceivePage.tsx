import { useEffect, useMemo, useState } from 'react';
import { Link, useNavigate, useSearchParams } from 'react-router-dom';
import api from '../../../src/services/api';
import { ENTITIES } from '../../../src/config/entities';
import { useToast } from '../../../src/components/ui/toast';

const INV = {
  "movement_entity": "stock_movements",
  "location_entity": "locations",
  "quantity_field": "quantity",
  "location_ids_field": "location_ids",
  "quantity_mode": "delta",
  "use_workflow_api": true,
  "issue": {
    "allow_negative_stock": true
  },
  "fields": {
    "item_ref": "product_id",
    "qty": "quantity",
    "type": "movement_type",
    "location": "location_id",
    "reason": "reason",
    "reference_number": "reference_number",
    "date": "movement_date",
    "from_location": "from_location_id",
    "to_location": "to_location_id"
  },
  "movement_types": {
    "receive": "IN",
    "issue": "OUT",
    "adjust": "ADJUSTMENT",
    "adjust_in": null,
    "adjust_out": null,
    "transfer_out": "TRANSFER_OUT",
    "transfer_in": "TRANSFER_IN"
  },
  "adjust": {
    "reason_codes": [
      "COUNT",
      "DAMAGED",
      "EXPIRED",
      "RETURN",
      "OTHER"
    ]
  }
} as const;
const ENTITY_SLUG = 'products' as const;
const ENTITY_LOCATION_FIELD = 'location_id' as any;

const DISPLAY_FIELD_BY_ENTITY: Record<string, string> = Object.fromEntries(
  ENTITIES.map((e) => [e.slug, e.displayField])
) as Record<string, string>;

const getEntityDisplay = (entitySlug: string, row: any) => {
  const df = DISPLAY_FIELD_BY_ENTITY[entitySlug] || 'name';
  const v = row?.[df] ?? row?.name ?? row?.sku ?? row?.id;
  return String(v ?? '');
};

export default function ProductsReceivePage() {
  const { toast } = useToast();
  const navigate = useNavigate();
  const [searchParams] = useSearchParams();

  const [items, setItems] = useState<any[]>([]);
  const [locations, setLocations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);

  const [itemId, setItemId] = useState('');
  const [locationId, setLocationId] = useState('');
  const [quantity, setQuantity] = useState<number>(0);
  const [referenceNumber, setReferenceNumber] = useState('');
  const [movementDate, setMovementDate] = useState<string>(() => new Date().toISOString().slice(0, 10));
  const [note, setNote] = useState('');

  useEffect(() => {
    const pre = searchParams.get('itemId');
    if (pre) setItemId(String(pre));
  }, [searchParams]);

  useEffect(() => {
    let cancelled = false;
    const run = async () => {
      try {
        const [itemsRes, locRes] = await Promise.all([
          api.get('/' + ENTITY_SLUG),
          api.get('/' + INV.location_entity).catch(() => ({ data: [] })),
        ]);
        if (cancelled) return;
        setItems(Array.isArray(itemsRes.data) ? itemsRes.data : []);
        setLocations(Array.isArray(locRes.data) ? locRes.data : []);
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    run();
    return () => { cancelled = true; };
  }, []);

  const selectedItem = useMemo(() => items.find((it) => String(it.id) === String(itemId)), [items, itemId]);

  const submit = async () => {
    if (!itemId) {
      toast({ title: 'Select an item', variant: 'warning' });
      return;
    }
    if (!Number.isFinite(quantity) || quantity <= 0) {
      toast({ title: 'Quantity must be > 0', variant: 'warning' });
      return;
    }

    try {
      if ((INV as any).use_workflow_api) {
        await api.post('/' + ENTITY_SLUG + '/' + itemId + '/inventory/receive', {
          quantity,
          location_id: locationId || undefined,
          movement_date: movementDate || undefined,
          reference_number: referenceNumber || undefined,
          note: note || undefined,
        });
        toast({ title: 'Stock received', variant: 'success' });
        navigate('/' + ENTITY_SLUG);
        return;
      }

      const movement: any = {};
      movement[INV.fields.item_ref] = itemId;
      movement[INV.fields.type] = INV.movement_types.receive;
      movement[INV.fields.qty] = quantity;
      if (locationId) movement[INV.fields.location] = locationId;
      if (movementDate) movement[INV.fields.date] = movementDate;
      if (referenceNumber) movement[INV.fields.reference_number] = referenceNumber;
      if (note) movement[INV.fields.reason] = note;

      await api.post('/' + INV.movement_entity, movement);

      // Update cached quantity on the main entity (if it exists)
      const current = Number(selectedItem?.[INV.quantity_field] ?? 0) || 0;
      const patch: any = {};
      patch[INV.quantity_field] = current + quantity;

      if (locationId && ENTITY_LOCATION_FIELD) {
        if (String(ENTITY_LOCATION_FIELD).endsWith('_ids')) {
          const existing = Array.isArray(selectedItem?.[ENTITY_LOCATION_FIELD]) ? selectedItem?.[ENTITY_LOCATION_FIELD] : [];
          patch[ENTITY_LOCATION_FIELD] = Array.from(new Set([...existing.map(String), String(locationId)]));
        } else {
          patch[ENTITY_LOCATION_FIELD] = locationId;
        }
      }

      await api.put('/' + ENTITY_SLUG + '/' + itemId, patch);

      toast({ title: 'Stock received', variant: 'success' });
      navigate('/' + ENTITY_SLUG);
    } catch (err: any) {
      toast({ title: 'Receive failed', description: err?.response?.data?.error || err?.message || 'Unknown error', variant: 'error' });
    }
  };

  if (loading) return <div className="p-4">Loading...</div>;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Receive stock</h1>
          <p className="text-sm text-slate-600">Creates a movement + updates quantity.</p>
        </div>
        <Link to={'/' + ENTITY_SLUG} className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50 no-print">
          Back
        </Link>
      </div>

      <div className="rounded-lg bg-white p-6 shadow space-y-4">
        <div>
          <label className="block text-sm font-medium text-slate-700 mb-1">Item</label>
          <select value={itemId} onChange={(e) => setItemId(e.target.value)} className="w-full rounded border px-3 py-2">
            <option value="">Select...</option>
            {items.map((it) => (
              <option key={it.id} value={it.id}>{getEntityDisplay(ENTITY_SLUG, it)}</option>
            ))}
          </select>
        </div>

        {locations.length ? (
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Location (optional)</label>
            <select value={locationId} onChange={(e) => setLocationId(e.target.value)} className="w-full rounded border px-3 py-2">
              <option value="">Select...</option>
              {locations.map((l) => (
                <option key={l.id} value={l.id}>{getEntityDisplay(INV.location_entity, l)}</option>
              ))}
            </select>
          </div>
        ) : null}

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Quantity</label>
            <input type="number" value={quantity} onChange={(e) => setQuantity(e.target.valueAsNumber)} className="w-full rounded border px-3 py-2" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Movement date</label>
            <input type="date" value={movementDate} onChange={(e) => setMovementDate(e.target.value)} className="w-full rounded border px-3 py-2" />
          </div>
        </div>

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-2">
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Reference # (optional)</label>
            <input value={referenceNumber} onChange={(e) => setReferenceNumber(e.target.value)} className="w-full rounded border px-3 py-2" />
          </div>
          <div>
            <label className="block text-sm font-medium text-slate-700 mb-1">Note (optional)</label>
            <input value={note} onChange={(e) => setNote(e.target.value)} className="w-full rounded border px-3 py-2" />
          </div>
        </div>

        <div className="flex justify-end gap-2 no-print">
          <button type="button" onClick={() => navigate('/' + ENTITY_SLUG)} className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50">
            Cancel
          </button>
          <button type="button" onClick={submit} className="rounded-md bg-blue-600 px-3 py-2 text-sm font-semibold text-white hover:bg-blue-700">
            Receive
          </button>
        </div>
      </div>
    </div>
  );
}
