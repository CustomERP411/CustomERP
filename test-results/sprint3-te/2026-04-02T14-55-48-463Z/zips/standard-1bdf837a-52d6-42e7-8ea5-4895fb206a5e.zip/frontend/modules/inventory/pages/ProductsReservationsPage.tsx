import { useEffect, useMemo, useState } from 'react';
import { Link, useSearchParams } from 'react-router-dom';
import api from '../../../src/services/api';
import { ENTITIES } from '../../../src/config/entities';
import { useToast } from '../../../src/components/ui/toast';

const ENTITY_SLUG = 'products' as const;
const CFG = {
  "reservation_entity": "stock_reservations",
  "item_field": "item_id",
  "quantity_field": "quantity",
  "status_field": "status",
  "reserved_field": "reserved_quantity",
  "committed_field": "committed_quantity",
  "available_field": "available_quantity",
  "enabled": true,
  "stock_entity": "products"
} as const;

const DISPLAY_FIELD_BY_ENTITY: Record<string, string> = Object.fromEntries(
  ENTITIES.map((e) => [e.slug, e.displayField])
) as Record<string, string>;

const getEntityDisplay = (entitySlug: string, row: any) => {
  const df = DISPLAY_FIELD_BY_ENTITY[entitySlug] || 'name';
  const v = row?.[df] ?? row?.name ?? row?.sku ?? row?.id;
  return String(v ?? '');
};

export default function ProductsReservationsPage() {
  const { toast } = useToast();
  const [searchParams] = useSearchParams();

  const [items, setItems] = useState<any[]>([]);
  const [itemId, setItemId] = useState('');
  const [reservations, setReservations] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [working, setWorking] = useState(false);

  const [quantity, setQuantity] = useState<number>(0);
  const [referenceNumber, setReferenceNumber] = useState('');
  const [note, setNote] = useState('');

  useEffect(() => {
    const preselected = searchParams.get('itemId');
    if (preselected) setItemId(String(preselected));
  }, [searchParams]);

  const fetchItems = async () => {
    const res = await api.get('/' + ENTITY_SLUG);
    setItems(Array.isArray(res.data) ? res.data : []);
  };

  const fetchReservations = async (targetItemId: string) => {
    if (!targetItemId) {
      setReservations([]);
      return;
    }
    const res = await api.get('/' + ENTITY_SLUG + '/' + targetItemId + '/reservations');
    setReservations(Array.isArray(res.data) ? res.data : []);
  };

  useEffect(() => {
    let cancelled = false;
    const run = async () => {
      try {
        await fetchItems();
      } catch (err) {
        if (!cancelled) toast({ title: 'Load failed', description: 'Could not load items', variant: 'error' });
      } finally {
        if (!cancelled) setLoading(false);
      }
    };
    run();
    return () => { cancelled = true; };
  }, []);

  useEffect(() => {
    fetchReservations(itemId).catch((err) => {
      console.error('Failed to load reservations:', err);
      toast({ title: 'Load failed', description: 'Could not load reservations', variant: 'error' });
    });
  }, [itemId]);

  const selectedItem = useMemo(
    () => items.find((row) => String(row?.id) === String(itemId)),
    [items, itemId]
  );

  const createReservation = async () => {
    if (!itemId) {
      toast({ title: 'Select item first', variant: 'warning' });
      return;
    }
    if (!Number.isFinite(quantity) || quantity <= 0) {
      toast({ title: 'Quantity must be greater than zero', variant: 'warning' });
      return;
    }

    setWorking(true);
    try {
      await api.post('/' + ENTITY_SLUG + '/' + itemId + '/reservations', {
        quantity,
        reference_number: referenceNumber || undefined,
        note: note || undefined,
      });
      setQuantity(0);
      setReferenceNumber('');
      setNote('');
      await Promise.all([fetchItems(), fetchReservations(itemId)]);
      toast({ title: 'Reservation created', variant: 'success' });
    } catch (err: any) {
      toast({ title: 'Reserve failed', description: err?.response?.data?.error || err?.message || 'Unknown error', variant: 'error' });
    } finally {
      setWorking(false);
    }
  };

  const runReservationAction = async (reservationId: string, action: 'release' | 'commit') => {
    if (!itemId || !reservationId) return;
    const question = action === 'release' ? 'Release this reservation?' : 'Commit this reservation?';
    if (!confirm(question)) return;
    setWorking(true);
    try {
      await api.post('/' + ENTITY_SLUG + '/' + itemId + '/reservations/' + reservationId + '/' + action, {});
      await Promise.all([fetchItems(), fetchReservations(itemId)]);
      toast({
        title: action === 'release' ? 'Reservation released' : 'Reservation committed',
        variant: 'success',
      });
    } catch (err: any) {
      toast({ title: 'Action failed', description: err?.response?.data?.error || err?.message || 'Unknown error', variant: 'error' });
    } finally {
      setWorking(false);
    }
  };

  if (loading) return <div className="p-4">Loading...</div>;

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Inventory Reservations</h1>
          <p className="text-sm text-slate-600">Reserve, release, or commit stock with clear availability checks.</p>
        </div>
        <Link to={'/' + ENTITY_SLUG} className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50">
          Back to Products
        </Link>
      </div>

      <div className="rounded-lg bg-white p-6 shadow space-y-4">
        <div>
          <label className="mb-1 block text-sm font-medium text-slate-700">Item</label>
          <select
            value={itemId}
            onChange={(e) => setItemId(e.target.value)}
            className="w-full rounded border px-3 py-2"
          >
            <option value="">Select...</option>
            {items.map((row) => (
              <option key={row.id} value={row.id}>{getEntityDisplay(ENTITY_SLUG, row)}</option>
            ))}
          </select>
        </div>

        {selectedItem ? (
          <div className="rounded border bg-slate-50 p-4">
            <div className="mb-2 text-sm font-semibold text-slate-900">Availability Snapshot</div>
            <div className="grid grid-cols-2 gap-3 text-sm sm:grid-cols-4">
              <div>
                <div className="text-slate-500">On Hand</div>
                <div className="font-semibold text-slate-900">{selectedItem[CFG.quantity_field || 'quantity'] ?? 0}</div>
              </div>
              <div>
                <div className="text-slate-500">Reserved</div>
                <div className="font-semibold text-amber-700">{selectedItem[CFG.reserved_field || 'reserved_quantity'] ?? 0}</div>
              </div>
              <div>
                <div className="text-slate-500">Committed</div>
                <div className="font-semibold text-blue-700">{selectedItem[CFG.committed_field || 'committed_quantity'] ?? 0}</div>
              </div>
              <div>
                <div className="text-slate-500">Available</div>
                <div className="font-semibold text-emerald-700">{selectedItem[CFG.available_field || 'available_quantity'] ?? 0}</div>
              </div>
            </div>
          </div>
        ) : null}

        <div className="grid grid-cols-1 gap-4 sm:grid-cols-3">
          <div>
            <label className="mb-1 block text-sm font-medium text-slate-700">Quantity</label>
            <input type="number" value={quantity} onChange={(e) => setQuantity(e.target.valueAsNumber)} className="w-full rounded border px-3 py-2" />
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium text-slate-700">Reference # (optional)</label>
            <input value={referenceNumber} onChange={(e) => setReferenceNumber(e.target.value)} className="w-full rounded border px-3 py-2" />
          </div>
          <div>
            <label className="mb-1 block text-sm font-medium text-slate-700">Note (optional)</label>
            <input value={note} onChange={(e) => setNote(e.target.value)} className="w-full rounded border px-3 py-2" />
          </div>
        </div>

        <div className="flex justify-end">
          <button
            type="button"
            disabled={working}
            onClick={createReservation}
            className="rounded-md bg-blue-600 px-3 py-2 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-50"
          >
            Reserve Stock
          </button>
        </div>
      </div>

      <div className="rounded-lg bg-white p-6 shadow">
        <div className="mb-3 text-sm font-semibold text-slate-900">Reservations</div>
        <div className="overflow-x-auto">
          <table className="min-w-full text-sm">
            <thead className="bg-slate-100 text-slate-700">
              <tr>
                <th className="px-3 py-2 text-left">Reservation</th>
                <th className="px-3 py-2 text-left">Quantity</th>
                <th className="px-3 py-2 text-left">Status</th>
                <th className="px-3 py-2 text-left">Reference</th>
                <th className="px-3 py-2 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y">
              {reservations.map((row) => {
                const status = String(row?.[CFG.status_field || 'status'] || 'Pending');
                const pending = status === 'Pending';
                return (
                  <tr key={String(row.id)}>
                    <td className="px-3 py-2">{String(row.reservation_number || row.id)}</td>
                    <td className="px-3 py-2">{String(row?.[CFG.quantity_field || 'quantity'] ?? 0)}</td>
                    <td className="px-3 py-2">{status}</td>
                    <td className="px-3 py-2">{String(row.source_reference || '')}</td>
                    <td className="px-3 py-2 text-right">
                      <div className="flex justify-end gap-3">
                        {pending ? (
                          <>
                            <button
                              type="button"
                              onClick={() => runReservationAction(String(row.id), 'release')}
                              disabled={working}
                              className="text-amber-700 hover:underline disabled:opacity-50"
                            >
                              Release
                            </button>
                            <button
                              type="button"
                              onClick={() => runReservationAction(String(row.id), 'commit')}
                              disabled={working}
                              className="text-emerald-700 hover:underline disabled:opacity-50"
                            >
                              Commit
                            </button>
                          </>
                        ) : (
                          <span className="text-slate-400">—</span>
                        )}
                      </div>
                    </td>
                  </tr>
                );
              })}
              {reservations.length === 0 ? (
                <tr>
                  <td colSpan={5} className="px-3 py-4 text-center text-slate-500">No reservations yet</td>
                </tr>
              ) : null}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
}
