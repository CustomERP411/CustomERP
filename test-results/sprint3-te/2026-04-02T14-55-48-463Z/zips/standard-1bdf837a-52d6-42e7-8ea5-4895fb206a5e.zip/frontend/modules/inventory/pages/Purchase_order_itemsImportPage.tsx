import { Link, useNavigate } from 'react-router-dom';
import ImportCsvTool from '../../../src/components/tools/ImportCsvTool';

const fieldDefinitions = [
  { name: 'purchase_order_id', label: 'Purchase Order Id', type: 'reference', widget: 'EntitySelect', required: true, referenceEntity: 'purchase_orders' },
  { name: 'item_id', label: 'Item Id', type: 'reference', widget: 'EntitySelect', required: true, referenceEntity: 'products' },
  { name: 'ordered_quantity', label: 'Ordered Quantity', type: 'integer', widget: 'NumberInput', required: true },
  { name: 'received_quantity', label: 'Received Quantity', type: 'integer', widget: 'NumberInput', required: false },
  { name: 'status', label: 'Status', type: 'string', widget: 'RadioGroup', required: false, options: ['Open', 'Partial', 'Received'] },
  { name: 'unit_cost', label: 'Unit Cost', type: 'decimal', widget: 'NumberInput', required: false, min: 0 },
];

export default function Purchase_order_itemsImportPage() {
  const navigate = useNavigate();
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Import CSV — Purchase Order Items</h1>
          <p className="text-sm text-slate-600">Use the template and follow the rules.</p>
        </div>
        <Link to="/purchase_order_items" className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50 no-print">
          Back
        </Link>
      </div>

      <div className="rounded-lg bg-white p-6 shadow">
        <ImportCsvTool
          entitySlug="purchase_order_items"
          fields={fieldDefinitions as any}
          onCancel={() => navigate('/purchase_order_items')}
          onDone={() => navigate('/purchase_order_items')}
        />
      </div>
    </div>
  );
}
