import { Link, useNavigate } from 'react-router-dom';
import ImportCsvTool from '../../../src/components/tools/ImportCsvTool';

const fieldDefinitions = [
  { name: 'po_number', label: 'Po Number', type: 'string', widget: 'Input', required: true, unique: true },
  { name: 'supplier_name', label: 'Supplier Name', type: 'string', widget: 'Input', required: true },
  { name: 'status', label: 'Status', type: 'string', widget: 'RadioGroup', required: true, options: ['Open', 'Partial', 'Received', 'Cancelled'] },
  { name: 'order_date', label: 'Order Date', type: 'date', widget: 'DatePicker', required: true },
  { name: 'notes', label: 'Notes', type: 'text', widget: 'TextArea', required: false },
  { name: 'expected_date', label: 'Expected Date', type: 'date', widget: 'DatePicker', required: false },
  { name: 'allow_over_receipt', label: 'Allow Over Receipt', type: 'boolean', widget: 'Checkbox', required: false },
  { name: 'note', label: 'Note', type: 'text', widget: 'TextArea', required: false },
];

export default function Purchase_ordersImportPage() {
  const navigate = useNavigate();
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Import CSV — Purchase Orders</h1>
          <p className="text-sm text-slate-600">Use the template and follow the rules.</p>
        </div>
        <Link to="/purchase_orders" className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50 no-print">
          Back
        </Link>
      </div>

      <div className="rounded-lg bg-white p-6 shadow">
        <ImportCsvTool
          entitySlug="purchase_orders"
          fields={fieldDefinitions as any}
          onCancel={() => navigate('/purchase_orders')}
          onDone={() => navigate('/purchase_orders')}
        />
      </div>
    </div>
  );
}
