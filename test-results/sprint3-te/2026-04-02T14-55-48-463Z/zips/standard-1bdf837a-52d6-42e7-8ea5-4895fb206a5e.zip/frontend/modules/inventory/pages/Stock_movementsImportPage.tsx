import { Link, useNavigate } from 'react-router-dom';
import ImportCsvTool from '../../../src/components/tools/ImportCsvTool';

const fieldDefinitions = [
  { name: 'item_id', label: 'Item Id', type: 'reference', widget: 'EntitySelect', required: true, referenceEntity: 'products' },
  { name: 'movement_type', label: 'Movement Type', type: 'string', widget: 'RadioGroup', required: true, options: ['Receive', 'Issue', 'Adjust', 'Transfer'] },
  { name: 'quantity', label: 'Quantity', type: 'integer', widget: 'NumberInput', required: true },
  { name: 'movement_date', label: 'Movement Date', type: 'date', widget: 'DatePicker', required: true },
  { name: 'reason', label: 'Reason', type: 'string', widget: 'Input', required: false },
  { name: 'reference_number', label: 'Reference Number', type: 'string', widget: 'Input', required: false },
  { name: 'location_id', label: 'Location Id', type: 'reference', widget: 'EntitySelect', required: false, referenceEntity: 'locations' },
  { name: 'from_location_id', label: 'From Location Id', type: 'string', widget: 'Input', required: false },
  { name: 'to_location_id', label: 'To Location Id', type: 'string', widget: 'Input', required: false },
  { name: 'batch_number', label: 'Batch Number', type: 'string', widget: 'Input', required: false },
  { name: 'serial_number', label: 'Serial Number', type: 'string', widget: 'Input', required: false },
];

export default function Stock_movementsImportPage() {
  const navigate = useNavigate();
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Import CSV — Stock Movements</h1>
          <p className="text-sm text-slate-600">Use the template and follow the rules.</p>
        </div>
        <Link to="/stock_movements" className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50 no-print">
          Back
        </Link>
      </div>

      <div className="rounded-lg bg-white p-6 shadow">
        <ImportCsvTool
          entitySlug="stock_movements"
          fields={fieldDefinitions as any}
          onCancel={() => navigate('/stock_movements')}
          onDone={() => navigate('/stock_movements')}
        />
      </div>
    </div>
  );
}
