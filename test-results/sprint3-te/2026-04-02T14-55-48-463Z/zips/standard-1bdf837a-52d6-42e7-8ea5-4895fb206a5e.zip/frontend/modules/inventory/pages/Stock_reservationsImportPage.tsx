import { Link, useNavigate } from 'react-router-dom';
import ImportCsvTool from '../../../src/components/tools/ImportCsvTool';

const fieldDefinitions = [
  { name: 'reservation_number', label: 'Reservation Number', type: 'string', widget: 'Input', required: false, unique: true },
  { name: 'item_id', label: 'Item Id', type: 'reference', widget: 'EntitySelect', required: true, referenceEntity: 'products' },
  { name: 'quantity', label: 'Quantity', type: 'integer', widget: 'NumberInput', required: true },
  { name: 'status', label: 'Status', type: 'string', widget: 'RadioGroup', required: true, options: ['Pending', 'Released', 'Committed'] },
  { name: 'source_reference', label: 'Source Reference', type: 'string', widget: 'Input', required: false },
  { name: 'note', label: 'Note', type: 'text', widget: 'TextArea', required: false },
  { name: 'reserved_at', label: 'Reserved At', type: 'datetime', widget: 'DatePicker', required: false },
  { name: 'released_at', label: 'Released At', type: 'datetime', widget: 'DatePicker', required: false },
  { name: 'committed_at', label: 'Committed At', type: 'datetime', widget: 'DatePicker', required: false },
];

export default function Stock_reservationsImportPage() {
  const navigate = useNavigate();
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Import CSV — Stock Reservations</h1>
          <p className="text-sm text-slate-600">Use the template and follow the rules.</p>
        </div>
        <Link to="/stock_reservations" className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50 no-print">
          Back
        </Link>
      </div>

      <div className="rounded-lg bg-white p-6 shadow">
        <ImportCsvTool
          entitySlug="stock_reservations"
          fields={fieldDefinitions as any}
          onCancel={() => navigate('/stock_reservations')}
          onDone={() => navigate('/stock_reservations')}
        />
      </div>
    </div>
  );
}
