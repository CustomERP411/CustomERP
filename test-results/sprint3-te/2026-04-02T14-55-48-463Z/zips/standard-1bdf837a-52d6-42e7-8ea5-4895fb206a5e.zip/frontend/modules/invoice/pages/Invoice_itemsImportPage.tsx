import { Link, useNavigate } from 'react-router-dom';
import ImportCsvTool from '../../../src/components/tools/ImportCsvTool';

const fieldDefinitions = [
  { name: 'invoice_id', label: 'Invoice Id', type: 'reference', widget: 'EntitySelect', required: true, referenceEntity: 'invoices' },
  { name: 'description', label: 'Description', type: 'string', widget: 'Input', required: true },
  { name: 'quantity', label: 'Quantity', type: 'decimal', widget: 'NumberInput', required: true },
  { name: 'unit_price', label: 'Unit Price', type: 'decimal', widget: 'NumberInput', required: true },
  { name: 'line_total', label: 'Line Total', type: 'decimal', widget: 'NumberInput', required: false },
  { name: 'line_subtotal', label: 'Line Subtotal', type: 'decimal', widget: 'NumberInput', required: false },
  { name: 'line_discount_type', label: 'Line Discount Type', type: 'string', widget: 'RadioGroup', required: false, options: ['Percent', 'Fixed'] },
  { name: 'line_discount_value', label: 'Line Discount Value', type: 'decimal', widget: 'NumberInput', required: false },
  { name: 'line_discount_amount', label: 'Line Discount Amount', type: 'decimal', widget: 'NumberInput', required: false },
  { name: 'line_tax_rate', label: 'Line Tax Rate', type: 'decimal', widget: 'NumberInput', required: false },
  { name: 'line_tax_amount', label: 'Line Tax Amount', type: 'decimal', widget: 'NumberInput', required: false },
  { name: 'line_charges', label: 'Line Charges', type: 'decimal', widget: 'NumberInput', required: false },
  { name: 'line_discount_total', label: 'Discount Total', type: 'decimal', widget: 'NumberInput', required: false, min: 0 },
  { name: 'line_tax_total', label: 'Tax Total', type: 'decimal', widget: 'NumberInput', required: false, min: 0 },
  { name: 'line_additional_charge', label: 'Additional Charge', type: 'decimal', widget: 'NumberInput', required: false, min: 0 },
];

export default function Invoice_itemsImportPage() {
  const navigate = useNavigate();
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Import CSV — Invoice Items</h1>
          <p className="text-sm text-slate-600">Use the template and follow the rules.</p>
        </div>
        <Link to="/invoice_items" className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50 no-print">
          Back
        </Link>
      </div>

      <div className="rounded-lg bg-white p-6 shadow">
        <ImportCsvTool
          entitySlug="invoice_items"
          fields={fieldDefinitions as any}
          onCancel={() => navigate('/invoice_items')}
          onDone={() => navigate('/invoice_items')}
        />
      </div>
    </div>
  );
}
