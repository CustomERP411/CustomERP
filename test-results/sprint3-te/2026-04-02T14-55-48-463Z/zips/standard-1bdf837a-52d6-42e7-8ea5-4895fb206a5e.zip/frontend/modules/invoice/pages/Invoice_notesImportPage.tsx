import { Link, useNavigate } from 'react-router-dom';
import ImportCsvTool from '../../../src/components/tools/ImportCsvTool';

const fieldDefinitions = [
  { name: 'note_number', label: 'Note Number', type: 'string', widget: 'Input', required: false, unique: true },
  { name: 'source_invoice_id', label: 'Source Invoice Id', type: 'reference', widget: 'EntitySelect', required: true, referenceEntity: 'invoices' },
  { name: 'note_type', label: 'Note Type', type: 'string', widget: 'RadioGroup', required: true, options: ['Credit', 'Debit'] },
  { name: 'amount', label: 'Amount', type: 'decimal', widget: 'NumberInput', required: true },
  { name: 'tax_total', label: 'Tax Total', type: 'decimal', widget: 'NumberInput', required: false },
  { name: 'grand_total', label: 'Grand Total', type: 'decimal', widget: 'NumberInput', required: false },
  { name: 'status', label: 'Status', type: 'string', widget: 'RadioGroup', required: false, options: ['Draft', 'Posted', 'Cancelled'] },
  { name: 'issue_date', label: 'Issue Date', type: 'date', widget: 'DatePicker', required: false },
  { name: 'reason', label: 'Reason', type: 'text', widget: 'TextArea', required: false },
  { name: 'post_reference', label: 'Post Reference', type: 'string', widget: 'Input', required: false },
  { name: 'posted_at', label: 'Posted At', type: 'datetime', widget: 'DatePicker', required: false },
  { name: 'cancelled_at', label: 'Cancelled At', type: 'datetime', widget: 'DatePicker', required: false },
  { name: 'cancel_reason', label: 'Cancel Reason', type: 'text', widget: 'TextArea', required: false },
  { name: 'note', label: 'Note', type: 'text', widget: 'TextArea', required: false },
];

export default function Invoice_notesImportPage() {
  const navigate = useNavigate();
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Import CSV — Invoice Notes</h1>
          <p className="text-sm text-slate-600">Use the template and follow the rules.</p>
        </div>
        <Link to="/invoice_notes" className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50 no-print">
          Back
        </Link>
      </div>

      <div className="rounded-lg bg-white p-6 shadow">
        <ImportCsvTool
          entitySlug="invoice_notes"
          fields={fieldDefinitions as any}
          onCancel={() => navigate('/invoice_notes')}
          onDone={() => navigate('/invoice_notes')}
        />
      </div>
    </div>
  );
}
