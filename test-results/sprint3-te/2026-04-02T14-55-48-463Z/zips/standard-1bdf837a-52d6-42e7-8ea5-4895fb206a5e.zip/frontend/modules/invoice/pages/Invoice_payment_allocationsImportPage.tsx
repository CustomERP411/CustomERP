import { Link, useNavigate } from 'react-router-dom';
import ImportCsvTool from '../../../src/components/tools/ImportCsvTool';

const fieldDefinitions = [
  { name: 'payment_id', label: 'Payment Id', type: 'reference', widget: 'EntitySelect', required: true, referenceEntity: 'invoice_payments' },
  { name: 'invoice_id', label: 'Invoice Id', type: 'reference', widget: 'EntitySelect', required: true, referenceEntity: 'invoices' },
  { name: 'amount', label: 'Amount', type: 'decimal', widget: 'NumberInput', required: true },
  { name: 'allocated_at', label: 'Allocated At', type: 'datetime', widget: 'DatePicker', required: false },
  { name: 'note', label: 'Note', type: 'text', widget: 'TextArea', required: false },
];

export default function Invoice_payment_allocationsImportPage() {
  const navigate = useNavigate();
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Import CSV — Invoice Payment Allocations</h1>
          <p className="text-sm text-slate-600">Use the template and follow the rules.</p>
        </div>
        <Link to="/invoice_payment_allocations" className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50 no-print">
          Back
        </Link>
      </div>

      <div className="rounded-lg bg-white p-6 shadow">
        <ImportCsvTool
          entitySlug="invoice_payment_allocations"
          fields={fieldDefinitions as any}
          onCancel={() => navigate('/invoice_payment_allocations')}
          onDone={() => navigate('/invoice_payment_allocations')}
        />
      </div>
    </div>
  );
}
