import { Link, useNavigate } from 'react-router-dom';
import ImportCsvTool from '../../../src/components/tools/ImportCsvTool';

const fieldDefinitions = [
  { name: 'payment_number', label: 'Payment Number', type: 'string', widget: 'Input', required: false, unique: true },
  { name: 'invoice_id', label: 'Invoice Id', type: 'reference', widget: 'EntitySelect', required: true, referenceEntity: 'invoices' },
  { name: 'amount', label: 'Amount', type: 'decimal', widget: 'NumberInput', required: true },
  { name: 'payment_date', label: 'Payment Date', type: 'date', widget: 'DatePicker', required: true },
  { name: 'payment_method', label: 'Payment Method', type: 'string', widget: 'Input', required: false },
  { name: 'status', label: 'Status', type: 'string', widget: 'RadioGroup', required: false, options: ['Draft', 'Posted', 'Cancelled'] },
  { name: 'reference_number', label: 'Reference Number', type: 'string', widget: 'Input', required: false },
  { name: 'posted_at', label: 'Posted At', type: 'datetime', widget: 'DatePicker', required: false },
  { name: 'cancelled_at', label: 'Cancelled At', type: 'datetime', widget: 'DatePicker', required: false },
  { name: 'cancel_reason', label: 'Cancel Reason', type: 'text', widget: 'TextArea', required: false },
  { name: 'note', label: 'Note', type: 'text', widget: 'TextArea', required: false },
  { name: 'customer_id', label: 'Customer', type: 'reference', widget: 'EntitySelect', required: false, referenceEntity: 'customers' },
  { name: 'unallocated_amount', label: 'Unallocated Amount', type: 'decimal', widget: 'NumberInput', required: false, min: 0 },
];

export default function Invoice_paymentsImportPage() {
  const navigate = useNavigate();
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Import CSV — Invoice Payments</h1>
          <p className="text-sm text-slate-600">Use the template and follow the rules.</p>
        </div>
        <Link to="/invoice_payments" className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50 no-print">
          Back
        </Link>
      </div>

      <div className="rounded-lg bg-white p-6 shadow">
        <ImportCsvTool
          entitySlug="invoice_payments"
          fields={fieldDefinitions as any}
          onCancel={() => navigate('/invoice_payments')}
          onDone={() => navigate('/invoice_payments')}
        />
      </div>
    </div>
  );
}
