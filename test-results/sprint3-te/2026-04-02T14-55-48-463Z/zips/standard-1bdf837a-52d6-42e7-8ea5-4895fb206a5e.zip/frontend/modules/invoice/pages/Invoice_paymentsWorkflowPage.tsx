import { useEffect, useState } from 'react';
import api from '../../../src/services/api';
import { useToast } from '../../../src/components/ui/toast';

const ENTITY_SLUG = 'invoice_payments';

export default function Invoice_paymentsWorkflowPage() {
  const { toast } = useToast();
  const [items, setItems] = useState<any[]>([]);
  const [selectedId, setSelectedId] = useState<string>('');
  const [working, setWorking] = useState(false);

  const fetchData = async () => {
    try {
      const res = await api.get('/' + ENTITY_SLUG);
      const rows = Array.isArray(res.data) ? res.data : [];
      setItems(rows);
      if (!selectedId && rows.length) setSelectedId(String(rows[0].id));
    } catch (error: any) {
      toast({ title: 'Failed to load payments', description: error?.response?.data?.error || error?.message || 'Unknown error', variant: 'error' });
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const runAction = async (action: 'post' | 'cancel') => {
    if (!selectedId) return;
    if (!confirm((action === 'post' ? 'Post' : 'Cancel') + ' selected payment?')) return;
    setWorking(true);
    try {
      await api.post('/' + ENTITY_SLUG + '/' + selectedId + '/' + action, {});
      toast({ title: action === 'post' ? 'Payment posted' : 'Payment cancelled', variant: 'success' });
      await fetchData();
    } catch (error: any) {
      toast({ title: 'Action failed', description: error?.response?.data?.error || error?.message || 'Unknown error', variant: 'error' });
    } finally {
      setWorking(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="rounded-xl border bg-white p-4">
        <h1 className="text-xl font-semibold text-slate-900">Invoice_payments Workflow</h1>
        <p className="mt-1 text-sm text-slate-600">Post or cancel payment entries.</p>
      </div>
      <div className="rounded-xl border bg-white p-4">
        <label className="mb-2 block text-sm font-medium text-slate-700">Payment</label>
        <select
          value={selectedId}
          onChange={(e) => setSelectedId(e.target.value)}
          className="w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm"
        >
          {!items.length && <option value="">No payments</option>}
          {items.map((row) => (
            <option key={String(row.id)} value={String(row.id)}>
              {String(row.payment_number || row.id)} - {String(row.status || 'Draft')}
            </option>
          ))}
        </select>
      </div>
      <div className="grid gap-2 md:grid-cols-2">
        <button type="button" onClick={() => runAction('post')} disabled={!selectedId || working} className="rounded-md bg-blue-600 px-3 py-2 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-50">
          Post Payment
        </button>
        <button type="button" onClick={() => runAction('cancel')} disabled={!selectedId || working} className="rounded-md bg-rose-600 px-3 py-2 text-sm font-semibold text-white hover:bg-rose-700 disabled:opacity-50">
          Cancel Payment
        </button>
      </div>
    </div>
  );
}
