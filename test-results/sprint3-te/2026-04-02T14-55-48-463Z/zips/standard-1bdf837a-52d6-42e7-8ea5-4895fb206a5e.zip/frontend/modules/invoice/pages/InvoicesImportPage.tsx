import { Link, useNavigate } from 'react-router-dom';
import ImportCsvTool from '../../../src/components/tools/ImportCsvTool';

const fieldDefinitions = [
  { name: 'invoice_number', label: 'Invoice Number', type: 'string', widget: 'Input', required: true, unique: true },
  { name: 'customer_id', label: 'Customer Id', type: 'reference', widget: 'EntitySelect', required: true, referenceEntity: 'customers' },
  { name: 'issue_date', label: 'Issue Date', type: 'date', widget: 'DatePicker', required: true },
  { name: 'due_date', label: 'Due Date', type: 'date', widget: 'DatePicker', required: true },
  { name: 'status', label: 'Status', type: 'string', widget: 'Select', required: true, options: ['Draft', 'Sent', 'Paid', 'Overdue', 'Cancelled'] },
  { name: 'subtotal', label: 'Subtotal', type: 'decimal', widget: 'NumberInput', required: false },
  { name: 'tax_total', label: 'Tax Total', type: 'decimal', widget: 'NumberInput', required: false },
  { name: 'grand_total', label: 'Grand Total', type: 'decimal', widget: 'NumberInput', required: false },
  { name: 'paid_total', label: 'Paid Total', type: 'decimal', widget: 'NumberInput', required: false },
  { name: 'outstanding_balance', label: 'Outstanding Balance', type: 'decimal', widget: 'NumberInput', required: false },
  { name: 'idempotency_key', label: 'Idempotency Key', type: 'string', widget: 'Input', required: false },
  { name: 'posted_at', label: 'Posted At', type: 'datetime', widget: 'DatePicker', required: false },
  { name: 'cancelled_at', label: 'Cancelled At', type: 'datetime', widget: 'DatePicker', required: false },
  { name: 'discount_total', label: 'Discount Total', type: 'decimal', widget: 'NumberInput', required: false },
  { name: 'additional_charges_total', label: 'Additional Charges Total', type: 'decimal', widget: 'NumberInput', required: false },
  { name: 'currency', label: 'Currency', type: 'string', widget: 'Input', required: false },
];

export default function InvoicesImportPage() {
  const navigate = useNavigate();
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Import CSV — Invoices</h1>
          <p className="text-sm text-slate-600">Use the template and follow the rules.</p>
        </div>
        <Link to="/invoices" className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50 no-print">
          Back
        </Link>
      </div>

      <div className="rounded-lg bg-white p-6 shadow">
        <ImportCsvTool
          entitySlug="invoices"
          fields={fieldDefinitions as any}
          onCancel={() => navigate('/invoices')}
          onDone={() => navigate('/invoices')}
        />
      </div>
    </div>
  );
}
