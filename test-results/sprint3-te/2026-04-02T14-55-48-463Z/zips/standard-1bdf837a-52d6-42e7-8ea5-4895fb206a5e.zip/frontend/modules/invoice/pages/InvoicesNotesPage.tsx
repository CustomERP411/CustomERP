import { useEffect, useState } from 'react';
import api from '../../../src/services/api';
import { useToast } from '../../../src/components/ui/toast';

const INVOICE_SLUG = 'invoices';

export default function InvoicesNotesPage() {
  const { toast } = useToast();
  const [invoices, setInvoices] = useState<any[]>([]);
  const [selectedInvoiceId, setSelectedInvoiceId] = useState<string>('');
  const [items, setItems] = useState<any[]>([]);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    note_type: 'Credit',
    amount: '',
    tax_total: '0',
    issue_date: new Date().toISOString().slice(0, 10),
    reason: '',
    note: '',
  });

  const loadInvoices = async () => {
    try {
      const res = await api.get('/' + INVOICE_SLUG);
      const rows = Array.isArray(res.data) ? res.data : [];
      setInvoices(rows);
      if (!selectedInvoiceId && rows.length) setSelectedInvoiceId(String(rows[0].id));
    } catch (error: any) {
      toast({ title: 'Failed to load invoices', description: error?.response?.data?.error || error?.message || 'Unknown error', variant: 'error' });
    }
  };

  const loadNotes = async (invoiceId: string) => {
    if (!invoiceId) {
      setItems([]);
      return;
    }
    try {
      const res = await api.get('/' + INVOICE_SLUG + '/' + invoiceId + '/notes');
      setItems(Array.isArray(res.data) ? res.data : []);
    } catch (error: any) {
      toast({ title: 'Failed to load notes', description: error?.response?.data?.error || error?.message || 'Unknown error', variant: 'error' });
    }
  };

  useEffect(() => {
    loadInvoices();
  }, []);

  useEffect(() => {
    loadNotes(selectedInvoiceId);
  }, [selectedInvoiceId]);

  const createNote = async () => {
    if (!selectedInvoiceId) return;
    const amount = Number(form.amount);
    const tax = Number(form.tax_total);
    if (!Number.isFinite(amount) || amount <= 0) {
      toast({ title: 'Amount must be greater than zero', variant: 'warning' });
      return;
    }
    if (!Number.isFinite(tax) || tax < 0) {
      toast({ title: 'Tax total must be zero or greater', variant: 'warning' });
      return;
    }
    setSaving(true);
    try {
      await api.post('/' + INVOICE_SLUG + '/' + selectedInvoiceId + '/notes', {
        note_type: form.note_type,
        amount,
        tax_total: tax,
        issue_date: form.issue_date || undefined,
        reason: form.reason || undefined,
        note: form.note || undefined,
      });
      toast({ title: 'Note created', variant: 'success' });
      setForm((prev) => ({ ...prev, amount: '', tax_total: '0', reason: '', note: '' }));
      await loadNotes(selectedInvoiceId);
    } catch (error: any) {
      toast({ title: 'Failed to create note', description: error?.response?.data?.error || error?.message || 'Unknown error', variant: 'error' });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="rounded-xl border bg-white p-4">
        <h1 className="text-xl font-semibold text-slate-900">Invoices Notes</h1>
        <p className="mt-1 text-sm text-slate-600">Create credit/debit notes linked to source invoices.</p>
      </div>

      <div className="rounded-xl border bg-white p-4">
        <label className="mb-2 block text-sm font-medium text-slate-700">Invoice</label>
        <select
          value={selectedInvoiceId}
          onChange={(e) => setSelectedInvoiceId(e.target.value)}
          className="w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm"
        >
          {!invoices.length && <option value="">No invoices</option>}
          {invoices.map((row) => (
            <option key={String(row.id)} value={String(row.id)}>
              {String(row.invoice_number || row.id)} | Status: {String(row.status || 'Draft')}
            </option>
          ))}
        </select>
      </div>

      <div className="rounded-xl border bg-white p-4">
        <h2 className="mb-3 text-sm font-semibold text-slate-900">Create Note</h2>
        <div className="grid gap-3 md:grid-cols-5">
          <select
            value={form.note_type}
            onChange={(e) => setForm((prev) => ({ ...prev, note_type: e.target.value }))}
            className="rounded-md border border-slate-300 bg-white px-3 py-2 text-sm"
          >
            <option value="Credit">Credit</option>
            <option value="Debit">Debit</option>
          </select>
          <input
            value={form.amount}
            onChange={(e) => setForm((prev) => ({ ...prev, amount: e.target.value }))}
            placeholder="Amount"
            className="rounded-md border border-slate-300 px-3 py-2 text-sm"
          />
          <input
            value={form.tax_total}
            onChange={(e) => setForm((prev) => ({ ...prev, tax_total: e.target.value }))}
            placeholder="Tax total"
            className="rounded-md border border-slate-300 px-3 py-2 text-sm"
          />
          <input
            type="date"
            value={form.issue_date}
            onChange={(e) => setForm((prev) => ({ ...prev, issue_date: e.target.value }))}
            className="rounded-md border border-slate-300 px-3 py-2 text-sm"
          />
          <button
            type="button"
            onClick={createNote}
            disabled={!selectedInvoiceId || saving}
            className="rounded-md bg-emerald-600 px-3 py-2 text-sm font-semibold text-white hover:bg-emerald-700 disabled:opacity-50"
          >
            Create
          </button>
        </div>
        <input
          value={form.reason}
          onChange={(e) => setForm((prev) => ({ ...prev, reason: e.target.value }))}
          placeholder="Reason"
          className="mt-3 w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
        />
        <textarea
          value={form.note}
          onChange={(e) => setForm((prev) => ({ ...prev, note: e.target.value }))}
          placeholder="Note (optional)"
          className="mt-3 min-h-[84px] w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
        />
      </div>

      <div className="rounded-xl border bg-white p-4">
        <h2 className="mb-3 text-sm font-semibold text-slate-900">Notes for selected invoice</h2>
        {!items.length ? (
          <div className="text-sm text-slate-500">No notes yet.</div>
        ) : (
          <div className="space-y-2">
            {items.map((row: any) => (
              <div key={String(row.id)} className="rounded-md border border-slate-200 p-3 text-sm">
                <div className="font-medium text-slate-900">{String(row.note_number || row.id)}</div>
                <div className="mt-1 text-slate-600">{String(row.note_type || '')} | Status: {String(row.status || '')}</div>
                <div className="text-slate-600">Grand total: {String(row.grand_total ?? row.amount ?? 0)}</div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
