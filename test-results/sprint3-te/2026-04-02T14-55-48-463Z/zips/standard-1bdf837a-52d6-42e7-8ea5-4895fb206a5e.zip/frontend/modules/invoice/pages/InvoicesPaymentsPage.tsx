import { useEffect, useMemo, useState } from 'react';
import api from '../../../src/services/api';
import { useToast } from '../../../src/components/ui/toast';

const INVOICE_SLUG = 'invoices';

export default function InvoicesPaymentsPage() {
  const { toast } = useToast();
  const [invoices, setInvoices] = useState<any[]>([]);
  const [selectedInvoiceId, setSelectedInvoiceId] = useState<string>('');
  const [items, setItems] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [saving, setSaving] = useState(false);
  const [form, setForm] = useState({
    amount: '',
    payment_method: '',
    payment_date: new Date().toISOString().slice(0, 10),
    note: '',
  });

  const selectedInvoice = useMemo(
    () => invoices.find((x) => String(x.id) === String(selectedInvoiceId)) || null,
    [invoices, selectedInvoiceId]
  );

  const fetchInvoices = async () => {
    try {
      const res = await api.get('/' + INVOICE_SLUG);
      const rows = Array.isArray(res.data) ? res.data : [];
      setInvoices(rows);
      if (!selectedInvoiceId && rows.length) setSelectedInvoiceId(String(rows[0].id));
    } catch (error: any) {
      toast({ title: 'Failed to load invoices', description: error?.response?.data?.error || error?.message || 'Unknown error', variant: 'error' });
    }
  };

  const fetchPayments = async (invoiceId: string) => {
    if (!invoiceId) {
      setItems([]);
      return;
    }
    try {
      const res = await api.get('/' + INVOICE_SLUG + '/' + invoiceId + '/payments');
      setItems(Array.isArray(res.data) ? res.data : []);
    } catch (error: any) {
      toast({ title: 'Failed to load payments', description: error?.response?.data?.error || error?.message || 'Unknown error', variant: 'error' });
    }
  };

  useEffect(() => {
    (async () => {
      setLoading(true);
      await fetchInvoices();
      setLoading(false);
    })();
  }, []);

  useEffect(() => {
    fetchPayments(selectedInvoiceId);
  }, [selectedInvoiceId]);

  const createPayment = async () => {
    if (!selectedInvoiceId) return;
    const amount = Number(form.amount);
    if (!Number.isFinite(amount) || amount <= 0) {
      toast({ title: 'Amount must be greater than zero', variant: 'warning' });
      return;
    }
    setSaving(true);
    try {
      await api.post('/' + INVOICE_SLUG + '/' + selectedInvoiceId + '/payments', {
        amount,
        payment_method: form.payment_method || undefined,
        payment_date: form.payment_date || undefined,
        note: form.note || undefined,
      });
      toast({ title: 'Payment recorded', variant: 'success' });
      setForm((prev) => ({ ...prev, amount: '', payment_method: '', note: '' }));
      await fetchInvoices();
      await fetchPayments(selectedInvoiceId);
    } catch (error: any) {
      toast({ title: 'Failed to record payment', description: error?.response?.data?.error || error?.message || 'Unknown error', variant: 'error' });
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="rounded-xl border bg-white p-4">
        <h1 className="text-xl font-semibold text-slate-900">Invoices Payments</h1>
        <p className="mt-1 text-sm text-slate-600">Record and review allocations (full/partial payments).</p>
      </div>

      <div className="rounded-xl border bg-white p-4">
        <label className="mb-2 block text-sm font-medium text-slate-700">Invoice</label>
        <select
          value={selectedInvoiceId}
          onChange={(e) => setSelectedInvoiceId(e.target.value)}
          className="w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm"
        >
          {!invoices.length && <option value="">No invoices</option>}
          {invoices.map((row) => (
            <option key={String(row.id)} value={String(row.id)}>
              {String(row.invoice_number || row.id)} | Outstanding: {String(row.outstanding_balance ?? row.grand_total ?? 0)}
            </option>
          ))}
        </select>
      </div>

      <div className="rounded-xl border bg-white p-4">
        <h2 className="mb-3 text-sm font-semibold text-slate-900">Record Payment</h2>
        <div className="grid gap-3 md:grid-cols-4">
          <input
            value={form.amount}
            onChange={(e) => setForm((prev) => ({ ...prev, amount: e.target.value }))}
            placeholder="Amount"
            className="rounded-md border border-slate-300 px-3 py-2 text-sm"
          />
          <input
            value={form.payment_method}
            onChange={(e) => setForm((prev) => ({ ...prev, payment_method: e.target.value }))}
            placeholder="Payment method"
            className="rounded-md border border-slate-300 px-3 py-2 text-sm"
          />
          <input
            type="date"
            value={form.payment_date}
            onChange={(e) => setForm((prev) => ({ ...prev, payment_date: e.target.value }))}
            className="rounded-md border border-slate-300 px-3 py-2 text-sm"
          />
          <button
            type="button"
            onClick={createPayment}
            disabled={!selectedInvoiceId || saving}
            className="rounded-md bg-emerald-600 px-3 py-2 text-sm font-semibold text-white hover:bg-emerald-700 disabled:opacity-50"
          >
            Record
          </button>
        </div>
        <textarea
          value={form.note}
          onChange={(e) => setForm((prev) => ({ ...prev, note: e.target.value }))}
          placeholder="Note (optional)"
          className="mt-3 min-h-[84px] w-full rounded-md border border-slate-300 px-3 py-2 text-sm"
        />
      </div>

      <div className="rounded-xl border bg-white p-4">
        <h2 className="mb-3 text-sm font-semibold text-slate-900">Payments for selected invoice</h2>
        {loading ? (
          <div className="text-sm text-slate-500">Loading…</div>
        ) : !selectedInvoice ? (
          <div className="text-sm text-slate-500">Select an invoice.</div>
        ) : !items.length ? (
          <div className="text-sm text-slate-500">No payments allocated yet.</div>
        ) : (
          <div className="space-y-2">
            {items.map((row: any, idx: number) => {
              const payment = row?.payment || row;
              const allocation = row?.allocation || null;
              return (
                <div key={String(payment?.id || idx)} className="rounded-md border border-slate-200 p-3 text-sm">
                  <div className="font-medium text-slate-900">{String(payment?.payment_number || payment?.id || 'Payment')}</div>
                  <div className="mt-1 text-slate-600">Status: {String(payment?.status || 'Unknown')}</div>
                  <div className="text-slate-600">Amount: {String(payment?.amount ?? 0)} | Unallocated: {String(payment?.unallocated_amount ?? 0)}</div>
                  {allocation ? (
                    <div className="text-slate-600">Allocated: {String(allocation?.amount ?? 0)} at {String(allocation?.allocated_at || '')}</div>
                  ) : null}
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
}
