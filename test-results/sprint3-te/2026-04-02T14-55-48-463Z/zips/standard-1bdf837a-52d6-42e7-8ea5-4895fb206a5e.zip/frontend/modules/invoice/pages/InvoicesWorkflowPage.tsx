import { useEffect, useMemo, useState } from 'react';
import api from '../../../src/services/api';
import { useToast } from '../../../src/components/ui/toast';

const ENTITY_SLUG = 'invoices';
const STATUS_FLOW = ["Draft","Sent","Paid","Overdue","Cancelled"];

export default function InvoicesWorkflowPage() {
  const { toast } = useToast();
  const [items, setItems] = useState<any[]>([]);
  const [selectedId, setSelectedId] = useState<string>('');
  const [loading, setLoading] = useState(true);
  const [working, setWorking] = useState(false);

  const selectedInvoice = useMemo(
    () => items.find((x) => String(x.id) === String(selectedId)) || null,
    [items, selectedId]
  );

  const fetchData = async () => {
    setLoading(true);
    try {
      const res = await api.get('/' + ENTITY_SLUG);
      const rows = Array.isArray(res.data) ? res.data : [];
      setItems(rows);
      if (!selectedId && rows.length) setSelectedId(String(rows[0].id));
    } catch (error: any) {
      toast({ title: 'Failed to load invoices', description: error?.response?.data?.error || error?.message || 'Unknown error', variant: 'error' });
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchData();
  }, []);

  const runAction = async (action: 'issue' | 'cancel') => {
    if (!selectedId) return;
    if (!confirm((action === 'issue' ? 'Issue' : 'Cancel') + ' selected invoice?')) return;
    setWorking(true);
    try {
      await api.post('/' + ENTITY_SLUG + '/' + selectedId + '/' + action, {});
      toast({ title: action === 'issue' ? 'Invoice issued' : 'Invoice cancelled', variant: 'success' });
      await fetchData();
    } catch (error: any) {
      toast({ title: 'Action failed', description: error?.response?.data?.error || error?.message || 'Unknown error', variant: 'error' });
    } finally {
      setWorking(false);
    }
  };

  return (
    <div className="space-y-4">
      <div className="rounded-xl border bg-white p-4">
        <h1 className="text-xl font-semibold text-slate-900">Invoices Workflow</h1>
        <p className="mt-1 text-sm text-slate-600">Run strict invoice lifecycle actions (issue/cancel).</p>
      </div>

      <div className="rounded-xl border bg-white p-4">
        <label className="mb-2 block text-sm font-medium text-slate-700">Select Invoice</label>
        <select
          value={selectedId}
          onChange={(e) => setSelectedId(e.target.value)}
          className="w-full rounded-md border border-slate-300 bg-white px-3 py-2 text-sm"
        >
          {!items.length && <option value="">No invoices</option>}
          {items.map((row) => (
            <option key={String(row.id)} value={String(row.id)}>
              {String(row.invoice_number || row.id)} - {String(row.status || 'Draft')}
            </option>
          ))}
        </select>
      </div>

      <div className="rounded-xl border bg-white p-4">
        <div className="mb-3 text-sm text-slate-700">
          Status flow: {STATUS_FLOW.join(' -> ')}
        </div>
        <div className="grid gap-2 md:grid-cols-2">
          <button
            type="button"
            onClick={() => runAction('issue')}
            disabled={!selectedId || working}
            className="rounded-md bg-blue-600 px-3 py-2 text-sm font-semibold text-white hover:bg-blue-700 disabled:opacity-50"
          >
            Issue Invoice
          </button>
          <button
            type="button"
            onClick={() => runAction('cancel')}
            disabled={!selectedId || working}
            className="rounded-md bg-rose-600 px-3 py-2 text-sm font-semibold text-white hover:bg-rose-700 disabled:opacity-50"
          >
            Cancel Invoice
          </button>
        </div>
      </div>

      <div className="rounded-xl border bg-white p-4">
        <h2 className="mb-2 text-sm font-semibold text-slate-900">Selected Invoice</h2>
        {loading ? (
          <div className="text-sm text-slate-500">Loading…</div>
        ) : !selectedInvoice ? (
          <div className="text-sm text-slate-500">Select an invoice to view details.</div>
        ) : (
          <pre className="overflow-auto rounded-lg bg-slate-50 p-3 text-xs text-slate-700">{JSON.stringify(selectedInvoice, null, 2)}</pre>
        )}
      </div>
    </div>
  );
}
