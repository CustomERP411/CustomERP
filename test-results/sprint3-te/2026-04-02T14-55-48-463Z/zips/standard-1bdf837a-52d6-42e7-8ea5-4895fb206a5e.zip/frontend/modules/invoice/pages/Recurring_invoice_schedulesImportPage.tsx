import { Link, useNavigate } from 'react-router-dom';
import ImportCsvTool from '../../../src/components/tools/ImportCsvTool';

const fieldDefinitions = [
  { name: 'customer_id', label: 'Customer Id', type: 'reference', widget: 'EntitySelect', required: true, referenceEntity: 'customers' },
  { name: 'template_invoice_id', label: 'Template Invoice Id', type: 'reference', widget: 'EntitySelect', required: false, referenceEntity: 'invoices' },
  { name: 'frequency', label: 'Frequency', type: 'string', widget: 'RadioGroup', required: true, options: ['Weekly', 'Monthly', 'Quarterly', 'Yearly'] },
  { name: 'next_run_date', label: 'Next Run Date', type: 'date', widget: 'DatePicker', required: true },
  { name: 'status', label: 'Status', type: 'string', widget: 'RadioGroup', required: false, options: ['Active', 'Paused', 'Cancelled'] },
  { name: 'note', label: 'Note', type: 'text', widget: 'TextArea', required: false },
];

export default function Recurring_invoice_schedulesImportPage() {
  const navigate = useNavigate();
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Import CSV — Recurring Invoice Schedules</h1>
          <p className="text-sm text-slate-600">Use the template and follow the rules.</p>
        </div>
        <Link to="/recurring_invoice_schedules" className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50 no-print">
          Back
        </Link>
      </div>

      <div className="rounded-lg bg-white p-6 shadow">
        <ImportCsvTool
          entitySlug="recurring_invoice_schedules"
          fields={fieldDefinitions as any}
          onCancel={() => navigate('/recurring_invoice_schedules')}
          onDone={() => navigate('/recurring_invoice_schedules')}
        />
      </div>
    </div>
  );
}
