import { Link, useNavigate } from 'react-router-dom';
import ImportCsvTool from '../../../src/components/tools/ImportCsvTool';

const fieldDefinitions = [
  { name: 'name', label: 'Name', type: 'string', widget: 'Input', required: true },
  { name: 'company_name', label: 'Company Name', type: 'string', widget: 'Input', required: false },
  { name: 'email', label: 'Email', type: 'string', widget: 'Input', required: true },
  { name: 'phone', label: 'Phone', type: 'string', widget: 'Input', required: false },
  { name: 'address', label: 'Address', type: 'text', widget: 'TextArea', required: false },
];

export default function CustomersImportPage() {
  const navigate = useNavigate();
  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold text-slate-900">Import CSV — Customers</h1>
          <p className="text-sm text-slate-600">Use the template and follow the rules.</p>
        </div>
        <Link to="/customers" className="rounded-md bg-white px-3 py-2 text-sm font-semibold text-slate-900 ring-1 ring-slate-200 hover:bg-slate-50 no-print">
          Back
        </Link>
      </div>

      <div className="rounded-lg bg-white p-6 shadow">
        <ImportCsvTool
          entitySlug="customers"
          fields={fieldDefinitions as any}
          onCancel={() => navigate('/customers')}
          onDone={() => navigate('/customers')}
        />
      </div>
    </div>
  );
}
