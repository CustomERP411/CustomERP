import { Routes, Route, Navigate } from 'react-router-dom';
import DashboardLayout from './components/layout/DashboardLayout';
import DashboardHome from './pages/DashboardHome';

import ProductsPage from '../modules/inventory/pages/ProductsPage';
import ProductsFormPage from '../modules/inventory/pages/ProductsFormPage';
import ProductsImportPage from '../modules/inventory/pages/ProductsImportPage';
import ProductsReceivePage from '../modules/inventory/pages/ProductsReceivePage';
import ProductsIssuePage from '../modules/inventory/pages/ProductsIssuePage';
import ProductsAdjustPage from '../modules/inventory/pages/ProductsAdjustPage';
import ProductsTransferPage from '../modules/inventory/pages/ProductsTransferPage';
import ProductsLabelsPage from '../modules/inventory/pages/ProductsLabelsPage';
import ProductsReservationsPage from '../modules/inventory/pages/ProductsReservationsPage';
import LocationsPage from '../modules/inventory/pages/LocationsPage';
import LocationsFormPage from '../modules/inventory/pages/LocationsFormPage';
import LocationsImportPage from '../modules/inventory/pages/LocationsImportPage';
import Stock_movementsPage from '../modules/inventory/pages/Stock_movementsPage';
import Stock_movementsFormPage from '../modules/inventory/pages/Stock_movementsFormPage';
import Stock_movementsImportPage from '../modules/inventory/pages/Stock_movementsImportPage';
import Stock_reservationsPage from '../modules/inventory/pages/Stock_reservationsPage';
import Stock_reservationsFormPage from '../modules/inventory/pages/Stock_reservationsFormPage';
import Stock_reservationsImportPage from '../modules/inventory/pages/Stock_reservationsImportPage';
import Purchase_ordersPage from '../modules/inventory/pages/Purchase_ordersPage';
import Purchase_ordersFormPage from '../modules/inventory/pages/Purchase_ordersFormPage';
import Purchase_ordersImportPage from '../modules/inventory/pages/Purchase_ordersImportPage';
import Purchase_order_itemsPage from '../modules/inventory/pages/Purchase_order_itemsPage';
import Purchase_order_itemsFormPage from '../modules/inventory/pages/Purchase_order_itemsFormPage';
import Purchase_order_itemsImportPage from '../modules/inventory/pages/Purchase_order_itemsImportPage';
import Goods_receiptsPage from '../modules/inventory/pages/Goods_receiptsPage';
import Goods_receiptsFormPage from '../modules/inventory/pages/Goods_receiptsFormPage';
import Goods_receiptsImportPage from '../modules/inventory/pages/Goods_receiptsImportPage';
import Goods_receiptsPostingPage from '../modules/inventory/pages/Goods_receiptsPostingPage';
import Goods_receipt_itemsPage from '../modules/inventory/pages/Goods_receipt_itemsPage';
import Goods_receipt_itemsFormPage from '../modules/inventory/pages/Goods_receipt_itemsFormPage';
import Goods_receipt_itemsImportPage from '../modules/inventory/pages/Goods_receipt_itemsImportPage';
import Cycle_count_sessionsPage from '../modules/inventory/pages/Cycle_count_sessionsPage';
import Cycle_count_sessionsFormPage from '../modules/inventory/pages/Cycle_count_sessionsFormPage';
import Cycle_count_sessionsImportPage from '../modules/inventory/pages/Cycle_count_sessionsImportPage';
import Cycle_count_sessionsWorkflowPage from '../modules/inventory/pages/Cycle_count_sessionsWorkflowPage';
import Cycle_count_linesPage from '../modules/inventory/pages/Cycle_count_linesPage';
import Cycle_count_linesFormPage from '../modules/inventory/pages/Cycle_count_linesFormPage';
import Cycle_count_linesImportPage from '../modules/inventory/pages/Cycle_count_linesImportPage';
import CustomersPage from '../modules/shared/pages/CustomersPage';
import CustomersFormPage from '../modules/shared/pages/CustomersFormPage';
import CustomersImportPage from '../modules/shared/pages/CustomersImportPage';
import InvoicesPage from '../modules/invoice/pages/InvoicesPage';
import InvoicesFormPage from '../modules/invoice/pages/InvoicesFormPage';
import InvoicesImportPage from '../modules/invoice/pages/InvoicesImportPage';
import InvoicesWorkflowPage from '../modules/invoice/pages/InvoicesWorkflowPage';
import InvoicesPaymentsPage from '../modules/invoice/pages/InvoicesPaymentsPage';
import InvoicesNotesPage from '../modules/invoice/pages/InvoicesNotesPage';
import Invoice_itemsPage from '../modules/invoice/pages/Invoice_itemsPage';
import Invoice_itemsFormPage from '../modules/invoice/pages/Invoice_itemsFormPage';
import Invoice_itemsImportPage from '../modules/invoice/pages/Invoice_itemsImportPage';
import Invoice_paymentsPage from '../modules/invoice/pages/Invoice_paymentsPage';
import Invoice_paymentsFormPage from '../modules/invoice/pages/Invoice_paymentsFormPage';
import Invoice_paymentsImportPage from '../modules/invoice/pages/Invoice_paymentsImportPage';
import Invoice_paymentsWorkflowPage from '../modules/invoice/pages/Invoice_paymentsWorkflowPage';
import Invoice_payment_allocationsPage from '../modules/invoice/pages/Invoice_payment_allocationsPage';
import Invoice_payment_allocationsFormPage from '../modules/invoice/pages/Invoice_payment_allocationsFormPage';
import Invoice_payment_allocationsImportPage from '../modules/invoice/pages/Invoice_payment_allocationsImportPage';
import Invoice_notesPage from '../modules/invoice/pages/Invoice_notesPage';
import Invoice_notesFormPage from '../modules/invoice/pages/Invoice_notesFormPage';
import Invoice_notesImportPage from '../modules/invoice/pages/Invoice_notesImportPage';
import Invoice_notesWorkflowPage from '../modules/invoice/pages/Invoice_notesWorkflowPage';
import Recurring_invoice_schedulesPage from '../modules/invoice/pages/Recurring_invoice_schedulesPage';
import Recurring_invoice_schedulesFormPage from '../modules/invoice/pages/Recurring_invoice_schedulesFormPage';
import Recurring_invoice_schedulesImportPage from '../modules/invoice/pages/Recurring_invoice_schedulesImportPage';
import DepartmentsPage from '../modules/hr/pages/DepartmentsPage';
import DepartmentsFormPage from '../modules/hr/pages/DepartmentsFormPage';
import DepartmentsImportPage from '../modules/hr/pages/DepartmentsImportPage';
import EmployeesPage from '../modules/hr/pages/EmployeesPage';
import EmployeesFormPage from '../modules/hr/pages/EmployeesFormPage';
import EmployeesImportPage from '../modules/hr/pages/EmployeesImportPage';
import EmployeesBalancesPage from '../modules/hr/pages/EmployeesBalancesPage';
import LeavesPage from '../modules/hr/pages/LeavesPage';
import LeavesFormPage from '../modules/hr/pages/LeavesFormPage';
import LeavesImportPage from '../modules/hr/pages/LeavesImportPage';
import LeavesApprovalsPage from '../modules/hr/pages/LeavesApprovalsPage';
import Leave_balancesPage from '../modules/hr/pages/Leave_balancesPage';
import Leave_balancesFormPage from '../modules/hr/pages/Leave_balancesFormPage';
import Leave_balancesImportPage from '../modules/hr/pages/Leave_balancesImportPage';
import Attendance_entriesPage from '../modules/hr/pages/Attendance_entriesPage';
import Attendance_entriesFormPage from '../modules/hr/pages/Attendance_entriesFormPage';
import Attendance_entriesImportPage from '../modules/hr/pages/Attendance_entriesImportPage';
import Attendance_entriesAttendancePage from '../modules/hr/pages/Attendance_entriesAttendancePage';
import Shift_assignmentsPage from '../modules/hr/pages/Shift_assignmentsPage';
import Shift_assignmentsFormPage from '../modules/hr/pages/Shift_assignmentsFormPage';
import Shift_assignmentsImportPage from '../modules/hr/pages/Shift_assignmentsImportPage';
import Timesheet_entriesPage from '../modules/hr/pages/Timesheet_entriesPage';
import Timesheet_entriesFormPage from '../modules/hr/pages/Timesheet_entriesFormPage';
import Timesheet_entriesImportPage from '../modules/hr/pages/Timesheet_entriesImportPage';
import Compensation_ledgerPage from '../modules/hr/pages/Compensation_ledgerPage';
import Compensation_ledgerFormPage from '../modules/hr/pages/Compensation_ledgerFormPage';
import Compensation_ledgerImportPage from '../modules/hr/pages/Compensation_ledgerImportPage';
import Compensation_snapshotsPage from '../modules/hr/pages/Compensation_snapshotsPage';
import Compensation_snapshotsFormPage from '../modules/hr/pages/Compensation_snapshotsFormPage';
import Compensation_snapshotsImportPage from '../modules/hr/pages/Compensation_snapshotsImportPage';

function App() {
  return (
    <Routes>
      <Route element={<DashboardLayout />}>
        <Route path="/" element={<DashboardHome />} />

          <Route path="/products" element={<ProductsPage />} />
          <Route path="/products/new" element={<ProductsFormPage />} />
          <Route path="/products/:id/edit" element={<ProductsFormPage />} />
          <Route path="/products/import" element={<ProductsImportPage />} />
          <Route path="/products/receive" element={<ProductsReceivePage />} />
          <Route path="/products/issue" element={<ProductsIssuePage />} />
          <Route path="/products/adjust" element={<ProductsAdjustPage />} />
          <Route path="/products/transfer" element={<ProductsTransferPage />} />
          <Route path="/products/labels" element={<ProductsLabelsPage />} />
          <Route path="/products/reservations" element={<ProductsReservationsPage />} />
          <Route path="/locations" element={<LocationsPage />} />
          <Route path="/locations/new" element={<LocationsFormPage />} />
          <Route path="/locations/:id/edit" element={<LocationsFormPage />} />
          <Route path="/locations/import" element={<LocationsImportPage />} />
          <Route path="/stock_movements" element={<Stock_movementsPage />} />
          <Route path="/stock_movements/new" element={<Stock_movementsFormPage />} />
          <Route path="/stock_movements/:id/edit" element={<Stock_movementsFormPage />} />
          <Route path="/stock_movements/import" element={<Stock_movementsImportPage />} />
          <Route path="/stock_reservations" element={<Stock_reservationsPage />} />
          <Route path="/stock_reservations/new" element={<Stock_reservationsFormPage />} />
          <Route path="/stock_reservations/:id/edit" element={<Stock_reservationsFormPage />} />
          <Route path="/stock_reservations/import" element={<Stock_reservationsImportPage />} />
          <Route path="/purchase_orders" element={<Purchase_ordersPage />} />
          <Route path="/purchase_orders/new" element={<Purchase_ordersFormPage />} />
          <Route path="/purchase_orders/:id/edit" element={<Purchase_ordersFormPage />} />
          <Route path="/purchase_orders/import" element={<Purchase_ordersImportPage />} />
          <Route path="/purchase_order_items" element={<Purchase_order_itemsPage />} />
          <Route path="/purchase_order_items/new" element={<Purchase_order_itemsFormPage />} />
          <Route path="/purchase_order_items/:id/edit" element={<Purchase_order_itemsFormPage />} />
          <Route path="/purchase_order_items/import" element={<Purchase_order_itemsImportPage />} />
          <Route path="/goods_receipts" element={<Goods_receiptsPage />} />
          <Route path="/goods_receipts/new" element={<Goods_receiptsFormPage />} />
          <Route path="/goods_receipts/:id/edit" element={<Goods_receiptsFormPage />} />
          <Route path="/goods_receipts/import" element={<Goods_receiptsImportPage />} />
          <Route path="/goods_receipts/posting" element={<Goods_receiptsPostingPage />} />
          <Route path="/goods_receipt_items" element={<Goods_receipt_itemsPage />} />
          <Route path="/goods_receipt_items/new" element={<Goods_receipt_itemsFormPage />} />
          <Route path="/goods_receipt_items/:id/edit" element={<Goods_receipt_itemsFormPage />} />
          <Route path="/goods_receipt_items/import" element={<Goods_receipt_itemsImportPage />} />
          <Route path="/cycle_count_sessions" element={<Cycle_count_sessionsPage />} />
          <Route path="/cycle_count_sessions/new" element={<Cycle_count_sessionsFormPage />} />
          <Route path="/cycle_count_sessions/:id/edit" element={<Cycle_count_sessionsFormPage />} />
          <Route path="/cycle_count_sessions/import" element={<Cycle_count_sessionsImportPage />} />
          <Route path="/cycle_count_sessions/workflow" element={<Cycle_count_sessionsWorkflowPage />} />
          <Route path="/cycle_count_lines" element={<Cycle_count_linesPage />} />
          <Route path="/cycle_count_lines/new" element={<Cycle_count_linesFormPage />} />
          <Route path="/cycle_count_lines/:id/edit" element={<Cycle_count_linesFormPage />} />
          <Route path="/cycle_count_lines/import" element={<Cycle_count_linesImportPage />} />
          <Route path="/customers" element={<CustomersPage />} />
          <Route path="/customers/new" element={<CustomersFormPage />} />
          <Route path="/customers/:id/edit" element={<CustomersFormPage />} />
          <Route path="/customers/import" element={<CustomersImportPage />} />
          <Route path="/invoices" element={<InvoicesPage />} />
          <Route path="/invoices/new" element={<InvoicesFormPage />} />
          <Route path="/invoices/:id/edit" element={<InvoicesFormPage />} />
          <Route path="/invoices/import" element={<InvoicesImportPage />} />
          <Route path="/invoices/workflow" element={<InvoicesWorkflowPage />} />
          <Route path="/invoices/payments" element={<InvoicesPaymentsPage />} />
          <Route path="/invoices/notes" element={<InvoicesNotesPage />} />
          <Route path="/invoice_items" element={<Invoice_itemsPage />} />
          <Route path="/invoice_items/new" element={<Invoice_itemsFormPage />} />
          <Route path="/invoice_items/:id/edit" element={<Invoice_itemsFormPage />} />
          <Route path="/invoice_items/import" element={<Invoice_itemsImportPage />} />
          <Route path="/invoice_payments" element={<Invoice_paymentsPage />} />
          <Route path="/invoice_payments/new" element={<Invoice_paymentsFormPage />} />
          <Route path="/invoice_payments/:id/edit" element={<Invoice_paymentsFormPage />} />
          <Route path="/invoice_payments/import" element={<Invoice_paymentsImportPage />} />
          <Route path="/invoice_payments/workflow" element={<Invoice_paymentsWorkflowPage />} />
          <Route path="/invoice_payment_allocations" element={<Invoice_payment_allocationsPage />} />
          <Route path="/invoice_payment_allocations/new" element={<Invoice_payment_allocationsFormPage />} />
          <Route path="/invoice_payment_allocations/:id/edit" element={<Invoice_payment_allocationsFormPage />} />
          <Route path="/invoice_payment_allocations/import" element={<Invoice_payment_allocationsImportPage />} />
          <Route path="/invoice_notes" element={<Invoice_notesPage />} />
          <Route path="/invoice_notes/new" element={<Invoice_notesFormPage />} />
          <Route path="/invoice_notes/:id/edit" element={<Invoice_notesFormPage />} />
          <Route path="/invoice_notes/import" element={<Invoice_notesImportPage />} />
          <Route path="/invoice_notes/workflow" element={<Invoice_notesWorkflowPage />} />
          <Route path="/recurring_invoice_schedules" element={<Recurring_invoice_schedulesPage />} />
          <Route path="/recurring_invoice_schedules/new" element={<Recurring_invoice_schedulesFormPage />} />
          <Route path="/recurring_invoice_schedules/:id/edit" element={<Recurring_invoice_schedulesFormPage />} />
          <Route path="/recurring_invoice_schedules/import" element={<Recurring_invoice_schedulesImportPage />} />
          <Route path="/departments" element={<DepartmentsPage />} />
          <Route path="/departments/new" element={<DepartmentsFormPage />} />
          <Route path="/departments/:id/edit" element={<DepartmentsFormPage />} />
          <Route path="/departments/import" element={<DepartmentsImportPage />} />
          <Route path="/employees" element={<EmployeesPage />} />
          <Route path="/employees/new" element={<EmployeesFormPage />} />
          <Route path="/employees/:id/edit" element={<EmployeesFormPage />} />
          <Route path="/employees/import" element={<EmployeesImportPage />} />
          <Route path="/employees/balances" element={<EmployeesBalancesPage />} />
          <Route path="/leaves" element={<LeavesPage />} />
          <Route path="/leaves/new" element={<LeavesFormPage />} />
          <Route path="/leaves/:id/edit" element={<LeavesFormPage />} />
          <Route path="/leaves/import" element={<LeavesImportPage />} />
          <Route path="/leaves/approvals" element={<LeavesApprovalsPage />} />
          <Route path="/leave_balances" element={<Leave_balancesPage />} />
          <Route path="/leave_balances/new" element={<Leave_balancesFormPage />} />
          <Route path="/leave_balances/:id/edit" element={<Leave_balancesFormPage />} />
          <Route path="/leave_balances/import" element={<Leave_balancesImportPage />} />
          <Route path="/attendance_entries" element={<Attendance_entriesPage />} />
          <Route path="/attendance_entries/new" element={<Attendance_entriesFormPage />} />
          <Route path="/attendance_entries/:id/edit" element={<Attendance_entriesFormPage />} />
          <Route path="/attendance_entries/import" element={<Attendance_entriesImportPage />} />
          <Route path="/attendance_entries/attendance" element={<Attendance_entriesAttendancePage />} />
          <Route path="/shift_assignments" element={<Shift_assignmentsPage />} />
          <Route path="/shift_assignments/new" element={<Shift_assignmentsFormPage />} />
          <Route path="/shift_assignments/:id/edit" element={<Shift_assignmentsFormPage />} />
          <Route path="/shift_assignments/import" element={<Shift_assignmentsImportPage />} />
          <Route path="/timesheet_entries" element={<Timesheet_entriesPage />} />
          <Route path="/timesheet_entries/new" element={<Timesheet_entriesFormPage />} />
          <Route path="/timesheet_entries/:id/edit" element={<Timesheet_entriesFormPage />} />
          <Route path="/timesheet_entries/import" element={<Timesheet_entriesImportPage />} />
          <Route path="/compensation_ledger" element={<Compensation_ledgerPage />} />
          <Route path="/compensation_ledger/new" element={<Compensation_ledgerFormPage />} />
          <Route path="/compensation_ledger/:id/edit" element={<Compensation_ledgerFormPage />} />
          <Route path="/compensation_ledger/import" element={<Compensation_ledgerImportPage />} />
          <Route path="/compensation_snapshots" element={<Compensation_snapshotsPage />} />
          <Route path="/compensation_snapshots/new" element={<Compensation_snapshotsFormPage />} />
          <Route path="/compensation_snapshots/:id/edit" element={<Compensation_snapshotsFormPage />} />
          <Route path="/compensation_snapshots/import" element={<Compensation_snapshotsImportPage />} />
      </Route>
      <Route path="*" element={<Navigate to="/" replace />} />
    </Routes>
  );
}

export default App;