import { Link, useLocation } from 'react-router-dom';
import { ENTITIES } from '../config/entities';

const MODULE_DISPLAY_NAMES: Record<string, string> = {
  inventory: 'Inventory',
  invoice: 'Invoice',
  hr: 'HR',
  shared: 'Shared',
};

export default function Sidebar() {
  const location = useLocation();

  // Group entities by module
  const entityGroups = ENTITIES.reduce((acc, entity) => {
    const moduleKey = entity.module || 'inventory';
    if (!acc[moduleKey]) {
      acc[moduleKey] = [];
    }
    acc[moduleKey].push(entity);
    return acc;
  }, {} as Record<string, typeof ENTITIES>);

  // Order modules: inventory, invoice, hr, then shared
  const moduleOrder = ['inventory', 'invoice', 'hr', 'shared'];
  const orderedModules = moduleOrder.filter(mod => entityGroups[mod] && entityGroups[mod].length > 0);

  return (
    <aside className="w-64 border-r bg-white flex flex-col">
      <div className="px-4 py-4">
        <div className="text-lg font-bold text-slate-900">ERP System</div>
        <div className="text-xs text-slate-500">CustomERP generated</div>
      </div>
      
      <nav className="px-2 pb-4 flex-1 overflow-y-auto">
        <Link
          to="/"
          className={[
            'mb-1 block rounded-lg px-3 py-2 text-sm font-medium',
            location.pathname === '/' ? 'bg-slate-900 text-white' : 'text-slate-700 hover:bg-slate-100',
          ].join(' ')}
        >
          Dashboard
        </Link>

        {orderedModules.map((moduleKey) => (
          <div key={moduleKey} className="mt-4">
            <div className="px-3 mb-1 text-xs font-semibold uppercase tracking-wide text-slate-400">
              {MODULE_DISPLAY_NAMES[moduleKey] || moduleKey}
            </div>
            {entityGroups[moduleKey].map((e) => {
              const active = location.pathname === '/' + e.slug || location.pathname.startsWith('/' + e.slug + '/');
              return (
                <Link
                  key={e.slug}
                  to={'/' + e.slug}
                  className={[
                    'mb-1 block rounded-lg px-3 py-2 text-sm font-medium',
                    active ? 'bg-blue-600 text-white' : 'text-slate-700 hover:bg-slate-100',
                  ].join(' ')}
                >
                  {e.displayName}
                </Link>
              );
            })}
          </div>
        ))}


        <div className="my-2 px-3 text-xs font-semibold uppercase tracking-wide text-slate-400">Inventory Workflows</div>
        
        <Link
          to="/products/reservations"
          className={[
            'mb-1 block rounded-lg px-3 py-2 text-sm font-medium',
            location.pathname.startsWith('/products/reservations') ? 'bg-indigo-600 text-white' : 'text-slate-700 hover:bg-slate-100',
          ].join(' ')}
        >
          Reservations
        </Link>
        <Link
          to="/goods_receipts/posting"
          className={[
            'mb-1 block rounded-lg px-3 py-2 text-sm font-medium',
            location.pathname.startsWith('/goods_receipts/posting') ? 'bg-indigo-600 text-white' : 'text-slate-700 hover:bg-slate-100',
          ].join(' ')}
        >
          PO / GRN Posting
        </Link>
        <Link
          to="/cycle_count_sessions/workflow"
          className={[
            'mb-1 block rounded-lg px-3 py-2 text-sm font-medium',
            location.pathname.startsWith('/cycle_count_sessions/workflow') ? 'bg-indigo-600 text-white' : 'text-slate-700 hover:bg-slate-100',
          ].join(' ')}
        >
          Cycle Count Workflow
        </Link>
      

        <div className="my-2 px-3 text-xs font-semibold uppercase tracking-wide text-slate-400">Invoice Workflows</div>
        
        <Link
          to="/invoices/workflow"
          className={[
            'mb-1 block rounded-lg px-3 py-2 text-sm font-medium',
            location.pathname.startsWith('/invoices/workflow') ? 'bg-indigo-600 text-white' : 'text-slate-700 hover:bg-slate-100',
          ].join(' ')}
        >
          Invoice Lifecycle
        </Link>
        <Link
          to="/invoices/payments"
          className={[
            'mb-1 block rounded-lg px-3 py-2 text-sm font-medium',
            location.pathname.startsWith('/invoices/payments') ? 'bg-indigo-600 text-white' : 'text-slate-700 hover:bg-slate-100',
          ].join(' ')}
        >
          Invoice Payments
        </Link>
        <Link
          to="/invoices/notes"
          className={[
            'mb-1 block rounded-lg px-3 py-2 text-sm font-medium',
            location.pathname.startsWith('/invoices/notes') ? 'bg-indigo-600 text-white' : 'text-slate-700 hover:bg-slate-100',
          ].join(' ')}
        >
          Invoice Notes
        </Link>
        <Link
          to="/invoice_payments/workflow"
          className={[
            'mb-1 block rounded-lg px-3 py-2 text-sm font-medium',
            location.pathname.startsWith('/invoice_payments/workflow') ? 'bg-indigo-600 text-white' : 'text-slate-700 hover:bg-slate-100',
          ].join(' ')}
        >
          Payment Posting
        </Link>
        <Link
          to="/invoice_notes/workflow"
          className={[
            'mb-1 block rounded-lg px-3 py-2 text-sm font-medium',
            location.pathname.startsWith('/invoice_notes/workflow') ? 'bg-indigo-600 text-white' : 'text-slate-700 hover:bg-slate-100',
          ].join(' ')}
        >
          Note Posting
        </Link>
      

        <div className="my-2 px-3 text-xs font-semibold uppercase tracking-wide text-slate-400">HR Workflows</div>
        
        <Link
          to="/leaves/approvals"
          className={[
            'mb-1 block rounded-lg px-3 py-2 text-sm font-medium',
            location.pathname.startsWith('/leaves/approvals') ? 'bg-indigo-600 text-white' : 'text-slate-700 hover:bg-slate-100',
          ].join(' ')}
        >
          Leave Approvals
        </Link>
        <Link
          to="/employees/balances"
          className={[
            'mb-1 block rounded-lg px-3 py-2 text-sm font-medium',
            location.pathname.startsWith('/employees/balances') ? 'bg-indigo-600 text-white' : 'text-slate-700 hover:bg-slate-100',
          ].join(' ')}
        >
          Leave Balances
        </Link>
        <Link
          to="/attendance_entries/attendance"
          className={[
            'mb-1 block rounded-lg px-3 py-2 text-sm font-medium',
            location.pathname.startsWith('/attendance_entries/attendance') ? 'bg-indigo-600 text-white' : 'text-slate-700 hover:bg-slate-100',
          ].join(' ')}
        >
          Attendance Entries
        </Link>
      
      </nav>
    </aside>
  );
}
