export interface EntityNavItem {
  slug: string;
  displayName: string;
  displayField: string;
  module?: string;
}

export const ENTITIES: EntityNavItem[] = [
  { slug: 'products', displayName: 'Products', displayField: 'name', module: 'inventory' },
  { slug: 'locations', displayName: 'Locations', displayField: 'name', module: 'inventory' },
  { slug: 'stock_movements', displayName: 'Stock Movements', displayField: 'item_id', module: 'inventory' },
  { slug: 'stock_reservations', displayName: 'Stock Reservations', displayField: 'reservation_number', module: 'inventory' },
  { slug: 'purchase_orders', displayName: 'Purchase Orders', displayField: 'po_number', module: 'inventory' },
  { slug: 'purchase_order_items', displayName: 'Purchase Order Items', displayField: 'purchase_order_id', module: 'inventory' },
  { slug: 'goods_receipts', displayName: 'Goods Receipts', displayField: 'grn_number', module: 'inventory' },
  { slug: 'goods_receipt_items', displayName: 'Goods Receipt Items', displayField: 'goods_receipt_id', module: 'inventory' },
  { slug: 'cycle_count_sessions', displayName: 'Cycle Count Sessions', displayField: 'session_number', module: 'inventory' },
  { slug: 'cycle_count_lines', displayName: 'Cycle Count Lines', displayField: 'cycle_count_session_id', module: 'inventory' },
  { slug: 'customers', displayName: 'Customers', displayField: 'name', module: 'shared' },
  { slug: 'invoices', displayName: 'Invoices', displayField: 'invoice_number', module: 'invoice' },
  { slug: 'invoice_items', displayName: 'Invoice Items', displayField: 'description', module: 'invoice' },
  { slug: 'invoice_payments', displayName: 'Invoice Payments', displayField: 'payment_number', module: 'invoice' },
  { slug: 'invoice_payment_allocations', displayName: 'Invoice Payment Allocations', displayField: 'payment_id', module: 'invoice' },
  { slug: 'invoice_notes', displayName: 'Invoice Notes', displayField: 'note_number', module: 'invoice' },
  { slug: 'recurring_invoice_schedules', displayName: 'Recurring Invoice Schedules', displayField: 'customer_id', module: 'invoice' },
  { slug: 'departments', displayName: 'Departments', displayField: 'name', module: 'hr' },
  { slug: 'employees', displayName: 'Employees', displayField: 'first_name', module: 'hr' },
  { slug: 'leaves', displayName: 'Leaves', displayField: 'leave_type', module: 'hr' },
  { slug: 'leave_balances', displayName: 'Leave Balances', displayField: 'leave_type', module: 'hr' },
  { slug: 'attendance_entries', displayName: 'Attendance Entries', displayField: 'employee_id', module: 'hr' },
  { slug: 'shift_assignments', displayName: 'Shift Assignments', displayField: 'shift_name', module: 'hr' },
  { slug: 'timesheet_entries', displayName: 'Timesheet Entries', displayField: 'employee_id', module: 'hr' },
  { slug: 'compensation_ledger', displayName: 'Compensation Ledger', displayField: 'employee_id', module: 'hr' },
  { slug: 'compensation_snapshots', displayName: 'Compensation Snapshots', displayField: 'employee_id', module: 'hr' },
];
